import pandas as pd
from rapidspy.sql import RapidsPYSQL
from rapidspy.config import RapidsPYSession, SESSION_MAP


def new_rapidspy_object(meta, backend_sql, table_name=None, dependencies=None, op=None, computed=False, table_in_session=True, cls=None):
    if cls is not None: # for Scalar
        return cls(meta, backend_sql, table=table_name, dependencies=dependencies, op=op, computed=computed, table_in_session=table_in_session)
    elif type(meta) is pd.DataFrame:
        meta = meta.copy() # 保证index和columns是一个新的副本，改名影响别的对象
        from rapidspy.frame import DataFrame
        return DataFrame(meta, backend_sql, table=table_name, dependencies=dependencies, op=op, computed=computed, table_in_session=table_in_session)
    elif type(meta) is pd.Series:
        meta = meta.copy() # 保证index和columns是一个新的副本，改名影响别的对象
        from rapidspy.series import Series
        return Series(meta, backend_sql, table=table_name, dependencies=dependencies, op=op, computed=computed, table_in_session=table_in_session)
    elif isinstance(meta, pd.Index):
        # meta = meta.copy() # index需要保证和rs以及rdf的index是一个对象，暂不清楚对于index本身的接口而言，是否需要深拷贝一份
        from rapidspy.index import Index
        return Index(meta, backend_sql, table=table_name, dependencies=dependencies, op=op, computed=computed, table_in_session=table_in_session)
    raise NotImplementedError


class Frame(object):
    
    def __init__(self, meta: pd.DataFrame, backend_sql: RapidsPYSQL, table=None, dependencies=None, op = None, computed=False, table_in_session=True):
        self._meta = meta
        self.session_id = backend_sql.session_id
        self.rid = self.session.rid
        self.session.rid += 1
        if table is None:
            self.table = backend_sql.new_table()
        else:
            if not computed and self.backend_sql.has_table(table):
            # TODO 由于延迟计算，应该还需要判断是否在session中
                raise ValueError(f"Table {table} exists in Backend Engine.")
            self.table = str(table)            
        
        self.session.set_rapidspy_obj(self) # 设置完table和session_id后，将其绑定到session中
        self.computed = computed
        self.sql = '' # 记录当前操作生成的sql语句
        self.op = op
        self.dependencies = dependencies
        
        self.method_factory = backend_sql.create_method_factory()
        self.fa = self # 记录可优化的祖先节点
        self.table_in_session = table_in_session # 记录是否需要session管理
        if self.table_in_session and self.computed:
            self.backend_sql.computed_tables.add(self.table)
        # print(f"New Object: table: {self.table}, meta_type: {type(self._meta)}\n")

    @property
    def session(self) -> RapidsPYSession:
        session = SESSION_MAP.get(self.session_id)
        if not session:
            raise Exception("Session Already closed")
        return session

    @property
    def backend_sql(self) -> RapidsPYSQL:
        return self.session.backend_sql

    @property
    def fa(self):
        return self.session.get_rapidspy_obj(self._fa)

    @fa.setter
    def fa(self, fa):
        self._fa = fa.rid

    @property
    def dependencies(self):
        return [self.session.get_rapidspy_obj(rid) for rid in self.session._graph[self.rid]]

    @dependencies.setter
    def dependencies(self, dependencies):
        if dependencies is None:
            self.session._graph[self.rid] = []
        else:
            self.session._graph[self.rid] = [father.rid for father in dependencies]

    def put(self, dependencies=None, op=None):
        self.op = op
        self.dependencies = dependencies

    # def __del__(self):
    #     try:
    #         del self.session._graph[self.table] # 若session已经close，会导致程序结束时，取不到session而触发这个方法，进而报错
    #     except:
    #         pass
    #     try:
    #         if self.computed and self.table_in_session:
    #             sql = f"DROP TABLE {self.table}"
    #             self.backend_sql.execute(sql)
    #     except Exception as e:
    #         pass
            # print("__del__: ", e)
    
    def __str__(self):
        return f"table: {self.table}"
        if self.computed:
            return str(self.table)
        raise Exception("No computed exception.")

    def dfs(self, gray_set, black_set, need_ix=True):
        # print("visit:", self.table, "father:", end=': ')
        # for father in self.dependencies:
        #     print(father.table, end=', ')
        # print()
        if self.computed or self.table in black_set:
            return ""
        if self.table in gray_set:
            print(f"cycle at {self}")
            raise Exception(f"cycle at {self}")
        
        # if self in dfs_set:
        #     return True
        # dfs_set.add(self)
        gray_set.add(self.table)

        sql = ""
        if self.fa is not self: # 可优化的情况
            sql = self.fa.dfs(gray_set, black_set)
            self.sql = self.op(self, *self.dependencies) # 从祖先生成sql语句，完成优化, 但只能传递依赖进去
        else:
            for father in self.dependencies:
                father_sql = father.dfs(gray_set, black_set, need_ix = True) # 先各自计算出father的table
                if father_sql:
                    sql = sql + father_sql
            self.sql = self.op(self, *self.dependencies) # 然后再计算自己的table

        black_set.add(self.table)
        sql += f"{self.table} as ({self.sql}),\n"
        return sql

    def gen_sql(self):
        gray_set = set()
        black_set = set()
        sql = 'With\n' + self.dfs(gray_set, black_set)
        sql = f"CREATE TABLE {self.table} AS " + sql[:-2]
        sql += f"\nSELECT * FROM {self.table};\n"
        # print("table:", self.table)
        # print("sql:", sql)
        return sql

    def compute(self):
        if self.computed:
            return self
        sql = self.gen_sql()
        self.backend_sql.execute(sql)
        if self.table_in_session:
            self.backend_sql.computed_tables.add(self.table)
        self.computed = True
        return self

    def remove(self):
        if not self.computed:
            return self
        sql = f"drop table {self.table}"
        self.backend_sql.execute(sql)
        if self.table_in_session:
            self.backend_sql.computed_tables.remove(self.table)
        self.computed = False
        return self

    def _create_method_instance(self, **kwargs):
        raise NotImplementedError
        
    def persist(self, table_name=None, if_exists="fail"):
        # 引擎中的表都是和对象绑定的，不应该轻易删除
        if table_name is not None:
            if self.backend_sql.BACKEND_TYPE == "MOXE":
                table_name = table_name.upper()
            elif self.backend_sql.BACKEND_TYPE == "POSTGRES":
                table_name = table_name.lower()

            if self.backend_sql.has_table(table_name):
                if if_exists == "fail":
                    raise ValueError(f"Table {table_name} exists in Backend Engine.")
                elif if_exists == "replace":
                    self.backend_sql.drop_table(table_name)
                else:
                    raise ValueError("if_exists can only be fail and replace.")
        meta = self._meta.copy()
        new_o = new_rapidspy_object(meta, backend_sql=self.backend_sql, table_name=table_name)
        new_o.put(dependencies=[self], op=self._create_method_instance().nothing)
        new_o.table_in_session = False
        return new_o

    def _find_src(self, in1, in2):
        pass

    # 暂时只有运算方法提供了两个父亲的依赖关系，避免复杂化
    def condition_dfs(self, src):
        if len(self.dependencies) == 1:
            if isinstance(src._meta, pd.DataFrame) and self.dependencies[0] is src:
                # self.op(self, *self.dependencies, no_select=True) # getitem和loc等操作暂时没有添加 no select
                # ci = src.columns.get_loc(self.name) # 只能取出Series进行比较操作，例如 rdf['l_partkey']、rdf.loc[:, 'l_partkey']
                # return f"c{ci}"
                if isinstance(self._meta, pd.Series):
                    return f'"{self.name}"'
                else:
                    pass
            if isinstance(src._meta, pd.Series) and self is src:
                return f'"{self.name}"'
            if self is src:
                return ''
            fa_con = self.dependencies[0].condition_dfs(src)
            con = self.op(self, *self.dependencies, no_select=True).format(fa_con=fa_con)
            con = f"({con})"
        elif len(self.dependencies) == 2:
            l_con = self.dependencies[0].condition_dfs(src)
            r_con = self.dependencies[1].condition_dfs(src)
            con = self.op(self, *self.dependencies, no_select=True).format(l_con=l_con, r_con=r_con)
            con = f"({con})"
        else:
            # 这种情况就是找不到祖先
            print(self.op, self.dependencies)
        return con

    def _get_condition(self, rs):
        # if 同源
        if isinstance(rs, Frame):
            condition  = rs.condition_dfs(src=self)
            return condition
        elif isinstance(rs, str):
            return f"'{rs}'"
        elif isinstance(rs, bool):
            return "true" if rs else "false"
        else:
            return rs

"""
WITH
linea as (SELECT l_orderkey from LINEITEM),
lineb as (SELECT l_orderkey, IF(l_orderkey <= 20000, 1, 0) as value FROM linea),
linec as (SELECT LINEITEM from LINEITEM JOIN lineb ON LINEITEM.l_orderkey = lineb.l_orderkey WHERE value = 1)SELECT * FROM linec limit 10;

select  * from  l_orderkey <= 20000

CREATE TABLE table_70 AS ( WITH
table_33 as (SELECT l_orderkey from LINEITEM),
table_34 as (SELECT l_orderkey, IF(l_orderkey <= 20000, 1, 0) as value FROM table_33),
table_35 as (SELECT LINEITEM.l_orderkey, LINEITEM.l_orderkey, LINEITEM.l_partkey, LINEITEM.l_partkey, LINEITEM.l_suppkey, LINEITEM.l_suppkey, LINEITEM.l_linenumber, LINEITEM.l_linenumber, LINEITEM.l_quantity, LINEITEM.l_quantity, LINEITEM.l_extendedprice, LINEITEM.l_extendedprice, LINEITEM.l_discount, LINEITEM.l_discount, LINEITEM.l_tax, LINEITEM.l_tax, LINEITEM.l_returnflag, LINEITEM.l_returnflag, LINEITEM.l_linestatus, LINEITEM.l_linestatus, LINEITEM.l_shipdate, LINEITEM.l_shipdate, LINEITEM.l_commitdate, LINEITEM.l_commitdate, LINEITEM.l_receiptdate, LINEITEM.l_receiptdate, LINEITEM.l_shipinstruct, LINEITEM.l_shipinstruct, LINEITEM.l_shipmode, LINEITEM.l_shipmode, LINEITEM.l_comment, LINEITEM.l_comment from LINEITEM JOIN table_34 ON LINEITEM.l_orderkey = table_34.l_orderkey WHERE value > 0),
table_68 as (SELECT l_returnflag, l_linestatus, MIN(l_quantity) FROM table_35 GROUP BY l_returnflag, l_linestatus),
table_70 as (SELECT * from table_68 ORDER BY l_returnflag, l_linestatus)
SELECT * FROM table_70 limit 10);

CREATE TABLE "table7" AS ( With
"table6" as (SELECT row_number() over() -1 as table6_ix, l_orderkey as c0, l_partkey as c1, l_suppkey as c2, l_linenumber as c3, l_quantity as c4, l_extendedprice as c5, l_discount as c6, l_tax as c7, l_returnflag as c8, l_linestatus as c9, l_shipdate as c10, l_commitdate as c11, l_receiptdate as c12, l_shipinstruct as c13, l_shipmode as c14, l_comment as c15 FROM "TABLE5"),
"table7" as (SELECT c5 FROM "table6" WHERE table6_ix=5)
SELECT * FROM "table7");
"""