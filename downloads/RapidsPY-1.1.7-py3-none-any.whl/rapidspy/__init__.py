from rapidspy.general import to_datetime, cut

from rapidspy.frame import DataFrame
from rapidspy.series import Series
from rapidspy.index import Index
from rapidspy.scalar import Scalar

from rapidspy.missing import isna, isnull, notna, notnull

from rapidspy.config import RapidsPYSession

__all__ = [
    "to_datetime",
    "cut",
    "isna",
    "isnull",
    "notna",
    "notnull"
]

# version = "v1.1.0" # rapidspy index column 单例化
# version = "v1.1.1" # 解决read_sql_table 读引擎表重复读的问题，增加persist接口
# version = "v1.1.2 demo" # rapidspy AIworkflow特有接口开发完成
# version = "v1.1.3 r+-*/ and fix from pandas" # 加减乘除求幂右方法，from pandas 以及修复loc str的bug
# version = "v1.1.4 apply for groupby" # 支持groupby的apply运算
# version = "v1.1.5 fix none and repeated name" # 修复列名和索引名为空以及重复的问题
# version = "v1.1.6 fix serialization" # 支持rapidspy对象序列化
version = "V1.1.7 add rid and fix case sensitive method" # 修复数据库大小写敏感问题，以及rapidspy 读写数据的一些优化

