import datetime
import inspect
import numpy as np
import pandas as pd
from pandas.api.types import is_categorical_dtype, is_scalar
from sqlalchemy import schema

from rapidspy import config


def get__function_name():
    '''获取正在运行函数(或方法)名称'''
    return inspect.stack()[1][3]


# def create_empty_dataframe(columns, dtypes):
#     index = pd.Index([], name="id", dtype=int)
#     # column_names = ["name", "score", "height", "weight"]
#     # series = [pandas.Series(dtype=str), pandas.Series(dtype=int), pandas.Series(dtype=float), pandas.Series(dtype=float)]
#     series = [pd.Series(dtype=dtype) for dtype in dtypes]
#     data = dict(zip(columns, series))
#     return pd.DataFrame(data, index=index, columns=columns)

def create_empty_dataframe(index, columns):
    index = index if index is None else index[0:0]
    return pd.DataFrame([], index=index, columns=columns)


def fix_index_names(frame, exists_names: dict=None, repeatable: bool=True):
    exists_names = exists_names if exists_names is not None else get_exists_names(frame)
    new_index_names = []
    for i, index_name in enumerate(frame.index.names):
        if index_name is None or (not repeatable and exists_names.get(index_name, 0) > 1):
            index_name = f"i{i}" if index_name is None else f"{index_name}_i{i}"
            while index_name in exists_names:
                index_name += "__1"
            exists_names[index_name] = 1
        new_index_names.append(index_name)
    frame.index.set_names(names=new_index_names, inplace=True)
    return frame

def fix_column_names(frame, exists_names: dict=None, repeatable=True):
    exists_names = exists_names if exists_names is not None else get_exists_names(frame)
    new_col_names = []
    for i, col_name in enumerate(frame.columns):
        if col_name is None or (not repeatable and exists_names.get(col_name, 0) > 1):
            col_name = f"c{i}" if col_name is None else f"{col_name}_c{i}"
            while col_name in exists_names:
                col_name += "__1"
            exists_names[col_name] = 1
        new_col_names.append(col_name)
    frame.set_axis(new_col_names, inplace=True, axis=1)
    return frame

def fix_series_name(frame, exists_names: dict=None, repeatable: bool=True):
    exists_names = exists_names if exists_names is not None else get_exists_names(frame)
    series_name = frame.name
    if series_name is None or (not repeatable and exists_names.get(series_name, 0) > 1):
        series_name = f"c0" if series_name is None else f"{series_name}_c0"
        while series_name in exists_names:
            series_name += "__1"
        exists_names[series_name] = 1
    frame.name = series_name
    return frame

def get_exists_names(frame):
    exists_names = dict()
    for index_name in frame.index.names:
        exists_names[index_name] = exists_names.get(index_name, 0) + 1
    if isinstance(frame, pd.Series):
        col_name = frame.name
        exists_names[col_name] = exists_names.get(col_name, 0) + 1
    else:
        for col_name in frame.columns:
            exists_names[col_name] = exists_names.get(col_name, 0) + 1
    return exists_names

def fix_meta_names(frame, repeatable: bool=True):
    exists_names = get_exists_names(frame)
    fix_index_names(frame, exists_names, repeatable=repeatable)
    if isinstance(frame, pd.Series):
        fix_series_name(frame, exists_names, repeatable=repeatable)
    else:
        fix_column_names(frame, exists_names, repeatable=repeatable)
    return frame

def lower_or_upper_meta_names(meta:pd.DataFrame, func):
    if isinstance(meta, pd.Index):
        meta.set_names(names=list(map(func, meta.names)), inplace=True)
        return meta
    meta.index.set_names(names=list(map(func, meta.index.names)), inplace=True)
    if isinstance(meta, pd.Series):
        meta.name = func(meta.name)
    else: # DataFrame
        meta.set_axis(list(map(func, meta.columns)), inplace=True, axis=1)
    return meta

_simple_fake_mapping = {
    'b': np.bool_(True),
    'V': np.void(b' '),
    'M': np.datetime64('1970-01-01'),
    'm': np.timedelta64(1),
    'S': np.str_('foo'),
    'a': np.str_('foo'),
    'U': np.unicode_('foo'),
    'O': 'foo'
}


def _scalar_from_dtype(dtype):
    if dtype.kind in ('i', 'f', 'u'):
        return dtype.type(1)
    elif dtype.kind == 'c':
        return dtype.type(complex(1, 0))
    elif dtype.kind in _simple_fake_mapping:
        o = _simple_fake_mapping[dtype.kind]
        return o.astype(dtype) if dtype.kind in ('m', 'M') else o
    else:
        raise TypeError("Can't handle dtype: {0}".format(dtype))


def _nonempty_scalar(x):
    if isinstance(x, (pd.Timestamp, pd.Timedelta, pd.Period)):
        return x
    elif np.isscalar(x):
        dtype = x.dtype if hasattr(x, 'dtype') else np.dtype(type(x))
        return _scalar_from_dtype(dtype)
    else:
        raise TypeError("Can't handle meta of type "
                        "'{0}'".format(type(x).__name__))

UNKNOWN_CATEGORIES = '__UNKNOWN_CATEGORIES__'

def _empty_series(name, dtype, index=None):
    if isinstance(dtype, str) and dtype == 'category':
        return pd.Series(pd.Categorical([UNKNOWN_CATEGORIES]),
                         name=name, index=index).iloc[:0]
    return pd.Series([], dtype=dtype, name=name, index=index)


def make_meta(x, index=None):
    """Create an empty pandas object containing the desired metadata.

    Parameters
    ----------
    x : dict, tuple, list, pd.Series, pd.DataFrame, pd.Index, dtype, scalar
        To create a DataFrame, provide a `dict` mapping of `{name: dtype}`, or
        an iterable of `(name, dtype)` tuples. To create a `Series`, provide a
        tuple of `(name, dtype)`. If a pandas object, names, dtypes, and index
        should match the desired output. If a dtype or scalar, a scalar of the
        same dtype is returned.
    index :  pd.Index, optional
        Any pandas index to use in the metadata. If none provided, a
        `RangeIndex` will be used.

    Examples
    --------
    >>> make_meta([('a', 'i8'), ('b', 'O')])
    Empty DataFrame
    Columns: [a, b]
    Index: []
    >>> make_meta(('a', 'f8'))
    Series([], Name: a, dtype: float64)
    >>> make_meta('i8')
    1
    """
    if hasattr(x, '_meta'):
        return x._meta
    if isinstance(x, (pd.Series, pd.DataFrame)):
        return x.iloc[0:0]
    elif isinstance(x, pd.Index):
        return x[0:0]
    index = index if index is None else index[0:0]

    if isinstance(x, dict):
        return pd.DataFrame({c: _empty_series(c, d, index=index)
                             for (c, d) in x.items()}, index=index)
    if isinstance(x, tuple) and len(x) == 2:
        return _empty_series(x[0], x[1], index=index)
    elif isinstance(x, (list, tuple)):
        if not all(isinstance(i, tuple) and len(i) == 2 for i in x):
            raise ValueError("Expected iterable of tuples of (name, dtype), "
                             "got {0}".format(x))
        return pd.DataFrame({c: _empty_series(c, d, index=index) for (c, d) in x},
                            columns=[c for c, d in x], index=index)
    elif not hasattr(x, 'dtype') and x is not None:
        # could be a string, a dtype object, or a python type. Skip `None`,
        # because it is implictly converted to `dtype('f8')`, which we don't
        # want here.
        try:
            dtype = np.dtype(x)
            return _scalar_from_dtype(dtype)
        except Exception:
            # Continue on to next check
            pass

    if is_scalar(x):
        return _nonempty_scalar(x)

    raise TypeError("Don't know how to create metadata from {0}".format(x))
