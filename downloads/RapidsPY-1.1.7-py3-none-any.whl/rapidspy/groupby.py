
from rapidspy.base import Frame, new_rapidspy_object
from rapidspy.frame import DataFrame
from rapidspy.series import Series


class GroupByBase():

    def __init__(self, obj: Frame, by=None, sort=True):
        self.obj = obj
        if not isinstance(by, (tuple, list)):
            by = [by]
        self.by = by
        self.sort = sort
        # self.groupby_keys = ", ".join(self.by)

    def count(self):
        meta = self.obj._meta.groupby(self.by).count()
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="COUNT", sort=self.sort).groupby)
        return rdf

    def min(self):
        meta = self.obj._meta.groupby(self.by).min(numeric_only=True)
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="MIN", sort=self.sort).groupby)
        return rdf

    def max(self):
        meta = self.obj._meta.groupby(self.by).max(numeric_only=True)
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="MAX", sort=self.sort).groupby)
        return rdf

    def sum(self):
        meta = self.obj._meta.groupby(self.by).sum(numeric_only=True)
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="SUM", sort=self.sort).groupby)
        return rdf

    def mean(self):
        meta = self.obj._meta.groupby(self.by).mean(numeric_only=True)
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="MEAN", sort=self.sort).groupby)
        return rdf

    def nunique(self):
        meta = self.obj._meta.groupby(self.by).nunique()
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="NUNIQUE", sort=self.sort).groupby)
        return rdf

    def strjoin(self, symbol=","):
        if self.obj.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("not support API if you choose MOXE as Backend Engine.")
        meta = self.obj._meta.groupby(self.by).agg(lambda x: symbol.join(x)).drop(columns=self.by, errors="ignore")
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(func="STRJOIN", sort=self.sort, kwargs={'symbol': symbol}).groupby)
        return rdf

    def apply(self, **kwargs):
        for k in kwargs.keys():
            if k in self.by:
                raise ValueError(f"'{k}' can not be repeated with groupby keys.")
        pd_kwargs = {k: v._meta if isinstance(v, Frame) else v for k, v in kwargs.items()}
        meta = self.obj._meta.groupby(self.by).apply(lambda x: 1)
        meta = meta.assign(**pd_kwargs).loc[:, kwargs.keys()]
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(sort=self.sort, kwargs=kwargs).groupby_apply)
        return rdf


class SeriesGroupBy(GroupByBase):

    def apply(self, **kwargs):
        for k in kwargs.keys():
            if k in self.by:
                raise ValueError(f"'{k}' can not be repeated with groupby keys.")
        pd_kwargs = {k: v._meta if isinstance(v, Frame) else v for k, v in kwargs.items()}
        meta = self.obj._meta.groupby(self.by).apply(lambda x: 1)
        meta = meta.to_frame().assign(**pd_kwargs).loc[:, kwargs.keys()]
        rdf = new_rapidspy_object(meta, self.obj.backend_sql)
        rdf.put(dependencies=[self.obj], op=self.obj._create_method_instance(sort=self.sort, kwargs=kwargs).groupby_apply)
        return rdf


class DataFrameGroupBy(GroupByBase):
    
    pass
