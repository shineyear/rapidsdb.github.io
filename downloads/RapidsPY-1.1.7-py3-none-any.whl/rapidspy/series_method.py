from rapidspy.method import PostgresMethodBase, MoxeMethodBase, RapidsPYMethodBase


class SeriesMethodBase():

    _method = RapidsPYMethodBase.instance_base() # 默认值，要绑定对应数据库的method

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def create_ix(self, ns, rs):
        index_col = self.kwargs["index_col"]
        name = self.kwargs["name"]
        col_expression = self._method._create_table_ix(create_ix=True)
        if index_col:
            index = index_col if isinstance(index_col, list) else [index_col]
            change_map = {ns.index.names[i]: self._method._get_case_sensitive(index[i]) for i in range(ns.index.nlevels)}
        else:
            change_map = {ns.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=rs.index.names, change_map=change_map)

        if name is not None:
            change_map = {ns.name: self._method._get_case_sensitive(name)}
        else:
            change_map = {ns.name: self._method._get_case_sensitive(ns.name)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f'SELECT {col_expression} FROM "{rs.table}"' # 可能是用户的表
        return sql

    def nothing(self, ns, rs):
        sql = f"SELECT * FROM {rs.table}"
        return sql

    def len(self, sc, rs, no_select=False):
        if no_select:
            return "COUNT(*)"

        sql = f"SELECT COUNT(*) as c0 FROM {rs.table}"
        return sql

    # ----------------------------------------------------------------
    # Attributes
    # ----------------------------------------------------------------
    def index(self, ni, rs):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ni.names)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def empty(self, sc, rs):
        sql = f"SELECT COUNT(*) = 0 as c0 FROM {rs.table}"
        return sql

    # ----------------------------------------------------------------
    # Conversion
    # ----------------------------------------------------------------
    def astype(self, ns, rs):
        dtype = self.kwargs["dtype"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        sql_type = self._method._get_sql_type(dtype)
        change_map = {rs.name: f"cast({self._method._get_case_sensitive(rs.name)} as {sql_type})"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def copy(self, ns, rs):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def bool(self, sc, rs):
        sql = f"SELECT count(*) as c0 FROM {rs.table}"
        sql = f"SELECT c0 FROM {rs.table}"
        pass

    # ----------------------------------------------------------------
    # Indexing, iteration
    # ----------------------------------------------------------------
    def iat(self, sc, rs):
        iindexer = self.kwargs["iindexer"]
        col_expression = self._method._create_table_ci(out_ci=[rs.name], has_index=False)
        where_expression = f"ix = {iindexer}"
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    def iloc(self, ns, rs):
        iindexer = self.kwargs["iindexer"]
        where_expression = self._method._iloc_iindexer(rs, iindexer)
        col_expression = self._method._create_table_ix(create_ix=where_expression is not None)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    def loc(self, ns, rs):
        iindexer = self.kwargs["iindexer"]
        where_expression = self._method._loc_iindexer(rs, iindexer)
        col_expression  = self._method._create_table_ix(create_ix=where_expression is not None)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    # ----------------------------------------------------------------
    # Function application /
    # Groupby & Window
    # ----------------------------------------------------------------
    # def agg(self, ns, rs):
    #     func = self.kwargs["func"]
    #     col_expression = f"AVG(c0)"
    #     sql = f"SELECT {col_expression} FROM {rs.table}"
    #     return sql
    def agg(self, out, rs):
        func = self.kwargs["func"]
        if not isinstance(func, (list, tuple)): # 返回结果是Scalar
            func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
            col_expression = self._method._get_one_col("c0", func_exp)
            sql = f"SELECT {col_expression} from {rs.table}"
            return sql
        else:
            ns = out
            clauses = self._method._get_clauses_by_out_index(out_index=ns.index, out_ci=[rs.name], in1_dtypes={rs.name: rs.dtype}, in1_table=rs.table)
            sql = self._method._union_all(clauses)
        return sql

    def groupby(self, ns, rs):
        func = self.kwargs["func"]
        sort = self.kwargs["sort"]
        kwargs = self.kwargs.get("kwargs", {})
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func=func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype, **kwargs)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        gb_expression = self._method._get_groupby_expression(ns.index.names)
        if sort:
            ob_expression = self._method._get_orderby_expression(ns.index.names)
            sql = f"SELECT {col_expression} FROM {rs.table} GROUP BY {gb_expression} ORDER BY {ob_expression}"
        else:
            sql = f"SELECT {col_expression} FROM {rs.table} GROUP BY {gb_expression}"
        return sql

    def groupby_apply(self, ndf, rs):
        kwargs = self.kwargs["kwargs"]
        sort = self.kwargs["sort"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {k: rs._get_condition(v) for k, v in kwargs.items()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        gb_expression = self._method._get_groupby_expression(ndf.index.names)
        if sort:
            ob_expression = self._method._get_orderby_expression(ndf.index.names)
            sql = f"SELECT {col_expression} FROM {rs.table} GROUP BY {gb_expression} ORDER BY {ob_expression}"
        else:
            sql = f"SELECT {col_expression} FROM {rs.table} GROUP BY {gb_expression}"
        return sql

    # ----------------------------------------------------------------
    # Computations / 
    # Descriptive Stats
    # ----------------------------------------------------------------
    def count(self, sc, rs, no_select=False):
        func = "COUNT"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql
    
    def min(self, sc, rs, no_select=False):
        func = "MIN"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def max(self, sc, rs, no_select=False):
        func = "MAX"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def sum(self, sc, rs, no_select=False):
        func = "SUM"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def mean(self, sc, rs, no_select=False):
        func = "MEAN"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def median(self, sc, rs):
        # 无法实现no_select，因为无法自定义聚合函数
        col_name = self._get_case_sensitive(rs.name)
        table0 = f"{sc.table}_{0}"
        table1 = f"{sc.table}_{1}"
        table2 = f"{sc.table}_{2}"
        table3 = f"{sc.table}_{3}"
        sql = f"""with 
            {table0} as (select {col_name} as c0 from {rs.table} order by c0),
            {table1} as (select row_number() over() as ix, c0 from {table0}),
            {table2} as (select floor((count(*) + 1) / 2.0) as ix from {table1} union all select ceil((count(*) + 1) / 2.0) as ix from {table1}),
            {table3} as (select {table1}.c0 as c0 from {table2} left join {table1} on {table2}.ix = {table1}.ix)
            select SUM(c0) / 2.0 as c0 from {table3}
        """
        return sql

    def std(self, sc, rs, no_select=False):
        func = "STD"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def var(self, sc, rs, no_select=False):
        func = "VAR"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def all(self, sc, rs, no_select=False):
        # col_expression = self._method._get_if_expression("MIN(c0) != 0", "true", "false") + " as c0"
        func = "ALL"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def any(self, sc, rs, no_select=False):
        # col_expression = self._method._get_if_expression("MAX(c0) != 0", "true", "false") + " as c0"
        func = "ANY"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def is_unique(self, sc, rs, no_select=False):
        func = "IS_UNIQUE"
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql
    
    def nunique(self, sc, rs, no_select=False):
        # col_expression = f"count(distinct(c0)) as c0"
        func = "NUNIQUE"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def unique(self, sc, rs):
        # 返回的是array的标量
        # col_expression = f"distinct(c0) as c0"
        func = "UNIQUE"
        func_exp = self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        col_expression = self._method._get_one_col("c0", func_exp)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def abs(self, ns, rs, no_select=False):
        func="ABS"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype)
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def round(self, ns, rs, no_select=False):
        decimals = self.kwargs["decimals"]
        func="ROUND"
        if no_select:
            return self._method._get_func_expression(func, c='{fa_con}', dtype=rs.dtype, decimals=decimals)
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func, c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype, decimals=decimals)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def between(self, ns, rs):
        left = self.kwargs["left"]
        right = self.kwargs["right"]
        inclusive = self.kwargs["inclusive"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        if inclusive:
            left_op = "<="
            right_op = ">="
        else:
            left_op = "<"
            right_op = ">"
        change_map = {ns.name: self._method._get_if_expression(f"{left} {left_op} {self._method._get_case_sensitive(rs.name)} and {right} {right_op} {self._method._get_case_sensitive(rs.name)}", "true", "false")}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def filter(self, ns, rs):
        like = self.kwargs["like"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        where_expression = " or ".join([f"cast({self._method._get_case_sensitive(index_name)} as varchar) like '%%{like}%%'" for index_name in rs.index.names])
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    def describe(self, ns, rs):
        # TODO
        # func = ["COUNT(c{ci})", "AVG(c{ci})", "stddev_samp(c{ci})", "MIN(c{ci})", "percentile_disc(0.25) within group (order by c{ci})",
        #         "percentile_disc(0.5) within group (order by c{ci})", "percentile_disc(0.75) within group (order by c{ci})", "MAX(c{ci})"]
        # func = ["COUNT", "MEAN", "STD", "MIN", "PERCENTILE25", "PERCENTILE50", "PERCENTILE75", "MAX"]
        # col_exp_list = self._method._get_col_exp_list_by_out_name(ns, rs, func=func)
        # clauses = self._method._get_clauses(rs, col_exp_list)
        clauses = self._method._get_clauses_by_out_index(out_index=ns.index, out_ci=[rs.name], in1_dtypes={rs.name: rs.dtype}, in1_table=rs.table)
        sql = self._method._union_all(clauses)
        return sql

    def nsmallest(self, ns, rs):
        n = self.kwargs["n"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        ob_expression = self._method._get_orderby_expression([ns.name])
        clause = f"SELECT * FROM {rs.table} ORDER BY {ob_expression} LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    def nlargest(self, ns, rs):
        n = self.kwargs["n"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        ob_expression = self._method._get_orderby_expression([ns.name], desc=True)
        clause = f"SELECT * FROM {rs.table} ORDER BY {ob_expression} DESC LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    def value_counts(self, ns, rs):
        # series的values_counts方法会让列名保持原来的列名，但df会变成c0
        gb_expression = self._method._get_groupby_expression([rs.name])
        # col_expression = self._method._create_table_ix() # 这里不能创建ix
        col_expression = ""
        change_map = {ns.index.name: self._method._get_case_sensitive(rs.name)}
        col_expression += self._method._create_table_ii(out_ii=ns.index.names, change_map=change_map)
        change_map = {ns.name: "COUNT(*)"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        ob_expression = self._method._get_orderby_expression([ns.name])
        clause = f"SELECT {col_expression} FROM {rs.table} GROUP BY {gb_expression} ORDER BY {ob_expression} DESC"
        
        col_expression = self._method._create_table_ix(create_ix=True) + "*" # 必须要在排序之后create_ix
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def drop(self, ns, rs):
        labels = self.kwargs["labels"]
        axis = self.kwargs["axis"]
        index = self.kwargs["index"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        where_expression = ""
        if axis in [0, "index"]:
            index = index or labels
        if index:
            index = index if isinstance(index, (list, tuple)) else [index]
            index_exp = ", ".join(map(str, index))
            where_expression = "WHERE " + " and ".join([f"{self._method._get_case_sensitive(index_name)} not in ({index_exp})" for index_name in rs.index.names])
        sql = f"SELECT {col_expression} FROM {rs.table} {where_expression}"
        return sql

    def drop_duplicates(self, ns, rs):
        keep = self.kwargs["keep"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        gb_expression = self._method._get_groupby_expression([rs.name])
        if keep == "first":
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE ix in (SELECT min(ix) FROM {rs.table} GROUP BY {gb_expression})"
        elif keep == "last":
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE ix in (SELECT max(ix) FROM {rs.table} GROUP BY {gb_expression})"
        else:
            clause = f"SELECT {gb_expression} FROM {rs.table} GROUP BY {gb_expression} HAVING COUNT(*) = 1"
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE {gb_expression} in ({clause})"
        return sql

    def reset_index(self, ndf, rs):
        level = self.kwargs["level"]
        drop = self.kwargs["drop"] # 无需处理的参数
        col_expression  = self._method._create_table_ix()
        change_map = {}
        if isinstance(level, (list, tuple)):
            reset_index_count = len(level)
        elif level is not None:
            reset_index_count = 1
        else:
            reset_index_count = rs.index.nlevels
        if reset_index_count == rs.index.nlevels:
            change_map = {ndf.index.name: "ix"}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def sample(self, ns, rs):
        n = self.kwargs["n"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        clause = f"SELECT *, random() as c0 FROM {rs.table}, (SELECT setseed({seed})) {ns.table}_seed ORDER BY c0 LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    def head(self, ns, rs):
        n = self.kwargs["n"]
        # col_expression = "*"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        sql = f"SELECT {col_expression} FROM {rs.table} LIMIT {n}"
        return sql

    # ----------------------------------------------------------------
    # Missing data handling
    # ----------------------------------------------------------------
    def isnull(self, ns, rs):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func="ISNULL", c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql
    
    def notnull(self, ns, rs):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func="NOTNULL", c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def dropna(self, ns, rs):
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        where_expression = self._method._get_func_expression(func="NOTNULL", c=self._method._get_case_sensitive(rs.name), dtype=rs.dtype)
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    def fillna(self, ns, rs):
        value = self.kwargs["value"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_if_expression(f"{self._method._get_case_sensitive(ns.name)} is null", self._method._value_to_sql(value), ns.name)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)    
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def replace(self, ns, rs):
        to_replace = self.kwargs["to_replace"]
        value = self.kwargs["value"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        value = self._method._value_to_sql(value)
        to_replace = self._method._value_to_sql(to_replace)
        col = self._method._get_case_sensitive(rs.name)
        if to_replace == "null":
            change_map = {ns.name: self._method._get_if_expression(f"{col} is null", value, col)}
        else:
            change_map = {ns.name: self._method._get_if_expression(f"{col} = {to_replace}", value, col)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    # ----------------------------------------------------------------
    # Reshaping /
    # sorting /
    # transposing
    # ----------------------------------------------------------------
    def sort_values(self, ns, rs):
        ascending = self.kwargs["ascending"]
        
        col_expression = ""
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        ob_expression = self._method._get_orderby_expression(cols=[ns.name], desc=[not ascending])
        clause = f"SELECT {col_expression} FROM {rs.table} ORDER BY {ob_expression}"

        col_expression = self._method._create_table_ix(create_ix=True) + "*"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql
    
    def sort_index(self, ns, rs):
        level = self.kwargs["level"]
        ascending = self.kwargs["ascending"]
        col_expression = ""
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        if level is None:
            level = rs.index.names
        if not isinstance(level, (list, tuple)):
            level = [level]
        if not isinstance(ascending, (list, tuple)):
            ascending = [ascending] * len(level)
        ob_expression = self._method._get_orderby_expression(cols=level, desc=[not asc for asc in ascending])
        clause = f"SELECT {col_expression} FROM {rs.table} ORDER BY {ob_expression}"
        
        col_expression = self._method._create_table_ix(create_ix=True) + "*"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    # ----------------------------------------------------------------
    # Combining / joining / merging
    # ----------------------------------------------------------------
    def concat_by_index(self, ns, rs1, rs2):
        # 若不同名，也照样合并得到series
        ignore_index = self.kwargs["ignore_index"]
        col_expression = ""
        if not ignore_index:
            change_map = {ns.index.names[ii]: self._method._get_case_sensitive(rs1.index.names[ii]) for ii in range(ns.index.nlevels)}
        else:
            change_map = {ns.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ns.index.names, change_map=change_map)
        change_map = {ns.name: self._method._get_case_sensitive(rs1.name)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        clause1 = f"SELECT {col_expression} FROM {rs1.table}"
        
        col_expression = ""
        if not ignore_index:
            change_map = {ns.index.names[ii]: self._method._get_case_sensitive(rs2.index.names[ii]) for ii in range(ns.index.nlevels)}
        else:
            change_map = {ns.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ns.index.names, change_map=change_map)
        change_map = {ns.name: self._method._get_case_sensitive(rs2.name)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        clause2 = f"SELECT {col_expression} FROM {rs2.table}"
        
        clause3 = self._method._union_all([clause1, clause2], sort=False)
        col_expression = self._method._create_table_ix(create_ix=True)
        if not ignore_index:
            col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        else:
            change_map = {ns.index.name: self._method._get_row_number_expression()}
            col_expression += self._method._create_table_ii(out_ii=ns.index.names, change_map=change_map)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        sql = f"SELECT {col_expression} FROM ({clause3}) {ns.table}_tmp"
        return sql

    def concat_by_ix(self, ndf, rs1, rs2):
        col_expression = self._method._create_table_ix(create_ix=True)
        change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        change_map = {}
        for i, col_name in enumerate(ndf.columns.to_list()):
            if i == 0:
                change_map[col_name] = self._method._get_case_sensitive(col=rs1.name, table=rs1.table)
            else:
                change_map[col_name] = self._method._get_case_sensitive(col=rs2.name, table=rs2.table)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs1.table} FULL JOIN {rs2.table} ON {rs1.table}.ix = {rs2.table}.ix"
        return sql

    # ----------------------------------------------------------------
    # Accessors
    # ----------------------------------------------------------------
    def datetime(self, ns, rs, no_select=False):
        func = self.kwargs["func"]
        if no_select:
            return self._method._get_datetime_expression(func)
        
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_datetime_expression(func).format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def str_len(self, ns, rs, no_select=False):
        if no_select:
            return "char_length({fa_con})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "char_length({fa_con})".format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def lower(self, ns, rs, no_select=False):
        if no_select:
            return "lower({fa_con})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "lower({fa_con})".format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def upper(self, ns, rs, no_select=False):
        if no_select:
            return "upper({fa_con})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "upper({fa_con})".format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def strip(self, ns, rs, no_select=False):
        to_strip = self.kwargs["to_strip"]
        to_strip = to_strip if to_strip is not None else " "
        to_strip = self._method._value_to_sql(to_strip)
        if no_select:
            return f"trim(both {to_strip} from " + "{fa_con})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: f"trim(both {to_strip} from " + "{fa_con})".format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def lstrip(self, ns, rs, no_select=False):
        to_strip = self.kwargs["to_strip"]
        to_strip = to_strip if to_strip is not None else " "
        to_strip = self._method._value_to_sql(to_strip)
        if no_select:
            return "ltrim({fa_con}, " + f"{to_strip})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "ltrim({fa_con}, ".format(fa_con=self._method._get_case_sensitive(rs.name)) + f"{to_strip})"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def rstrip(self, ns, rs, no_select=False):
        to_strip = self.kwargs["to_strip"]
        to_strip = to_strip if to_strip is not None else " "
        to_strip = self._method._value_to_sql(to_strip)
        if no_select:
            return "rtrim({fa_con}, " + f"{to_strip})"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "rtrim({fa_con}, ".format(fa_con=self._method._get_case_sensitive(rs.name)) + f"{to_strip})"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def slice(self, ns, rs, no_select=False):
        start = self.kwargs["start"] or 0
        stop = self.kwargs["stop"]
        step = self.kwargs["step"] # 只能等于1
        if no_select:
            return self._method._get_func_expression(func="SLICE", c="{fa_con}", dtype=None, start=start, stop=stop, step=step)
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func="SLICE", c="{fa_con}", dtype=None, start=start, stop=stop, step=step).format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def split_part(self, ns, rs, no_select=False):
        pat = self.kwargs["pat"]
        n = self.kwargs["n"]
        if no_select:
            return self._method._get_func_expression(func="SPLIT_PART", c="{fa_con}", dtype=None, pat=pat, n=n)
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_func_expression(func="SPLIT_PART", c="{fa_con}", dtype=None, pat=pat, n=n).format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def find(self, ns, rs, no_select=False):
        sub = self.kwargs["sub"]
        start = self.kwargs["start"]
        end = self.kwargs["end"]
        sub = self._method._value_to_sql(sub)
        substring = self._method._get_func_expression(func="SLICE", c="{fa_con}", dtype=None, start=start, stop=end, step=1)
        if no_select:
            return f"position({sub} in " + f"{substring}) - 1"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: f"position({sub} in " + f"{substring}) - 1".format(fa_con=self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def startswith(self, ns, rs, no_select=False):
        pat = self.kwargs["pat"]
        pat = self._method._value_to_sql(pat)
        if no_select:
            return "left({fa_con}, " + f"char_length({pat})) = {pat}"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "left({fa_con}, ".format(fa_con=self._method._get_case_sensitive(rs.name)) + f"char_length({pat})) = {pat}"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def endswith(self, ns, rs, no_select=False):
        pat = self.kwargs["pat"]
        pat = self._method._value_to_sql(pat)
        if no_select:
            return "right({fa_con}, " + f"char_length({pat})) = {pat}"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "right({fa_con}, ".format(fa_con=self._method._get_case_sensitive(rs.name)) + f"char_length({pat})) = {pat}"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    # ----------------------------------------------------------------
    # Binary Operator functions
    # ----------------------------------------------------------------
    """
    四则算支持的操作类型有很多，比如，单值，list，tuple，Series等
    当操作是Series时，如果index完全相等，则会按行进行运算，否则将先进行merge操作，然后运算

    当操作是Series时，将其列为了强相关性，也就是双父亲节点，这点与getitem和loc不同。

    当操作数是Scalar时，目前会将其单独计算出来，然后再运算，效率不高
    """
    def _get_arithemetic_sql(self, ns, rs):
        rs = rs.fa
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: rs._get_condition(ns)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} from {rs.table}"
        return sql

    def neg(self, ns, rs, no_select=False):
        if no_select:
            return "-{fa_con}"
        return self._get_arithemetic_sql(ns, rs)

    def add(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            if ns.dtype != "object":
                return "{fa_con}" + f" + {other}"
            else:
                return "cast({fa_con} as varchar)" + f" || cast({other} as varchar)"
        return self._get_arithemetic_sql(ns, rs)

    def sub(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "{fa_con}" + f" - {other}"
        return self._get_arithemetic_sql(ns, rs)

    def mul(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "{fa_con}" + f" * {other}"
        return self._get_arithemetic_sql(ns, rs)

    def truediv(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "cast({fa_con} as float)" + f" / {other}"
        return self._get_arithemetic_sql(ns, rs)

    def floordiv(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "floor(cast({fa_con} as float)" + f" / {other})"
        return self._get_arithemetic_sql(ns, rs)

    def mod(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "{fa_con}" + f" % {other}"
        return self._get_arithemetic_sql(ns, rs)

    def pow(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "{fa_con}" + f" ^ {other}"
        return self._get_arithemetic_sql(ns, rs)

    def radd(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            if ns.dtype != "object":
                return f"{other} + " + "{fa_con}"
            else:
                return f"cast({other} as varchar) || " + "cast({fa_con} as varchar)"
        return self._get_arithemetic_sql(ns, rs)

    def rsub(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"{other} -" + " {fa_con}"
        return self._get_arithemetic_sql(ns, rs)

    def rmul(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"{other} * " + "{fa_con}"
        return self._get_arithemetic_sql(ns, rs)

    def rtruediv(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"{other} / " + "cast({fa_con} as float)"
        return self._get_arithemetic_sql(ns, rs)

    def rfloordiv(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"floor({other} / " + "cast({fa_con} as float))"
        return self._get_arithemetic_sql(ns, rs)

    def rmod(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"{other} % " + "{fa_con}"
        return self._get_arithemetic_sql(ns, rs)

    def rpow(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"{other} ^ " + "{fa_con}"
        return self._get_arithemetic_sql(ns, rs)

    def lt(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" < {key}"
        return self._get_arithemetic_sql(ns, rs)

    def le(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" <= {key}"
        return self._get_arithemetic_sql(ns, rs)
    
    def gt(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" > {key}"
        return self._get_arithemetic_sql(ns, rs)
    
    def ge(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" >= {key}"
        return self._get_arithemetic_sql(ns, rs)

    def eq(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            if key == "null":
                return "{fa_con} is null"
            return "{fa_con}" + f" = {key}"
        return self._get_arithemetic_sql(ns, rs)

    def ne(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            if key == "null":
                return "{fa_con} is not null"
            return "{fa_con}" + f" != {key}"
        return self._get_arithemetic_sql(ns, rs)

    def and_(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" and {key}"
        return self._get_arithemetic_sql(ns, rs)

    def or_(self, ns, rs, no_select=False):
        key = self.kwargs["key"]
        key = self._method._value_to_sql(key)
        if no_select:
            return "{fa_con}" + f" or {key}"
        return self._get_arithemetic_sql(ns, rs)

    def _get_arithemetic2_sql(self, ns, left, right):
        src = left.fa if left.fa is right.fa else left.dependencies[0]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: src._get_condition(ns)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {src.table}"
        return sql

    def add2(self, ns, left, right, no_select=False):
        if no_select:
            if ns.dtype != "object":
                return "{l_con} + {r_con}"
            else:
                return "cast({l_con} as varchar) || cast({r_con} as varchar)"
        return self._get_arithemetic2_sql(ns, left, right)

    def sub2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} - {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def mul2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} * {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def truediv2(self, ns, left, right, no_select=False):
        if no_select:
            return "cast({l_con} as float) / {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def floordiv2(self, ns, left, right, no_select=False):
        if no_select:
            return "floor(cast({l_con} as float) / {r_con})"
        return self._get_arithemetic2_sql(ns, left, right)

    def mod2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} % {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def pow2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} ^ {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def radd2(self, ns, left, right, no_select=False):
        if no_select:
            if ns.dtype != "object":
                return "{r_con} + {l_con}"
            else:
                return "cast({r_con} as varchar) || cast({l_con} as varchar)"
        return self._get_arithemetic2_sql(ns, left, right)

    def rsub2(self, ns, left, right, no_select=False):
        if no_select:
            return "{r_con} - {l_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def rmul2(self, ns, left, right, no_select=False):
        if no_select:
            return "{r_con} * {l_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def rtruediv2(self, ns, left, right, no_select=False):
        if no_select:
            return "cast({r_con} as float) / {l_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def rfloordiv2(self, ns, left, right, no_select=False):
        if no_select:
            return "floor(cast({r_con} as float) / {l_con})"
        return self._get_arithemetic2_sql(ns, left, right)

    def rmod2(self, ns, left, right, no_select=False):
        if no_select:
            return "{r_con} % {l_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def rpow2(self, ns, left, right, no_select=False):
        if no_select:
            return "{r_con} ^ {l_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def lt2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} < {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def le2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} <= {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def gt2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} > {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def ge2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} >= {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def eq2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} = {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def ne2(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} != {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def and2_(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} and {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    def or2_(self, ns, left, right, no_select=False):
        if no_select:
            return "{l_con} or {r_con}"
        return self._get_arithemetic2_sql(ns, left, right)

    # ----------------------------------------------------------------
    # General
    # ----------------------------------------------------------------
    def cut(self, ns, rs, no_select=False):
        bins = self.kwargs["bins"]
        labels = self.kwargs["labels"]
        if no_select:
            return self._method._get_case_expression("{fa_con}", bins, labels)
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: self._method._get_case_expression(self._method._get_case_sensitive(rs.name), bins, labels)}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def to_datetime(self, ns, rs, no_select=False):
        # format = self.kwargs["format"]
        # format = format.replace("%", "%%")
        if no_select:
            return "cast({fa_con} as timestamp)"
            # return "to_timestamp({fa_con}, " + f"'{format}')"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        # col_expression += ", " + f"to_timestamp(c0, '{format}')" + " as c0"
        change_map = {ns.name: f"cast({self._method._get_case_sensitive(rs.name)} as timestamp)"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    # ----------------------------------------------------------------
    # For AIworkflow
    # ----------------------------------------------------------------
    def iloc_setitem(self, ns, rs):
        value = self.kwargs["value"]
        iindexer = self.kwargs["iindexer"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        
        value = self._method._value_to_sql(value)
        condition = self._method._iloc_iindexer(in1=rs, iindexer=iindexer)
        change_map = {ns.name: self._method._get_if_expression(condition, value, self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def loc_setitem(self, ns, rs):
        value = self.kwargs["value"]
        iindexer = self.kwargs["iindexer"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)

        value = self._method._value_to_sql(value)
        condition = self._method._loc_iindexer(in1=rs, iindexer=iindexer)
        change_map = {ns.name: self._method._get_if_expression(condition, value, self._method._get_case_sensitive(rs.name))}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rs.table}"
        return sql

    def filter_by_conditions(self, ns, rs):
        conditions = self.kwargs["conditions"]
        conjunction = self.kwargs["conjunction"]
        mask = self.kwargs["mask"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        where_list = []
        for condition in conditions:
            c = condition[0]
            op = condition[1]
            value = self._method._value_to_sql(condition[2])
            if value == "null":
                if op == "=":
                    op = "is"
                elif op == "!=":
                    op = "is not"
            wh_exp = f"{c} {op} {value}"
            if mask:
                wh_exp = f"not {wh_exp}"
            where_list.append(wh_exp)
        where_expression = (" "+ conjunction + " ").join(where_list)
        sql = f"SELECT {col_expression} FROM {rs.table} WHERE {where_expression}"
        return sql

    def random_split(self, ns, rs):
        rate = self.kwargs["rate"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        clause = f"SELECT *, random() as c0 FROM {rs.table}, (SELECT setseed({seed})) {ns.table}_seed ORDER BY c0 LIMIT floor((SELECT COUNT(*) FROM {rs.table}) * {rate})"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    def random_split2(self, ns, rs):
        rate = self.kwargs["rate"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        clause = f"SELECT *, random() as c0 FROM {rs.table}, (SELECT setseed({seed})) {ns.table}_seed ORDER BY c0 DESC LIMIT ceil((SELECT COUNT(*) FROM {rs.table}) * {1 - rate})"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    def save_duplicates(self, ns, rs):
        keep = self.kwargs["keep"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        col_expression += self._method._create_table_ci(out_ci=[ns.name])
        gb_expression = self._method._get_groupby_expression(cols=[rs.name])
        if keep == "first":
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE ix in (SELECT min(ix) FROM {rs.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1)"
        elif keep == "last":
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE ix in (SELECT max(ix) FROM {rs.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1)"
        else:
            clause = f"SELECT {gb_expression} FROM {rs.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1"
            sql = f"SELECT {col_expression} FROM {rs.table} WHERE {gb_expression} in ({clause})"
        return sql


class PostgresSeriesMethod(SeriesMethodBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._method = PostgresMethodBase.instance()


class MoxeSeriesMethod(SeriesMethodBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._method = MoxeMethodBase().instance()
        

    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def pow(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return "POWER({fa_con}" + f", {other})"
        return self._get_arithemetic_sql(ns, rs)

    def pow2(self, ns, left, right, no_select=False):
        if no_select:
            return "POWER({l_con}, {r_con})"
        return self._get_arithemetic2_sql(ns, left, right)

    def rpow(self, ns, rs, no_select=False):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if no_select:
            return f"POWER({other}" + ", {fa_con})"
        return self._get_arithemetic_sql(ns, rs)

    def rpow2(self, ns, left, right, no_select=False):
        if no_select:
            return "POWER({r_con}, {l_con})"
        return self._get_arithemetic2_sql(ns, left, right)
