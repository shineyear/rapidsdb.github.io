from rapidspy.method import PostgresMethodBase, MoxeMethodBase, RapidsPYMethodBase
from rapidspy.frame import DataFrame
from rapidspy.series import Series


class FrameMethodBase():

    _method = RapidsPYMethodBase.instance_base() # 默认值，要绑定对应数据库的method

    def __init__(self, **kwargs):
        self.kwargs = kwargs

    def create_ix(self, ndf, rdf):
        index_col = self.kwargs["index_col"]
        columns = self.kwargs["columns"]
        col_expression = self._method._create_table_ix(create_ix=True)
        if index_col:
            index = index_col if isinstance(index_col, list) else [index_col]        
            change_map = {ndf.index.names[i]: self._method._get_case_sensitive(index[i]) for i in range(ndf.index.nlevels)}
        else:
            change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        
        if columns is not None:
            change_map = {ndf.columns[i]: self._method._get_case_sensitive(columns[i]) for i in range(len(ndf.columns))}
        else:
            change_map = {ndf.columns[i]: self._method._get_case_sensitive(ndf.columns[i]) for i in range(len(ndf.columns))}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f'SELECT {col_expression} FROM "{rdf.table}"' # 可能是用户的表
        return sql

    def nothing(self, ndf, rdf):
        sql = f"SELECT * FROM {rdf.table}"
        return sql

    def len(self, sc, rdf, no_select=False):
        if no_select:
            return "COUNT(*)"
        # change_map = {"c0": "COUNT(*)"}
        # col_expression = self._method._create_table_ci(out_ci=["c0"], change_map=change_map)
        sql = f"SELECT COUNT(*) as c0 FROM {rdf.table}"
        return sql

    # ----------------------------------------------------------------
    # Attributes
    # ----------------------------------------------------------------
    def index(self, ni, rdf):
        col_expression = self._method._create_table_ix()
        col_expression = self._method._create_table_ii(out_ii=ni.names)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def size(self, sc, rdf):
        sql = f"SELECT COUNT(*) * {len(rdf.columns)} as c0 FROM {rdf.table}"
        return sql

    def empty(self, sc, rdf):
        sql = f"SELECT COUNT(*) = 0 as c0 FROM {rdf.table}"
        return sql

    # ----------------------------------------------------------------
    # Conversion
    # ----------------------------------------------------------------
    def astype(self, ndf, rdf):
        dtype = self.kwargs["dtype"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)

        dtypes = dtype if isinstance(dtype, dict) else {col_name: dtype for col_name in rdf.columns}
        change_map = {}
        for col_name, dtype in dtypes.items():
            sql_type = self._method._get_sql_type(dtype)
            change_map[col_name] = f"cast({self._method._get_case_sensitive(col_name)} as {sql_type})"
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def copy(self, ndf, rdf):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def bool(self, sc, rdf):
        pass

    # ----------------------------------------------------------------
    # Indexing, Iteration
    # ----------------------------------------------------------------
    def iat(self, sc, rdf):
        iindexer = self.kwargs["iindexer"]
        cindexer = self.kwargs["cindexer"]
        col_expression = self._method._create_table_ci(out_ci=[rdf.columns[cindexer]], has_index=False)
        where_expression = f"ix = {iindexer}"
        sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        return sql

    def iloc(self, out, rdf):
        """
        iindexer: int, list, slice, slice(None)
        cindexer: int, list, slice, slice(None), None
        """
        iindexer = self.kwargs["iindexer"]
        cindexer = self.kwargs["cindexer"]
        where_expression = self._method._iloc_iindexer(rdf, iindexer)
        col_expression = self._method._create_table_ix(create_ix=where_expression is not None)
        col_expression += self._method._create_table_ii(out_ii=out.index.names)
        if isinstance(out, DataFrame):
            col_expression += self._method._create_table_ci(out_ci=out.columns.to_list())
        elif isinstance(out, Series):
            col_expression += self._method._create_table_ci(out_ci=[out.name])
        sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        return sql
    
    def loc(self, out, rdf):
        """
        暂只支持单一index
        iinedeer不支持slice
        iindexer: int, str, list, slice(None), Series
        cindexer: int, str, list, slice(None), slice, None
        """
        iindexer = self.kwargs["iindexer"]
        cindexer = self.kwargs["cindexer"]
        where_expression = self._method._loc_iindexer(rdf, iindexer)
        col_expression = self._method._create_table_ix(create_ix=where_expression is not None)
        col_expression += self._method._create_table_ii(out_ii=out.index.names)
        if isinstance(out, DataFrame):
            col_expression += self._method._create_table_ci(out_ci=out.columns.to_list())
        elif isinstance(out, Series):
            col_expression += self._method._create_table_ci(out_ci=[out.name])
        sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        return sql

    # def getitemby(self, ndf, rdf):
    #     key = self.kwargs["key"]
    #     col_expression = self._method._create_table_ix(ndf, rdf)
    #     col_expression += ", ".join([f"i{ii}" for ii in range(rdf.index.nlevels)]) + ", "
    #     ci = rdf.columns.get_loc(key)
    #     col_expression += f"c{ci} as c0"
    #     sql = f"SELECT {col_expression} FROM {rdf.table}"
    #     return sql

    # def getitem(self, ndf, rdf):
    #     rs = self.kwargs["rs"]
    #     condition = rs.condition
    #     sql = f"SELECT * FROM {rdf.table} WHERE {condition}"
    #     return sql

    # ----------------------------------------------------------------
    # Function application,
    # Groupby & Window
    # ----------------------------------------------------------------
    def agg(self, out, rdf):
        func = self.kwargs["func"]
        # if not isinstance(func, (list, tuple)): 
        if isinstance(out, Series):
            ns = out
            clauses = self._method._get_clauses_by_func(ns, rdf, func=func)
        else: # 放回结果是Dataframe
            ndf = out
            clauses = self._method._get_clauses_by_out_index(out_index=ndf.index, out_ci=rdf.columns.to_list(), in1_dtypes=rdf.dtypes, in1_table=rdf.table)
            
        # if isinstance(ndf._meta, pd.DataFrame):
        #     col_exp_list = self._method._get_col_exp_list_by_out_index(ndf, rdf, func=func)
        # else:
        #     col_exp_list = self._method._get_col_exp_list_by_out_name(ndf, rdf, func=func)
        # clauses = self._method._get_clauses(rdf, col_exp_list)
        sql = self._method._union_all(clauses)
        return sql

    def groupby(self, ndf, rdf):
        func = self.kwargs["func"]
        sort = self.kwargs["sort"]
        kwargs = self.kwargs.get("kwargs", {})
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_func_expression(func=func, c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name], **kwargs) for col_name in ndf.columns}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        gb_expression = self._method._get_groupby_expression(ndf.index.names)
        if sort:
            ob_expression = self._method._get_orderby_expression(ndf.index.names)
            sql = f"SELECT {col_expression} FROM {rdf.table} GROUP BY {gb_expression} ORDER BY {ob_expression}"
        else:
            sql = f"SELECT {col_expression} FROM {rdf.table} GROUP BY {gb_expression}"
        return sql

    def groupby_apply(self, ndf, rdf):
        kwargs = self.kwargs["kwargs"]
        sort = self.kwargs["sort"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {k: rdf._get_condition(v) for k, v in kwargs.items()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        gb_expression = self._method._get_groupby_expression(ndf.index.names)
        if sort:
            ob_expression = self._method._get_orderby_expression(ndf.index.names)
            sql = f"SELECT {col_expression} FROM {rdf.table} GROUP BY {gb_expression} ORDER BY {ob_expression}"
        else:
            sql = f"SELECT {col_expression} FROM {rdf.table} GROUP BY {gb_expression}"
        return sql

    # ----------------------------------------------------------------
    # Computations / 
    # Descriptive Stats
    # ----------------------------------------------------------------
    def count(self, ns, rdf):
        # func = "COUNT(c{ci})"
        func = "COUNT"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql
    
    def min(self, ns, rdf):
        # func = "MIN(c{ci})"
        func = "MIN"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def max(self, ns, rdf):
        # func = "MAX(c{ci})"
        func = "MAX"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def sum(self, ns, rdf):
        # func = "SUM(cast(c{ci} as integer))"
        func = "SUM"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def mean(self, ns, rdf):
        # func = "SUM(c{ci}) * 1.0 / COUNT(c{ci})"
        func = "MEAN"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def median(self, ns, rdf):
        sql = self._method._get_median_sql(ns, rdf)
        return sql

    def std(self, ns, rdf):
        # col_exp_list = [(f"'{col_name}' as i0", f"stddev_samp(c{ci}) as c0") for ci, col_name in enumerate(rdf.columns)]
        # func = "stddev_samp(c{ci})"
        func = "STD"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def var(self, ns, rdf):
        # func = "var_samp(c{ci})"
        func = "VAR"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def all(self, ns, rdf):
        # func = self._method._get_if_expression("MIN(c{ci}) != 0", "true", "false")
        func = "ALL"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def any(self, ns, rdf):
        # func = self._method._get_if_expression("MAX(c{ci}) != 0", "true", "false")
        func = "ANY"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def nunique(self, ns, rdf):
        # func = "COUNT(distinct(c{ci}))"
        func = "NUNIQUE"
        clauses = self._method._get_clauses_by_func(ns, rdf, func)
        sql = self._method._union_all(clauses)
        return sql

    def abs(self, ndf, rdf):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_func_expression(func="ABS", c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name]) for col_name in ndf.columns}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def round(self, ndf, rdf):
        decimals = self.kwargs["decimals"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_func_expression(func="ROUND", c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name], decimals=decimals) for col_name in ndf.columns}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def filter(self, ndf, rdf):
        items = self.kwargs["items"]
        like = self.kwargs["like"]
        axis = self.kwargs["axis"]
        if axis in [0, "index"]:
            col_expression = self._method._create_table_ix(create_ix=True)
            col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
            col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
            if items:
                items_str = ", ".join(items)
                where_expression = " or ".join([f"{self._method._get_case_sensitive(index_name)} in ({items_str})" for index_name in rdf.index.names])
            else:
                where_expression = " or ".join([f"cast({self._method._get_case_sensitive(index_name)} as varchar) like '%%{like}%%'" for index_name in rdf.index.names])
            sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        else:
            col_expression = self._method._create_table_ix()
            col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
            col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
            sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def describe(self, ndf, rdf):
        # func = ["COUNT(c{ci})", "AVG(c{ci})", "stddev_samp(c{ci})", "MIN(c{ci})", "percentile_disc(0.25) within group (order by c{ci})",
        #         "percentile_disc(0.5) within group (order by c{ci})", "percentile_disc(0.75) within group (order by c{ci})", "MAX(c{ci})"]
        # func = ["COUNT", "MEAN", "STD", "MIN", "PERCENTILE25", "PERCENTILE50", "PERCENTILE75", "MAX"]
        # col_exp_list = self._method._get_col_exp_list_by_out_index(ndf, rdf, func=func)
        # clauses = self._method._get_clauses(rdf, col_exp_list)
        clauses = self._method._get_clauses_by_out_index(out_index=ndf.index, out_ci=rdf.columns.to_list(), in1_dtypes=rdf.dtypes, in1_table=rdf.table)
        sql = self._method._union_all(clauses)
        return sql

    def nsmallest(self, ndf, rdf):
        n = self.kwargs["n"]
        columns = self.kwargs["columns"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        ob_expression = self._method._get_orderby_expression(columns)
        clause = f"SELECT * FROM {rdf.table} ORDER BY {ob_expression} LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def nlargest(self, ndf, rdf):
        n = self.kwargs["n"]
        columns = self.kwargs["columns"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        ob_expression = self._method._get_orderby_expression(columns, desc=True)
        clause = f"SELECT * FROM {rdf.table} ORDER BY {ob_expression} LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def value_counts(self, ns, rdf):
        gb_expression = self._method._get_groupby_expression(cols=rdf.columns.to_list())
        col_expression = ""
        col_expression += self._method._create_table_ii(out_ii=ns.index.names)
        change_map = {ns.name: "COUNT(*)"}
        col_expression += self._method._create_table_ci(out_ci=[ns.name], change_map=change_map)
        ob_expression = self._method._get_orderby_expression(cols=[ns.name], desc=True)
        clause = f"SELECT {col_expression} FROM {rdf.table} GROUP BY {gb_expression} ORDER BY {ob_expression}"
        
        col_expression = self._method._create_table_ix(create_ix=True) + "*"
        sql = f"SELECT {col_expression} FROM ({clause}) {ns.table}_tmp"
        return sql

    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def drop(self, ndf, rdf):
        labels = self.kwargs["labels"]
        axis = self.kwargs["axis"]
        index = self.kwargs["index"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        where_expression = ""
        if axis in [0, "index"]:
            index = labels or index
        if index:
            index = index if isinstance(index, (list, tuple)) else [index]
            index_exp = ", ".join(map(str, index))
            where_expression = "WHERE " + " and ".join([f"{self._method._get_case_sensitive(index_name)} not in ({index_exp})" for index_name in rdf.index.names])
        sql = f"SELECT {col_expression} FROM {rdf.table} {where_expression}"
        return sql

    def drop_duplicates(self, ndf, rdf):
        subset = self.kwargs["subset"]
        keep = self.kwargs["keep"]
        subset = subset if subset is not None else rdf.columns.to_list()
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: f"{rdf.table}.{col_name} "for col_name in subset}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        gb_expression = self._method._get_groupby_expression(cols=subset)
        if keep == "first":
            sql = f"SELECT {col_expression} FROM {rdf.table} WHERE ix in (SELECT min(ix) FROM {rdf.table} GROUP BY {gb_expression})"
        elif keep == "last":
            sql = f"SELECT {col_expression} FROM {rdf.table} WHERE ix in (SELECT max(ix) FROM {rdf.table} GROUP BY {gb_expression})"
        else:
            # clause = f"SELECT {gb_expression} FROM (SELECT {gb_expression}, COUNT(*) as {ndf.table}_cnt FROM {rdf.table} GROUP BY {gb_expression}) {ndf.table}_tmp1 WHERE {ndf.table}_cnt > 1"
            clause = f"SELECT {gb_expression} FROM {rdf.table} GROUP BY {gb_expression} HAVING COUNT(*) = 1"
            on_expression = f" and ".join([f"{self._method._get_case_sensitive(col_name, table=rdf.table)} = {self._method._get_case_sensitive(col_name, f'{ndf.table}_tmp')}" for col_name in subset])
            where_expression = " or ".join(f"{self._method._get_case_sensitive(col_name, table=f'{ndf.table}_tmp')} is not null" for col_name in subset)
            sql = f"SELECT {col_expression} FROM {rdf.table} LEFT JOIN ({clause}) {ndf.table}_tmp ON {on_expression} WHERE {where_expression}"
        return sql

    def reset_index(self, ndf, rdf):
        level = self.kwargs["level"]
        drop = self.kwargs["drop"] # 无需处理的参数
        col_expression = self._method._create_table_ix()
        change_map = {}
        if isinstance(level, (list, tuple)):
            reset_index_count = len(level)
        elif level is not None:
            reset_index_count = 1
        else:
            reset_index_count = rdf.index.nlevels
        if reset_index_count == rdf.index.nlevels:
            change_map = {ndf.index.name: "ix"}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def set_index(self, ndf, rdf):
        # keys 暂不接受用户提供的array作为index
        keys = self.kwargs["keys"]
        drop = self.kwargs["drop"]
        append = self.kwargs["append"]
        col_expression = self._method._create_table_ix()
        if not isinstance(keys, (list, tuple)):
            keys = [keys]
        offset = rdf.index.nlevels if append else 0
        change_map = {ndf.index.names[offset + i]: self._method._get_case_sensitive(index_name) for i, index_name in enumerate(keys)}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def rename(self, ndf, rdf):
        columns = self.kwargs["columns"]
        change_map = {}
        for k, v in columns.items():
            change_map[v] = k
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {ndf.columns[i]: self._method._get_case_sensitive(rdf.columns[i]) for i in range(len(ndf.columns))}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def sample(self, ndf, rdf):
        n = self.kwargs["n"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        clause = f"SELECT *, random() as c0 FROM {rdf.table}, (SELECT setseed({seed})) {ndf.table}_seed ORDER BY c0 LIMIT {n}"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def head(self, ndf, rdf):
        n = self.kwargs["n"]
        # col_expression = "*"
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rdf.table} LIMIT {n}"
        return sql

    def tail(self, ndf, rdf):
        n = self.kwargs["n"]
        rows_count = self.kwargs["rows_count"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM {rdf.table} OFFSET {rows_count-n} LIMIT {n}"
        return sql

    # ----------------------------------------------------------------
    # Missing data handling
    # ----------------------------------------------------------------
    def isnull(self, ndf, rdf):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_func_expression(func="ISNULL", c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name]) for col_name in ndf.columns}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql
    
    def notnull(self, ndf, rdf):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_func_expression(func="NOTNULL", c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name]) for col_name in ndf.columns}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def dropna(self, ndf, rdf):
        how = self.kwargs["how"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        conjunction = " and " if how == "any" else " or "
        where_expression = conjunction.join([self._method._get_func_expression(func="NOTNULL", c=self._method._get_case_sensitive(col_name), dtype=rdf.dtypes[col_name]) for col_name in rdf.columns])
        sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        return sql

    def fillna(self, ndf, rdf):
        value = self.kwargs["value"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        if not isinstance(value, dict):
            value = {col_name: value for col_name in rdf.columns}
        change_map = {col_name: self._method._get_if_expression(f"{self._method._get_case_sensitive(col_name)} is null", self._method._value_to_sql(value[col_name]), self._method._get_case_sensitive(col_name)) for col_name in ndf.columns if col_name in value}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)    
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def replace(self, ndf, rdf):
        to_replace = self.kwargs["to_replace"]
        value = self.kwargs["value"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {}
        value = self._method._value_to_sql(value)
        for col_name, to_replace_value in to_replace.items():
            to_replace_value = self._method._value_to_sql(to_replace_value)
            col = self._method._get_case_sensitive(col_name)
            if to_replace_value == "null":
                change_map[col_name] = self._method._get_if_expression(f"{col} is null", value, col)
            else:
                change_map[col_name] = self._method._get_if_expression(f"{col} = {to_replace_value}", value, col)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    # ----------------------------------------------------------------
    # Reshaping /
    # sorting /
    # transposing
    # ----------------------------------------------------------------
    def sort_values(self, ndf, rdf):
        by = self.kwargs["by"]
        ascending = self.kwargs["ascending"]
        col_expression = ""
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        if not isinstance(by, (list, tuple)):
            by = [by]
        if not isinstance(ascending, (list, tuple)):
            ascending = [ascending] * len(by)
        ob_expression = self._method._get_orderby_expression(cols=by, desc=[not asc for asc in ascending])
        clause = f"SELECT {col_expression} FROM {rdf.table} ORDER BY {ob_expression}"
        
        col_expression = self._method._create_table_ix(create_ix=True) + "*"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def sort_index(self, ndf, rdf):
        level = self.kwargs["level"]
        ascending = self.kwargs["ascending"]
        col_expression = ""
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        if level is None:
            level = rdf.index.names
        if not isinstance(level, (list, tuple)):
            level = [level]
        if not isinstance(ascending, (list, tuple)):
            ascending = [ascending] * len(level)
        ob_expression = self._method._get_orderby_expression(cols=level, desc=[not asc for asc in ascending])
        clause = f"SELECT {col_expression} FROM {rdf.table} ORDER BY {ob_expression}"
        
        col_expression = self._method._create_table_ix(create_ix=True) + "*"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    # ----------------------------------------------------------------
    # Combining / joining / merging
    # ----------------------------------------------------------------
    def assign(self, ndf, rdf):
        kwargs = self.kwargs["kwargs"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {}
        for k, v in kwargs.items():
            if isinstance(v, Series):
                change_map[k] = rdf._get_condition(v)
            else:
                change_map[k] = self._method._value_to_sql(v)
        # change_map = {k: rdf._get_condition(v) for k, v in kwargs.items()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    # def merge_index(self, ndf, left, right):
    #     how = self.kwargs["how"]
    #     how = how if how != "outer" else "full"
    #     col_expression = self._method._create_table_ix(create_ix=True)
    #     change_map = {}
    #     on_list = []
    #     if ndf.index.nlevels == 1: # 只有一个index时，不需要左右index name相同
    #         left_index_name = f"{left.table}.{left.index.name}"
    #         right_index_name = f"{right.table}.{right.index.name}"
    #         change_map[ndf.index.name] = self._method._get_if_expression(f"{left_index_name} is not null", left_index_name, right_index_name)
    #         on_list.append(f"{left_index_name} = {right_index_name}")
    #     else:
    #         for index_name in ndf.index.names:
    #             left_index_name = f"{left.table}.{index_name}"
    #             right_index_name = f"{right.table}.{index_name}"
    #             if index_name in left.index.names and index_name in right.index.names:
    #                 change_map[index_name] = self._method._get_if_expression(f"{left_index_name} is not null", left_index_name, right_index_name)
    #                 on_list.append(f"{left_index_name} = {right_index_name}")
    #             elif index_name in left.index.names:
    #                 change_map[index_name] = left_index_name
    #             else:
    #                 change_map[index_name] = right_index_name
    #     col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
    #     on_expression = " and ".join(on_list) # 连接条件
    #     change_map = {}
    #     for ci, col_name in enumerate(ndf.columns.to_list()):
    #         if ci < len(left.columns):
    #             change_map[col_name] = f"{left.table}.{left.columns[ci]}"
    #         else:
    #             change_map[col_name] = f"{right.table}.{right.columns[ci - len(left.columns)]}"
    #     col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
    #     sql = f"SELECT {col_expression} FROM {left.table} {how} JOIN {right.table} ON {on_expression}"
    #     return sql

    def merge(self, ndf, left, right):
        how = self.kwargs["how"]
        left_on = self.kwargs["left_on"]
        right_on = self.kwargs["right_on"]
        how = how if how != "outer" else "full"
        if not isinstance(left_on, (list, tuple)):
            left_on, right_on = [left_on], [right_on]

        col_expression = self._method._create_table_ix(create_ix=True)
        if ndf.backend_sql.BACKEND_TYPE == "MOXE":
            # left_index_name = f"{left.table}.{left_on[0]}" # 这种情况无法处理cross join
            # right_index_name = f"{right.table}.{right_on[0]}"
            # change_map = {ndf.index.name: self._method._get_if_expression(f"{left_index_name} is not null", left_index_name, right_index_name)}
            change_map = {ndf.index.name: "cast(null as integer)"}
        else:
            change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        change_map = {}
        for i, col_name in enumerate(ndf.columns):
            if i < len(left.columns):
                change_map[col_name] = self._method._get_case_sensitive(col=left.columns[i], table=left.table)
            else:
                change_map[col_name] = self._method._get_case_sensitive(col=right.columns[i - len(left.columns)], table=right.table)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)

        on_expression = " and ".join([f"{self._method._get_case_sensitive(col=left_on[i], table=left.table)} = {self._method._get_case_sensitive(col=right_on[i], table=right.table)}" for i in range(len(left_on))])
        sql = f"SELECT {col_expression} FROM {left.table} {how} JOIN {right.table}"
        if how != "cross":
            sql += f" ON {on_expression}"
        return sql

    def concat_by_index(self, ndf, rdf1, rdf2):
        # column永远采用同名合并，若宽度不同，用空值填补
        # index不会采用同名合并，而是按照level合并
        # 若index宽度不相同，得到新对象的宽度为1，pandas的做法是让index合并为tuple，我们在这里丢弃了一些index信息
        ignore_index = self.kwargs["ignore_index"]
        col_expression = ""
        if not ignore_index:
            change_map = {ndf.index.names[ii]: self._method._get_case_sensitive(rdf1.index.names[ii]) for ii in range(ndf.index.nlevels)}
        else:
            change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        change_map = {col_name: "null" for col_name in ndf.columns if col_name not in rdf1.columns.to_list()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        clause1 = f"SELECT {col_expression} FROM {rdf1.table}"
        
        col_expression = ""
        if not ignore_index:
            change_map = {ndf.index.names[ii]: self._method._get_case_sensitive(rdf2.index.names[ii]) for ii in range(ndf.index.nlevels)}
        else:
            change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        change_map = {col_name: "null" for col_name in ndf.columns if col_name not in rdf2.columns.to_list()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        clause2 = f"SELECT {col_expression} FROM {rdf2.table}"
        
        clause3 = self._method._union_all([clause1, clause2], sort=False)
        col_expression = self._method._create_table_ix(create_ix=True)
        if not ignore_index:
            col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        else:
            change_map = {ndf.index.name: self._method._get_row_number_expression()}
            col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        sql = f"SELECT {col_expression} FROM ({clause3}) {ndf.table}_tmp"
        return sql

    def concat_by_ix(self, ndf, rdf1, rdf2):
        col_expression = self._method._create_table_ix(create_ix=True)
        change_map = {ndf.index.name: self._method._get_row_number_expression()}
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names, change_map=change_map)
        change_map = {}
        for i, col_name in enumerate(ndf.columns.to_list()):
            if i < len(rdf1.columns):
                change_map[col_name] = self._method._get_case_sensitive(col=rdf1.columns[i], table=rdf1.table)
            else:
                change_map[col_name] = self._method._get_case_sensitive(col=rdf2.columns[i- len(rdf1.columns)], table=rdf2.table)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf1.table} FULL JOIN {rdf2.table} ON {rdf1.table}.ix = {rdf2.table}.ix"
        return sql

    # ----------------------------------------------------------------
    # Binary Operator functions
    # ----------------------------------------------------------------
    def _get_arithemetic_sql(self, op, ndf, rdf):
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        # col_expression += ", ".join([f'{op} as "{col_name}"'.format(ci=col_name) for col_name in rdf.columns])
        
        change_map = {col_name: op.format(col=self._method._get_case_sensitive(col_name)) for col_name in ndf.columns.to_list()}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} from {rdf.table}"
        return sql

    def neg(self, ndf, rdf):
        op = "-{col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def add(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" + {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def sub(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" - {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def mul(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" * {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def truediv(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "cast({col} as float)" + f" / {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def floordiv(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "cast({col} as integer)" + f" / {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def mod(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" % {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def pow(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" ^ {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def radd(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} + " + "{col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rsub(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} - " + " {col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rmul(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} * " + "{col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rtruediv(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} / " + "cast({col} as float)"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rfloordiv(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} / " + "cast({col} as integer)"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rmod(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} % " + "{col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rpow(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"{other} ^ " + "{col}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def lt(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" < {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def le(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" <= {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def gt(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" > {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def ge(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "{col}" + f" >= {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def eq(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if other == "null":
            op = "{col} is null"
        else:
            op = "{col}" + f" = {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def ne(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        if other == "null":
            op = "{col} is not null"
        else:
            op = "{col}" + f" != {other}"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    # ----------------------------------------------------------------
    # For AIworkflow
    # ----------------------------------------------------------------
    def iloc_setitem(self, ndf, rdf):
        value = self.kwargs["value"]
        iindexer = self.kwargs["iindexer"]
        cindexer = self.kwargs["cindexer"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        
        if cindexer is None:
            cols = rdf.columns.to_list()
        elif isinstance(cindexer, int):
            cols = [rdf.columns[cindexer]]
        else:#slice(None) 或者其他情况
            cols = rdf.columns[cindexer]
        
        value = self._method._value_to_sql(value)
        condition = self._method._iloc_iindexer(in1=rdf, iindexer=iindexer)
        change_map = {col_name: self._method._get_if_expression(condition, value, self._method._get_case_sensitive(col_name)) for col_name in cols}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def loc_setitem(self, ndf, rdf):
        value = self.kwargs["value"]
        iindexer = self.kwargs["iindexer"]
        cindexer = self.kwargs["cindexer"]
        col_expression = self._method._create_table_ix()
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)

        if cindexer is None:
            cols = rdf.columns.to_list()
        elif not isinstance(cindexer, (list, tuple)): # lable的情况
            cols = [cindexer]
        else:
            cols = cindexer
        
        value = self._method._value_to_sql(value)
        condition = self._method._loc_iindexer(in1=rdf, iindexer=iindexer)
        change_map = {col_name: self._method._get_if_expression(condition, value, self._method._get_case_sensitive(col_name)) for col_name in cols}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        sql = f"SELECT {col_expression} FROM {rdf.table}"
        return sql

    def filter_by_conditions(self, ndf, rdf):
        conditions = self.kwargs["conditions"]
        conjunction = self.kwargs["conjunction"]
        mask = self.kwargs["mask"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        where_list = []
        for condition in conditions:
            c = condition[0]
            op = condition[1]
            value = self._method._value_to_sql(condition[2])
            if value == "null":
                op = "is" if op == "=" else "is not"
            wh_exp = f"{c} {op} {value}"
            where_list.append(wh_exp)
        where_expression = (" "+ conjunction + " ").join(where_list)
        if mask:
            where_expression = f"not ({where_expression})"
        sql = f"SELECT {col_expression} FROM {rdf.table} WHERE {where_expression}"
        return sql

    def random_split(self, ndf, rdf):
        rate = self.kwargs["rate"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        clause = f"SELECT *, random() as c0 FROM {rdf.table}, (SELECT setseed({seed})) {ndf.table}_seed ORDER BY c0 LIMIT floor((SELECT COUNT(*) FROM {rdf.table}) * {rate})"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def random_split2(self, ndf, rdf):
        rate = self.kwargs["rate"]
        seed = self.kwargs["seed"]
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list())
        clause = f"SELECT *, random() as c0 FROM {rdf.table}, (SELECT setseed({seed})) {ndf.table}_seed ORDER BY c0 DESC LIMIT ceil((SELECT COUNT(*) FROM {rdf.table}) * {1 - rate})"
        sql = f"SELECT {col_expression} FROM ({clause}) {ndf.table}_tmp"
        return sql

    def save_duplicates(self, ndf, rdf):
        subset = self.kwargs["subset"]
        keep = self.kwargs["keep"]
        subset = subset if subset is not None else rdf.columns.to_list()
        col_expression = self._method._create_table_ix(create_ix=True)
        col_expression += self._method._create_table_ii(out_ii=ndf.index.names)
        change_map = {col_name: self._method._get_case_sensitive(col=col_name, table=rdf.table) for col_name in subset}
        col_expression += self._method._create_table_ci(out_ci=ndf.columns.to_list(), change_map=change_map)
        gb_expression = self._method._get_groupby_expression(subset)
        if keep == "first":
            sql = f"SELECT {col_expression} FROM {rdf.table} WHERE ix in (SELECT min(ix) FROM {rdf.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1)"
        elif keep == "last":
            sql = f"SELECT {col_expression} FROM {rdf.table} WHERE ix in (SELECT max(ix) FROM {rdf.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1)"
        else:
            clause = f"SELECT {gb_expression} FROM {rdf.table} GROUP BY {gb_expression} HAVING COUNT(*) > 1"
            on_expression = f" and ".join([f"{self._method._get_case_sensitive(col=col_name, table=rdf.table)} = {self._method._get_case_sensitive(col=col_name, table=f'{ndf.table}_tmp')}" for col_name in subset])
            where_expression = " or ".join(f"{self._method._get_case_sensitive(col=col_name, table=f'{ndf.table}_tmp')} is not null" for col_name in subset)
            sql = f"SELECT {col_expression} FROM {rdf.table} LEFT JOIN ({clause}) {ndf.table}_tmp ON {on_expression} WHERE {where_expression}"
        return sql


class PostgresFrameMethod(FrameMethodBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._method = PostgresMethodBase.instance()


class MoxeFrameMethod(FrameMethodBase):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self._method = MoxeMethodBase().instance()
        

    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def pow(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = "POWER({col}" + f", {other})"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql

    def rpow(self, ndf, rdf):
        other = self.kwargs["other"]
        other = self._method._value_to_sql(other)
        op = f"POWER({other}" + ", {col})"
        sql = self._get_arithemetic_sql(op, ndf, rdf)
        return sql
