import pandas as pd

from rapidspy.series import Series


# TODO 这里都应该是rc的方法
def to_datetime(x):
    if isinstance(x, Series):
        return x.to_datetime()

    return pd.to_datetime(x)
    # return datetime.datetime.strptime(
    #     datetime_str, 
    #     "%Y-%m-%d %H:%M:%S"
    # )


def cut(x, bins, right: bool = True, labels=None, retbins: bool = False, precision: int = 3, include_lowest: bool = False, duplicates: str = "raise",ordered: bool = True):
    """
    case when 语句可以实现
    planA: 将lable传入数据库中，缺点就是数据类型会变化，且无法保持其顺序关系
    planB: 将lable固定为0,1,2,3，保持了其顺序，需要在to_pandas中重新cut，但区间会跟原本不太一样
        举例：pd.cut([9,8,7,6,5,1,3,10,15], bins=[-1,5,10,13,18,24])
                [(5, 10], (5, 10], (5, 10], (5, 10], (-1, 5], (-1, 5], (-1, 5], (5, 10], (13, 18]]
                Categories (5, interval[int64, right]): [(-1, 5] < (5, 10] < (10, 13] < (13, 18] < (18, 24]]
            存在数据库就是：1, 1, 1, 1, 0, 0, 0, 1, 3
            to_pandas时需要重新cut一次：
            pd.cut([1, 1, 1,1, 0, 0, 0, 1, 3], bins=[-1,0,1,2,3,4,5], lables=[(-1, 5], (5, 10], (10, 13], (13, 18], (18, 24]])
                [(5, 10], (5, 10], (5, 10], (5, 10], (-1, 5], (-1, 5], (-1, 5], (5, 10], (13, 18]]
                Categories (5, interval[int64, right]): [(-1, 5] < (5, 10] < (10, 13] < (13, 18] < (18, 24]]
        缺点1：只是看起来一样的，实际bins不一样
        缺点2：用户如果有后续判断相等之类的操作，由于在数据库中是0,1，所以，判断需要进行一些转换，违背了设计理念
        缺点3：太过于复杂，实现难度高
    planC：遇到cut操作，只在python端cut，当to_pandas时，拿到数据了再cut
        致命缺点：cut实际上是一些离散操作，cut完几乎可以认定是需要做groupby的，此方案无法在后续group by
    """
    if isinstance(x, Series):
        return x.cut(bins, labels=labels)
