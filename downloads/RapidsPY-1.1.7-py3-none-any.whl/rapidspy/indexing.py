import pandas as pd
from rapidspy.base import new_rapidspy_object
from rapidspy.frame import DataFrame
from rapidspy.series import Series
from rapidspy.scalar import Scalar


class _IndexerBase(object):
    
    def __init__(self, obj: DataFrame):
        self.obj = obj

    @property
    def _name(self):
        return self.obj._name

    @property
    def _meta_indexer(self):
        raise NotImplementedError

    def _make_meta(self, iindexer, cindexer):
        """
        get metadata
        """
        if cindexer is None:
            return self.obj._meta
        else:
            return self._meta_indexer[:, cindexer]


class _iAtIndexer(_IndexerBase):

    @property
    def _meta_indexer(self):
        # 空dataframe和serie无法使用iat进行模拟，所以meta返回的会是series
        return self.obj._meta.iloc

    def __getitem__(self, key):
        if not isinstance(key, tuple):
            key = tuple([key])
        
        return self._iat(*key)
    
    def _iat(self, iindexer, cindexer=None):
        if self.obj.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("'iat' can not be used if you choose MOXE as backend engine.")
        meta = self._make_meta(iindexer, cindexer)
        sc = new_rapidspy_object(meta, self.obj.backend_sql, cls=Scalar)
        sc.put(dependencies=[self.obj], op=self.obj._create_method_instance(iindexer=iindexer, cindexer=cindexer).iat)
        return sc


class _AtIndexer(_IndexerBase):

    @property
    def _meta_indexer(self):
        return self.obj._meta.at

    def __getitem__(self, key):
        # loc包含了at
        return _LocIndexer(self.obj)[key]


class _iLocIndexer(_IndexerBase):

    @property
    def _meta_indexer(self):
        return self.obj._meta.iloc

    def __getitem__(self, key):
        if type(key) is tuple:
            if len(key) > self.obj.ndim:
                # raise from pandas
                msg = 'Too many indexers'
                raise pd.core.indexing.IndexingError(msg)
            iindexer = key[0]
            cindexer = key[1]
        else:
            # if self.obj is Series, cindexer is always None
            iindexer = key
            cindexer = None
        
        return self._iloc(iindexer, cindexer)

    def _iloc(self, iindexer, cindexer):
        if iindexer != slice(None) and self.obj.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("'iloc' only supports selecting columns if you choose MOXE as backend engine.\nIt must be used like 'df.iloc[:, column_indexer]'.")
        
        meta = self._make_meta(iindexer, cindexer)
        new_o = new_rapidspy_object(meta, self.obj.backend_sql)
        new_o.put(dependencies=[self.obj], op=self.obj._create_method_instance(iindexer=iindexer, cindexer=cindexer).iloc)
        return new_o
    

class _LocIndexer(_IndexerBase):

    @property
    def _meta_indexer(self):
        return self.obj._meta.loc

    def __getitem__(self, key):
        if type(key) is tuple:
            if len(key) > self.obj.ndim:
                # raise from pandas
                msg = 'Too many indexers'
                raise pd.core.indexing.IndexingError(msg)
            iindexer = key[0]
            cindexer = key[1]
        else:
            # if self.obj is Series, cindexer is always None
            iindexer = key
            cindexer = None
        
        return self._loc(iindexer, cindexer)

    def _loc(self, iindexer, cindexer):
        
        meta = self._make_meta(iindexer, cindexer)
        new_o = new_rapidspy_object(meta, self.obj.backend_sql)
        new_o.put(dependencies=[self.obj], op=self.obj._create_method_instance(iindexer=iindexer, cindexer=cindexer).loc)
        return new_o

