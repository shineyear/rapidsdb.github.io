from rapidspy.base import new_rapidspy_object
from rapidspy.series import Series


class PropertiesBase():

    def __init__(self, obj: Series) -> None:
        self.obj = obj


class DatetimeProperties(PropertiesBase):

    @property
    def date(self):
        meta = self.obj._meta.dt.date.astype("datetime64[ns]") # 理应得到一个date类型
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='date').datetime)
        return rs

    @property
    def year(self):
        meta = self.obj._meta.dt.year
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='year').datetime)
        return rs

    @property
    def month(self):
        meta = self.obj._meta.dt.month
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='month').datetime)
        return rs

    @property
    def day(self):
        meta = self.obj._meta.dt.day
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='day').datetime)
        return rs

    @property
    def hour(self):
        meta = self.obj._meta.dt.hour
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='hour').datetime)
        return rs

    @property
    def minute(self):
        meta = self.obj._meta.dt.minute
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='minute').datetime)
        return rs

    @property
    def second(self):
        meta = self.obj._meta.dt.second
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='second').datetime)
        return rs

    @property
    def week(self):
        meta = self.obj._meta.dt.week
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='week').datetime)
        return rs

    @property
    def weekofyear(self):
        meta = self.obj._meta.dt.weekofyear
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='week').datetime)
        return rs

    @property
    def quarter(self):
        meta = self.obj._meta.dt.quarter
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='quarter').datetime)
        return rs


class TimedeltaProperties(PropertiesBase):

    @property
    def days(self):
        meta = self.obj._meta.dt.days
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='days').datetime)
        return rs

    @property
    def seconds(self):
        meta = self.obj._meta.dt.seconds
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='seconds').datetime)
        return rs

    def total_seconds(self):
        meta = self.obj._meta.dt.total_seconds()
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(func='total_seconds').datetime)
        return rs


class StringMethods():

    def __init__(self, obj: Series) -> None:
        self.obj = obj

    def len(self):
        meta = self.obj._meta.str.len()
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance().str_len)
        return rs

    def lower(self):
        meta = self.obj._meta.str.lower()
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance().lower)
        return rs

    def upper(self):
        meta = self.obj._meta.str.upper()
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance().upper)
        return rs

    def strip(self, to_strip=None):
        meta = self.obj._meta.str.strip(to_strip=to_strip)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(to_strip=to_strip).strip)
        return rs

    def lstrip(self, to_strip=None):
        meta = self.obj._meta.str.lstrip(to_strip=to_strip)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(to_strip=to_strip).lstrip)
        return rs

    def rstrip(self, to_strip=None):
        meta = self.obj._meta.str.rstrip(to_strip=to_strip)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(to_strip=to_strip).rstrip)
        return rs

    def slice(self, start=None, stop=None):
        step = 1
        meta = self.obj._meta.str.slice(start=start, stop=stop, step=step)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(start=start, stop=stop, step=step).slice)
        return rs

    def find(self, sub, start=0, end=None):
        meta = self.obj._meta.str.find(sub=sub, start=start, end=end)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(sub=sub, start=start, end=end).find)
        return rs

    def startswith(self, pat):
        meta = self.obj._meta.str.startswith(pat=pat)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(pat=pat).startswith)
        return rs

    def endswith(self, pat):
        meta = self.obj._meta.str.endswith(pat=pat)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(pat=pat).endswith)
        return rs

    def split_part(self, pat=None, n=0):
        if self.obj.backend_sql.BACKEND_TYPE == "MOXE" and n != 0:
            raise ValueError("'n' can only be 0 if you choose MOXE as Backend Engine.")
        meta = self.obj._meta.str.split(pat=pat, n=n)
        rs = new_rapidspy_object(meta, self.obj.backend_sql)
        rs.put(dependencies=[self.obj], op=self.obj._create_method_instance(pat=pat, n=n).split_part)
        return rs
