import numpy as np
import pandas as pd
from rapidspy.base import Frame


class Scalar(Frame):

    def __del__(self):
        # 必须存在，覆盖掉父类的del方法
        pass
    
    def compute(self):
        # TODO 计算之后转类型
        if self.computed:
            return self._sc
        
        gray_set = set()
        black_set = set()
        sql = 'With\n' + self.dfs(gray_set, black_set)[:-2] + f"\nSELECT * FROM {self.table};\n"
        # print("scalar table:", self.table)
        # print("scalar sql:", sql)
        self.computed = True
        self._sc = self.execute(sql)
        return self._sc
    
    def execute(self, sql):
        result = self.backend_sql.fetch_sql(sql)
        if isinstance(self._meta, np.ndarray):
            return np.array([tup[0] for tup in result])
        # for iat
        if (isinstance(self._meta, pd.Series) and self._meta.dtype == np.float64) or type(self._meta) is float:
            return float(result[0][0])
        return result[0][0]
    
    def __repr__(self) -> str:
        return f"<rapidspy scalar> object"

    def __str__(self) -> str:
        if not self.computed:
            self.compute()
        return self._sc.__str__()

"""
With
"table6" as (SELECT row_number() over() -1 as table6_ix, l_orderkey as c0, l_partkey as c1, l_suppkey as c2, l_linenumber as c3, l_quantity as c4, l_extendedprice as c5, l_discount as c6, l_tax as c7, l_returnflag as c8, l_linestatus as c9, l_shipdate as c10, l_commitdate as c11, l_receiptdate as c12, l_shipinstruct as c13, l_shipmode as c14, l_comment as c15 FROM "TABLE5"),
"table7" as (SELECT c5 FROM "table6" WHERE table6_ix=5)
SELECT * FROM "table7";
"""