import pandas as pd
import sqlalchemy
import json
import os
from rapidspy import utils

# from sqlalchemy.orm import sessionmaker
# BACKEND_TYPE = "POSTGRES"
# backend_engine = create_engine('postgresql+psycopg2://postgres:rdpuser@192.168.30.126:5432/rdp4', connect_args={'connect_timeout': 30000})

# CATALOG = 'rdp4'
# SCHEMA = 'public'

# session_factory = sessionmaker(bind=backend_engine)
# session = session_factory()
# tid = 0


SESSION_MAP = {}


def _engine_builder(con):
    if isinstance(con, str):
        return sqlalchemy.create_engine(con, echo=False, connect_args={'connect_timeout': 30000})
    return con


def _rapidspy_sql_builder(con, schema=None):
    engine = _engine_builder(con)
    from rapidspy.sql import RapidsPYSQL
    rapidspy_sql = RapidsPYSQL(engine=engine, schema=schema)
    return rapidspy_sql


class RapidsPYSession():

    CATALOG = ""
    SCHEMA = ""
    BACKEND_ENGINE = "" # rapids con
    session_id = ""
    backend_sql = None
    _graph = {} # save dependencies
    _rpy = {} # save rapidspy obj
    rid = 0 # rapidspy obj id
    
    _closed = False

    def _configure_moxe(self, connector_ddl, schema=None):
        from rapidspy.sql import MoxeSQL
        self.backend_sql = MoxeSQL(engine=self.BACKEND_ENGINE, catalog=self.CATALOG, schema=self.SCHEMA)

    def _configure_postgres(self, connector_ddl, schema=None):
        connector_msg_list = connector_ddl.split(', ')
        msg_d = {}
        for msg in connector_msg_list:
            try:
                key, value = msg.split('=')
                value = value.replace("'", "")
                msg_d[key] = value
            except:
                pass
        pg_engine = _engine_builder("postgresql+psycopg2://{USER}:{PASSWORD}@{HOST}:{PORT}/{DATABASE}".format(**msg_d))
        self.CATALOG = msg_d["DATABASE"]
        if schema is not None:
            self.SCHEMA = schema
        # self.SCHEMA = self.SCHEMA.lower()
        # self.CATALOG = self.CATALOG.lower()
        from rapidspy.sql import PostgresSQL
        self.backend_sql = PostgresSQL(engine=pg_engine, catalog=self.CATALOG, schema=self.SCHEMA)

    def _test_connect(self):
        result = self.BACKEND_ENGINE.execute(f"select 1;")
        if not result:
            raise Exception("can not connect to engine.")

    def _get_connector_name(self):
        result = self.BACKEND_ENGINE.execute(f"select distinct(connector_name) from rapids.system.TABLE_PROVIDERS where catalog_name='{self.CATALOG}' and schema_name='{self.SCHEMA}';").fetchall()
        return result[0][0]

    def _get_connector_info(self, connector_name):
        result = self.BACKEND_ENGINE.execute(f"select connector_type, connector_ddl from rapids.system.connectors where is_enabled=true and connector_name='{connector_name}';").fetchall()
        connector_type = result[0][0]
        try:
            connector_ddl = str(result[0][1]).split(" WITH ")[-1].split(" NODE ")[0]
        except:
            raise Exception('resolve connector_ddl failed.')
        return connector_type, connector_ddl

    def configure_by_con(self, con, schema=None):
        if type(con) is str:
            rdp_engine = _engine_builder(con)
        elif isinstance(con, sqlalchemy.engine.Connectable):
            rdp_engine = con

        con = str(rdp_engine.url)
        self.CATALOG = con.split('/')[-2]
        self.SCHEMA = con.split('/')[-1]
        self.BACKEND_ENGINE = rdp_engine
        self._test_connect()
        connector_name = self._get_connector_name()
        connector_type, connector_ddl = self._get_connector_info(connector_name)
        connector_type = connector_type.upper()
        if connector_type == "MOXE":
            self._configure_moxe(connector_ddl, schema)
        elif connector_type == "POSTGRES":
            self._configure_postgres(connector_ddl, schema)
        else:
            raise Exception(f"connector type {connector_type} can not be supported.")
        self.session_id = self.backend_sql.session_id
        SESSION_MAP[self.session_id] = self
        self._graph = {}
        self._rpy = {}
        self.rid = 0
        return self

    @staticmethod
    def _read_connector_configs():
        connectors_filepath = os.path.join(os.path.dirname(__file__), "connectors.json")
        with open(connectors_filepath) as fp:
            connector_configs = json.load(fp)
        return connector_configs

    def con_list(self):
        connector_configs = self._read_connector_configs()
        data = {}
        data["name"] = []
        data["description"] = []
        for con_name in connector_configs:
            con = connector_configs[con_name]
            data["name"].append(con_name)
            data["description"].append(con.get("description", ""))
        return pd.DataFrame.from_dict(data)

    def _get_con_by_json(self, con_name):
        connector_configs = self._read_connector_configs()
        if con_name not in connector_configs:
            raise ValueError(f"can non find connector: {con_name}")
        con = connector_configs[con_name]
        return con["con"]

    def configure(self, con_name):
        con = self._get_con_by_json(con_name)
        return self.configure_by_con(con)

    def get_rapidspy_obj(self, rid):
        return self._rpy.get(rid, None)

    def set_rapidspy_obj(self, obj):
        if obj.rid in self._rpy:
            raise ValueError(f"RapidsPY object id {obj.rid} already exists.")
        self._rpy[obj.rid] = obj

    def read_sql_table(self, table_name, con, index_col=None, columns=None, schema=None):
        # TODO 考虑用from record方法
        # 目前的实现，是使用了pd.read_sql_query接口，应该使用from_pandas接口来构建rapidsPY对象
        # rdf = pd.read_sql_table("TEST_BOOL", con=MOXE_CON, index_col="C0", columns=["C0"])
        # rdf = pd.read_sql_table("TEST__2", con=MOXE_CON, index_col="C0", columns=["C0", "C0__1", "C0__1__1"])
        # con 必须是Rapidspy con
        userdb_sql = _rapidspy_sql_builder(con, schema)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and index_col is None:
            raise ValueError("index_col can not be None if you choose MOXE as backend engine.")
        
        # read_sql_table无法复用原来的对象，create_orgin_rdf是根据index_col和columns得到的结果，create_ix只是将原表的的列与其对应了一下
        if self.BACKEND_ENGINE.url == userdb_sql.connectable.url and self.backend_sql.has_table(name=table_name):
            backend_tablename = table_name
            table_in_session = False
        else:
            backend_tablename = self.backend_sql.new_table()
            backend_full_tablename = self.backend_sql.get_backend_full_tablename(backend_tablename)
            userdb_sql.read_table(table_name, backend_full_tablename, index_col=index_col, columns=columns)
            table_in_session = True
        rdf = self.backend_sql.create_origin_rdf(table_name=backend_tablename, index_col=index_col, columns=columns, table_in_session=table_in_session)
        return rdf.create_ix(index_col=index_col, columns=columns)
    
    def read_sql_query(self, sql, con, index_col=None):
        userdb_sql = _rapidspy_sql_builder(con, schema=None)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and index_col is None:
            raise ValueError("index_col can not be None if you choose MOXE as backend engine.")

        backend_tablename = self.backend_sql.new_table()
        backend_full_tablename = self.backend_sql.get_backend_full_tablename(backend_tablename)
        userdb_sql.read_query(sql, backend_full_tablename)
        rdf = self.backend_sql.create_origin_rdf(table_name=backend_tablename, index_col=index_col, columns=None, table_in_session=True)
        return rdf.create_ix(index_col=index_col, columns=None)

    def read_sql(self, sql, con, index_col=None, columns=None):
        userdb_sql = _rapidspy_sql_builder(con, schema=None)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and index_col is None:
            raise ValueError("index_col can not be None if you choose MOXE as backend engine.")
        
        if userdb_sql.has_table(sql):
            return self.read_sql_table(table_name=sql, con=con, index_col=index_col, columns=columns)
        else:
            return self.read_sql_query(sql=sql, con=con, index_col=index_col)

    def from_pandas(self, frame, name, schema=None, if_exists="fail", chunksize=None, dtype=None, method=None):
        # moxe全大写，pg全小写
        if self.backend_sql.BACKEND_TYPE == "MOXE":
            name = name.upper()
            func = lambda x: x.upper()
        elif self.backend_sql.BACKEND_TYPE == "POSTGRES":
            name = name.lower()
            func = lambda x: x.lower()
        
        frame = frame.copy()
        utils.fix_meta_names(frame) # 处理None
        utils.lower_or_upper_meta_names(frame, func=func) # 全大写或小写
        utils.fix_meta_names(frame, repeatable=False) # 处理重复
        utils.lower_or_upper_meta_names(frame, func=func) # 尾缀大写或小写
        frame.to_sql(name, self.backend_sql.connectable, schema, if_exists=if_exists, index=True, index_label=None, chunksize=chunksize, dtype=dtype, method=method)

        index_col = frame.index.names
        columns = [frame.name] if isinstance(frame, pd.Series) else frame.columns
        rdf = self.backend_sql.create_origin_rdf(table_name=name, index_col=index_col, columns=columns, table_in_session=True)
        rdf = rdf.create_ix(index_col=index_col, columns=columns)
        if isinstance(frame, pd.Series):
            return rdf[frame.name]
        return rdf

    def sql(self, q, dependencies=None, index_col=None):
        if self.backend_sql.BACKEND_TYPE == "MOXE" and index_col is None:
            raise ValueError("index_col can not be None if you choose MOXE as backend engine.")
        table_name = self.backend_sql.new_table()
        full_sql = ""
        if dependencies is not None:
            gray_set = set()
            black_set = set()
            for father in dependencies:
                father_sql = father.dfs(gray_set, black_set, need_ix = True) # 先各自计算出father的table
                if father_sql:
                    full_sql = full_sql + father_sql
        full_sql += f"{table_name} as ({q}),\n"
        
        sql = 'With\n' + full_sql
        sql = sql[:-2]
        sql += f"\nSELECT * FROM {table_name};\n"
        backend_full_tablename = self.backend_sql.get_backend_full_tablename(table_name)
        self.backend_sql.read_query(sql, backend_full_tablename)
        rdf = self.backend_sql.create_origin_rdf(table_name=table_name, index_col=index_col, columns=None, table_in_session=True)
        return rdf.create_ix(index_col=index_col, columns=None)

    def close(self):
        if self._closed:
            raise Exception("Already closed")
        del SESSION_MAP[self.session_id]
        try:
            self.backend_sql.close()
            self.BACKEND_ENGINE.dispose()
        except:
            pass
        del self.backend_sql
        self._closed = True
