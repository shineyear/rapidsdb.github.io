import uuid
import pandas as pd
import sqlalchemy as sa
from sqlalchemy import sql


DTYPE_MAP = {
    "BIGINT": "int64",
    "VARCHAR": "object",
    "DECIMAL": "float64",
    "DATE": "datetime64[ns]"
}

# from sqlalchemy import engine, schema
# from sqlalchemy.orm import session
    # from sqlalchemy.orm import sessionmaker
    # session_factory = sessionmaker(bind=engine)
    # session = session_factory()
    # sql = f"select * from RAPIDS.SYSTEM.COLUMNS where CATALOG_NAME='MOXE' and table_name='{table_name}' ORDER BY ORDINAL;"
    # result = session.execute(sql)
    # table_schema = result.fetchall()


def _gt14() -> bool:
    """
    Check if sqlalchemy.__version__ is at least 1.4.0, when several
    deprecations were made.
    """
    import sqlalchemy
    from pandas.util.version import Version

    return Version(sqlalchemy.__version__) >= Version("1.4.0")


class RapidsPYSQL():
    BACKEND_TYPE = ""

    def __init__(self, engine: sa.engine.Engine, catalog=None, schema=None, meta=None):
        self.connectable = engine
        self.catalog = catalog
        self.schema = schema
        if not meta:
            self.new_metadata()
        self.session_id = "s" + str(uuid.uuid4())[:8]
        self.tid = 0
        self.tables = set()
        self.computed_tables = set()

    def new_metadata(self):
        from sqlalchemy.schema import MetaData
        meta = MetaData(self.connectable, schema=self.schema)
        self.meta = meta

    def execute(self, *args, **kwargs):
        return self.connectable.execute(*args, **kwargs)
    
    def read_table(self, table_name, backend_full_tablename, index_col=None, columns=None, limits=None):
        if columns is not None and len(columns) > 0:
            col_expression = ", ".join(columns)
            if index_col:
                index = index_col if isinstance(index_col, list) else [index_col]
                ii_col_expression = ", ".join([str(index_name) for index_name in index if index_name not in columns])
                if ii_col_expression:
                    col_expression = ii_col_expression + ", " + col_expression
        else:
            col_expression = "*"
        limit_expression = ""
        if limits:
            limit_expression = f"LIMIT {limits}"
        q = f"CREATE TABLE {backend_full_tablename} AS SELECT {col_expression} FROM {table_name} {limit_expression}"
        result = self.execute(q)
        return 

    def read_query(self, sql, backend_full_tablename):
        q = f"CREATE TABLE {backend_full_tablename} AS {sql}"
        result = self.execute(q)
        return 

    def create_origin_rdf(self, table_name, index_col, columns, table_in_session=True):
        print(table_name)
        # TODO 使用from_records的方法，则完全不需要反射，缺点是，可能数据类型和pd读的不一样
        self.new_metadata() # 连续反射同一张表时，需要新建metadata，清除缓存
        table = sa.Table(table_name, self.meta, autoload=True, autoload_with=self.connectable) # schema=config.SCHEMA, quote=True
        # table = sa.Table(table_name, self.meta, autoload=True, autoload_with=self.connectable, schema=self.schema) # , quote=True
        if columns is not None and len(columns) > 0:
            cols = [table.c[n] for n in columns]
            if index_col is not None:
                index = index_col if isinstance(index_col, list) else [index_col]
                for idx in index[::-1]:
                    cols.insert(0, table.c[idx])
            sql_select = sql.select(cols).limit(5)
        else:
            sql_select = table.select().limit(5)
        # q = sql.select(table.columns).limit(5).select_from(table)
        q = sql_select
        # result = self.execute(q)
        # column_names = result.keys()
        # data = result.fetchall()
        # head = pd.DataFrame.from_records(data=data, columns=column_names)
        # if index_col:
        #     head.set_index(index_col, inplace=True)
        # 使用from records方法，会导致pg的numerica类型变成object类型
        head = pd.read_sql(sql=q, con=self.connectable, index_col=index_col)
        head.drop(["ix", "IX"], axis=1, inplace=True, errors="ignore")
        meta = head.iloc[:0]
        from rapidspy.frame import DataFrame
        rdf = DataFrame(meta=meta, backend_sql=self, table=table_name, computed=True, table_in_session=table_in_session)
        return rdf
    
    def count(self, table_name):
        q = f'SELECT COUNT(*) FROM {table_name};'
        result = self.execute(q)
        count = result.fetchall()[0][0]
        return count
    
    def to_sql():
        pass
    
    def get_table_columns():
        pass

    def has_table(self, name, schema=None):
        if _gt14():
            insp = sa.inspect(self.connectable)
            return insp.has_table(name, schema or self.meta.schema)
        else:
            return self.connectable.run_callable(
                self.connectable.dialect.has_table, name, schema or self.meta.schema
            )

    def get_table(self, table_name, schema=None):
        schema = schema or self.meta.schema
        if schema:
            tbl = self.meta.tables.get('.'.join([schema, table_name]))
        else:
            tbl = self.meta.tables.get(table_name)

        # Avoid casting double-precision floats into decimals
        from sqlalchemy import Numeric
        for column in tbl.columns:
            if isinstance(column.type, Numeric):
                column.type.asdecimal = False
        return tbl

    def drop_table(self, table_name, schema=None):
        schema = schema or self.meta.schema
        try:
            self.execute(f"drop table {schema}.{table_name}")
        except Exception as e:
            pass
        # if self.has_table(table_name, schema):
        #     self.meta.reflect(only=[table_name], schema=schema)
        #     self.get_table(table_name, schema).drop()
        #     self.meta.clear()

    def read_index(self, table_name, index_col, schema=None):
        schema = schema or self.meta.schema
        if not index_col:
            index = pd.RangeIndex(self.count(table_name), name=index_col)
            return index
        else:
            col_expression = ", ".join(index_col) if type(index_col) is list else index_col
            q = f"SELECT {col_expression} FROM {table_name}"
            data = self.fetch_sql(q)
            index = pd.MultiIndex.from_tuples(data, names=index_col if type(index_col) is list else [index_col])
        return index
        
    def fetch_sql(self, q):
        result = self.execute(q)
        return result.fetchall()

    def generate_table_name(self):
        return NotImplementedError

    def new_table(self):
        table_name = self.generate_table_name()
        while table_name in self.tables or self.has_table(table_name):
            table_name = self.generate_table_name()
        self.tables.add(table_name)
        return table_name

    def get_backend_full_tablename(self, table_name):
        return NotImplementedError

    def create_method_factory():
        return 

    def close(self):
        for table_name in self.computed_tables:
            try:
                self.execute(f"drop table {table_name};")
            except Exception as e:
                pass
        self.connectable.dispose()


class MoxeSQL(RapidsPYSQL):

    def __init__(self, engine, catalog=None, schema=None, meta=None):
        self.BACKEND_TYPE = "MOXE"
        super().__init__(engine, catalog, schema, meta)
        self.session_id = self.session_id.upper()

    def generate_table_name(self):
        table_name = self.session_id + f'_TABLE{self.tid}'
        self.tid += 1
        return table_name
    
    def get_backend_full_tablename(self, table_name):
        return f'{self.catalog}.{self.schema}.{table_name}'

    def create_method_factory(self):
        from rapidspy import method_factory
        return method_factory.MoxeMethodFactory.instance()

class PostgresSQL(RapidsPYSQL):

    def __init__(self, engine, catalog=None, schema=None, meta=None):
        self.BACKEND_TYPE = "POSTGRES"
        super().__init__(engine, catalog, schema, meta)
        self.session_id = self.session_id.lower()

    def generate_table_name(self):
        table_name = self.session_id + f'_table{self.tid}'
        self.tid += 1
        return table_name

    def get_backend_full_tablename(self, table_name):
        return f'"{self.catalog}"."{self.schema}"."{table_name}"'

    def create_method_factory(self):
        from rapidspy import method_factory
        return method_factory.PostgresMethodFactory.instance()
