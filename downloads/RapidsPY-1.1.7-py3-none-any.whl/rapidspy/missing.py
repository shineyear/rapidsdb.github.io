import pandas as pd
from rapidspy.base import Frame


def isna(obj):
    if isinstance(obj, Frame):
        return obj.isna()
    return pd.isna(obj)


isnull = isna


def notna(obj):
    if isinstance(obj, Frame):
        return obj.isna()
    return pd.notna(obj)


notnull = notna

