import datetime
import pandas as pd
from rapidspy.base import Frame, new_rapidspy_object
from rapidspy.scalar import Scalar
from rapidspy import utils

class Series(Frame):

    def __init__(self, meta: pd.Series, backend_sql, table=None, dependencies=None, op = None, computed=False, table_in_session=True):
        utils.fix_meta_names(meta)
        super().__init__(meta, backend_sql, table, dependencies, op, computed, table_in_session)
        self._meta = meta

    def _create_method_instance(self, **kwargs):
        return self.method_factory.create_series_method(**kwargs)

    def _new_index_name(self):
        index_id = 0
        index_name = f"i{index_id}"
        while index_name == self.name or index_name in self.index.names:
            index_id += 1
            index_name = f"i{index_id}"
        return index_name

    def _new_series_name(self):
        column_id = 0
        column_name = f"c{column_id}"
        while column_name == self.name or column_name in self.index.names:
            column_id += 1
            column_name = f"c{column_id}"
        return column_name

    def _len(self):
        meta = len(self._meta)
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().len)
        return sc

    def __len__(self):
        return self._len().compute()

    def create_ix(self, index_col=None, name=None):
        meta = self._meta.copy()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(index_col=index_col, name=name).create_ix)
        return rs
    # ----------------------------------------------------------------
    # Attributes
    # ----------------------------------------------------------------
    @property
    def ndim(self):
        return self._meta.ndim

    @property
    def axes(self):
        return [self.index]

    @property
    def index(self):
        if not hasattr(self, "_index"):
            meta = self._meta.index.copy()
            ri = new_rapidspy_object(meta, self.backend_sql)
            ri.put(dependencies=[self], op=self._create_method_instance().index)
            self._index = ri.rid
        return self.session.get_rapidspy_obj(self._index)

    @property
    def name(self):
        return self._meta.name

    @name.setter
    def name(self, name):
        if self.computed:
            raise Exception("Already Computed.")
        self._meta.name = name
        utils.fix_series_name(self._meta)

    @property
    def dtype(self):
        return self._meta.dtype

    @property
    def dtypes(self):
        return self._meta.dtypes

    @property
    def shape(self):
        return self._len(),

    @property
    def size(self):
        return self._len()

    @property
    def empty(self):
        meta = self._meta.empty
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().empty)
        return sc

    @property
    def values(self):
        return self.to_pandas().values

    # ----------------------------------------------------------------
    # Conversion
    # ----------------------------------------------------------------
    def astype(self, dtype):
        meta = self._meta.astype(dtype)
        rs = new_rapidspy_object(meta, self.backend_sql)
        if dtype == "category":
            rs.put(dependencies=[self], op=self._create_method_instance().nothing)
        else:
            rs.put(dependencies=[self], op=self._create_method_instance(dtype=dtype).astype)
        return rs

    def copy(self):
        meta = self._meta.copy(deep=True)
        ns = new_rapidspy_object(meta, self.backend_sql)
        ns.put(dependencies=[self], op=self._create_method_instance().copy)
        return ns

    # ----------------------------------------------------------------
    # Indexing, iteration
    # ----------------------------------------------------------------
    @property
    def iat(self):
        from .indexing import _iAtIndexer
        return _iAtIndexer(self)
    
    @property
    def at(self):
        from .indexing import _AtIndexer
        return _AtIndexer(self)
    
    @property
    def iloc(self):
        from .indexing import _iLocIndexer
        return _iLocIndexer(self)
    
    @property
    def loc(self):
        from .indexing import _LocIndexer
        return _LocIndexer(self)

    def keys(self):
        return self.index

    def get(self, key, default=None):
        """
        等同于加了默认值的getitem
        """
        try:
            return self[key]
        except (KeyError, ValueError, IndexError):
            return default

    def __getitem__(self, key):
        return self.loc[key]

    # ----------------------------------------------------------------
    # Function application /
    # Groupby & Window
    # ----------------------------------------------------------------
    def groupby(self, by=None, sort=True):
        from rapidspy.groupby import SeriesGroupBy
        return SeriesGroupBy(obj=self, by=by, sort=sort)

    def aggregate(self, func):
        # 如果func是list，返回series，否则返回scalar
        meta = self._meta.agg(func=func)
        if isinstance(func, (list, tuple)): # rs
            new_o = new_rapidspy_object(meta, self.backend_sql)
        else: # sc
            new_o = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        new_o.put(dependencies=[self], op=self._create_method_instance(func=func).agg)
        return new_o

    agg = aggregate

    # ----------------------------------------------------------------
    # Computations / 
    # Descriptive Stats
    # ----------------------------------------------------------------
    def count(self):
        meta = self._meta.count()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().count)
        return sc

    def min(self):
        meta = self._meta.min()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().min)
        return sc

    def max(self):
        meta = self._meta.max()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().max)
        return sc

    def sum(self):
        meta = self._meta.sum()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().sum)
        return sc

    def mean(self):
        meta = self._meta.mean()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().mean)
        return sc

    def median(self):
        meta = self._meta.median()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().median)
        return sc

    def std(self):
        meta = self._meta.std()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().std)
        return sc

    def var(self):
        meta = self._meta.var()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().var)
        return sc

    def all(self):
        meta = self._meta.all()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().all)
        return sc

    def any(self):
        meta = self._meta.any()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().any)
        return sc

    @property
    def is_unique(self):
        meta = self._meta.is_unique
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().is_unique)
        return sc

    def nunique(self):
        meta = self._meta.nunique()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().nunique)
        return sc

    def unique(self):
        meta = self._meta.unique()
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().unique)
        return sc

    def abs(self):
        meta = self._meta.abs()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().abs)
        return rs

    def round(self, decimals=0):
        meta = self._meta.round(decimals=decimals)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(decimals=decimals).round)
        return rs

    def between(self, left, right, inclusive=True):
        meta = self._meta.between(left, right, inclusive)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(left=left, right=right, inclusive=inclusive).between)
        return rs

    def filter(self, like):
        meta = self._meta.filter(like=like)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(like=like).filter)
        return rs

    def describe(self):
        meta = self._meta.describe()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().describe)
        return rs

    def nsmallest(self, n=5):
        meta = self._meta.nsmallest(n)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(n=n).nsmallest)
        return rs

    def nlargest(self, n=5):
        meta = self._meta.nlargest(n)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(n=n).nlargest)
        return rs

    def value_counts(self):
        meta = self._meta.value_counts()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().value_counts)
        return rs
    
    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def drop(self, labels=None, axis=0, index=None, columns=None):
        # columns是冗余参数，同理axis也是
        # 但axis=1 会报错，columns不会报错
        if axis in [0, "index"]: # labels 作用于index上
            if columns: # 当columns为空的时候，drop会报错
                meta = self._meta.drop(columns=columns)
            else:
                meta = self._meta.copy()
        else: # labels 作用于columns上
            meta = self._meta.drop(labels=labels, axis=axis, columns=columns)

        meta = self._meta.copy()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(labels=labels, axis=axis, index=index).drop)
        return rs

    def drop_duplicates(self, keep=False):
        meta = self._meta.drop_duplicates(keep=keep)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and keep != False:
            raise ValueError("'keep' can only be False if you choose MOXE as Backend Engine.")
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(keep=keep).drop_duplicates)
        return rs

    def reset_index(self, level=None, drop=False):
        meta = self._meta.reset_index(level=level, drop=drop)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and isinstance(meta.index, pd.RangeIndex):
            raise ValueError("can not reset all index if you choose MOXE as Backend Engine.")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(level=level, drop=drop).reset_index)
        return rdf

    def sample(self, n=5, seed=0):
        meta = self._meta.copy()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(n=n, seed=seed).sample)
        return rs

    def head(self, n=5):
        meta = self._meta.head(n)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(n=n).head)
        return rs

    # ----------------------------------------------------------------
    # Missing data handling
    # ----------------------------------------------------------------
    def isna(self):
        return self.isnull()

    def isnull(self):
        meta = self._meta.isnull()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().isnull)
        return rs

    def notna(self):
        return self.notnull()

    def notnull(self):
        meta = self._meta.notnull()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().notnull)
        return rs

    def dropna(self, how='any'):
        # how: Not in use. Kept for compatibility.
        meta = self._meta.dropna(how=how)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().dropna)
        return rs

    def fillna(self, value):
        # value: scalar
        meta = self._meta.fillna(value=value)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(value=value).fillna)
        return rs

    def replace(self, to_replace, value):
        meta = self._meta.replace(to_replace=to_replace, value=value)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(to_replace=to_replace, value=value).replace)
        return rs

    # ----------------------------------------------------------------
    # Reshaping /
    # sorting /
    # transposing
    # ----------------------------------------------------------------
    def sort_values(self, ascending=True):
        meta = self._meta.sort_values(ascending=ascending)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(ascending=ascending).sort_values)
        return rs

    def sort_index(self, level=None, ascending=True):
        meta = self._meta.sort_index(level=level, ascending=ascending)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(level=level, ascending=ascending).sort_index)
        return rs

    # ----------------------------------------------------------------
    # Combining / joining / merging
    # ----------------------------------------------------------------
    def concat(self, obj, axis=0, ignore_index=False):
        # axis=1暂未实现
        meta = pd.concat([self._meta, obj._meta], axis=axis, ignore_index=ignore_index)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and ignore_index == True:
            raise ValueError("'ignore_index' can only be False if you choose MOXE as Backend Engine.")
        if axis in [0, "index"]:
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, obj], op=self._create_method_instance(ignore_index=ignore_index).concat_by_index)
            return rs
        else: # 暂未实现
            rdf = new_rapidspy_object(meta, self.backend_sql)
            rdf.put(dependencies=[self, obj], op=self._create_method_instance(ignore_index=ignore_index).concat_by_columns)
            return rdf

    # ----------------------------------------------------------------
    # Accessors
    # ----------------------------------------------------------------
    @property
    def dt(self):
        # if self.dtype in ["<m8[ns]", "timedelta64[ns]"]:
        if self.dtype == "timedelta64[ns]":
            from .accessors import TimedeltaProperties
            return TimedeltaProperties(self)
        elif self.dtype == "datetime64[ns]":
            from .accessors import DatetimeProperties
            return DatetimeProperties(self)
        raise NotImplementedError

    @property
    def str(self):
        if self.dtype == "object":
            from .accessors import StringMethods
            return StringMethods(self)
        raise NotImplementedError
    # ----------------------------------------------------------------
    # Binary Operator functions
    # ----------------------------------------------------------------
    def add(self, other):
        return self.__add__(other)

    def sub(self, other):
        return self.__sub__(other)

    def mul(self, other):
        return self.__mul__(other)

    def div(self, other):
        return self.__truediv__(other)

    def __div__(self, other):
        return self.__truediv__(other)

    def truediv(self, other):
        return self.__truediv__(other)

    def floordiv(self, other):
        return self.__floordiv__(other)

    def mod(self, other):
        return self.__mod__(other)

    def pow(self, other):
        return self.__pow__(other)

    def radd(self, other):
        return self.__radd__(other)

    def rsub(self, other):
        return self.__rsub__(other)

    def rmul(self, other):
        return self.__rmul__(other)

    def rdiv(self, other):
        return self.__rtruediv__(other)

    def __rdiv__(self, other):
        return self.__rtruediv__(other)

    def rtruediv(self, other):
        return self.__rtruediv__(other)

    def rfloordiv(self, other):
        return self.__rfloordiv__(other)

    def rmod(self, other):
        return self.__rmod__(other)

    def rpow(self, other):
        return self.__rpow__(other)

    def __neg__(self):
        meta  = self._meta.__neg__()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().neg)
        rs.fa = self.fa
        return rs

    def __add__(self, other):
        if isinstance(other, Series):
            meta = self._meta.add(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().add2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.add(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).add)
            rs.fa = self.fa
        return rs

    def __sub__(self, other):
        if isinstance(other, Series):
            meta = self._meta.sub(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().sub2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.sub(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).sub)
            rs.fa = self.fa
        return rs

    def __mul__(self, other):
        if isinstance(other, Series):
            meta = self._meta.mul(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().mul2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.mul(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).mul)
            rs.fa = self.fa
        return rs

    def __truediv__(self, other):
        if isinstance(other, Series):
            meta = self._meta.truediv(other._meta) # /
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().truediv2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.truediv(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).truediv)
            rs.fa = self.fa
        return rs

    def __floordiv__(self, other):
        if isinstance(other, Series):
            meta = self._meta.floordiv(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().floordiv2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.floordiv(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).floordiv)
            rs.fa = self.fa
        return rs

    def __mod__(self, other):
        if isinstance(other, Series):
            meta = self._meta.mod(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().mod2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.mod(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).mod)
            rs.fa = self.fa
        return rs

    def __pow__(self, other):
        if isinstance(other, Series):
            meta = self._meta.pow(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().pow2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.pow(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).pow)
            rs.fa = self.fa
        return rs

    def __radd__(self, other):
        if isinstance(other, Series):
            meta = self._meta.radd(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().radd2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.radd(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).radd)
            rs.fa = self.fa
        return rs

    def __rsub__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rsub(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().rsub2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rsub(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).rsub)
            rs.fa = self.fa
        return rs

    def __rmul__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rmul(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().rmul2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rmul(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).rmul)
            rs.fa = self.fa
        return rs

    def __rtruediv__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rtruediv(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().rtruediv2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rtruediv(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).rtruediv)
            rs.fa = self.fa
        return rs

    def __rfloordiv__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rfloordiv(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().rfloordiv2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rfloordiv(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).rfloordiv)
            rs.fa = self.fa
        return rs

    def __rmod__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rmod(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().rmod2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rmod(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).rmod)
            rs.fa = self.fa
        return rs

    def __rpow__(self, other):
        if isinstance(other, Series):
            meta = self._meta.rpow(other._meta)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().pow2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta.rpow(other)
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(other=other).pow)
            rs.fa = self.fa
        return rs

    def lt(self, other):
        return self < other

    def le(self, other):
        return self <= other

    def gt(self, other):
        return self > other

    def ge(self, other):
        return self >= other

    def eq(self, other):
        return self == other

    def ne(self, other):
        return self != other

    def __lt__(self, other):
        if isinstance(other, Series):
            meta = self._meta < other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().lt2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta < other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).lt)
            rs.fa = self.fa
        return rs

    def __le__(self, other):
        if isinstance(other, Series):
            meta = self._meta <= other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().le2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta <= other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).le)
            rs.fa = self.fa
        return rs

    def __gt__(self, other):
        if isinstance(other, Series):
            meta = self._meta > other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().gt2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta > other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).gt)
            rs.fa = self.fa
        return rs

    def __ge__(self, other):
        if isinstance(other, Series):
            meta = self._meta >= other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().ge2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta >= other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).ge)
            rs.fa = self.fa
        return rs

    def __eq__(self, other):
        if isinstance(other, Series):
            meta = self._meta == other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().eq2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta == other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).eq)
            rs.fa = self.fa
        return rs

    def __ne__(self, other):
        if isinstance(other, Series):
            meta = self._meta != other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().ne2)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta != other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).ne)
            rs.fa = self.fa
        return rs

    def __and__(self, other):
        if isinstance(other, Series):
            meta = self._meta & other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().and2_)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta & other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).and_)
            rs.fa = self.fa
        return rs

    def __or__(self, other):
        if isinstance(other, Series):
            meta = self._meta | other._meta
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self, other], op=self._create_method_instance().or2_)
            if self.fa is other.fa:
                rs.fa = self.fa
        else:
            meta = self._meta | other
            rs = new_rapidspy_object(meta, self.backend_sql)
            rs.put(dependencies=[self], op=self._create_method_instance(key=other).or_)
            rs.fa = self.fa
        return rs

    # ----------------------------------------------------------------
    # General
    # ----------------------------------------------------------------
    def cut(self, bins, labels):
        meta = pd.cut(self._meta, bins=bins, labels=labels)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(bins=bins, labels=labels).cut)
        return rs

    def to_datetime(self):
        meta = pd.to_datetime(self._meta)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().to_datetime)
        return rs

    # ----------------------------------------------------------------
    # Serialization / IO / conversion
    # ----------------------------------------------------------------
    def to_frame(self):
        meta = self._meta.to_frame()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().nothing)
        return rdf

    def to_pandas(self):
        if not self.computed:
            self.compute()
        meta = self._meta.copy()
        # if self.backend_sql.BACKEND_TYPE == "MOXE":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.upper())
        # elif self.backend_sql.BACKEND_TYPE == "POSTGRES":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.lower())
        index_col = meta.index.names
        columns = [meta.name]
        pdf = pd.read_sql_table(self.table, con=self.backend_sql.connectable, index_col=index_col, columns=columns)
        ps = pdf.iloc[:, 0]
        ps.name = self.name
        ps = ps.astype(self._meta.dtype, copy=False, errors="ignore")
        ps.index.names = self.index.names
        return ps

    def __repr__(self) -> str:
        if not self.computed:
            return self._meta.iloc[:0].__repr__()
        rows_count = len(self)
        if rows_count <= 60:
            ps = self.to_pandas()
        else:
            ps = self.head().to_pandas()
        return ps.__repr__()

    def __str__(self) -> str:
        return self.__repr__()

    # @property
    # def style(self):
    #     if not self.computed:
    #         self.compute()
    #     pdf = self.to_pandas()
    #     return pdf.style
    
    # def _repr_html_(self): 
    #     if not self.computed:
    #         self.compute()
    #     pdf = self.to_pandas()
    #     return pdf._repr_html_()

    # ----------------------------------------------------------------
    # For AIworkflow
    # ----------------------------------------------------------------

    def iloc_setitem(self, value, iindexer=None):
        iindexer = iindexer if iindexer is not None else slice(None)
        if iindexer != slice(None) and self.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("'iloc_setitem' only supports selecting columns if you choose MOXE as Backend Engine.")
        meta = self._meta.copy()
        meta.iloc[:] = value
        meta = meta.astype(self.dtype, errors="ignore")
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(value=value, iindexer=iindexer).iloc_setitem)
        return rs

    def loc_setitem(self, value, iindexer=None, cindexer=None):
        iindexer = iindexer if iindexer is not None else slice(None)
        meta = self._meta.copy()
        meta.loc[:] = value
        meta = meta.astype(self.dtype, errors="ignore")
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(value=value, iindexer=iindexer, cindexer=cindexer).loc_setitem)
        return rs

    def filter_by_conditions(self, conditions, conjunction="and", mask=False):
        meta = self._meta.copy()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(conditions=conditions, conjunction=conjunction, mask=mask).filter_by_conditions)
        return rs
    
    def random_split(self, rate, seed=0):
        meta = self._meta.copy()
        rs1 = new_rapidspy_object(meta, self.backend_sql)
        rs1.put(dependencies=[self], op=self._create_method_instance(rate=rate, seed=seed).random_split)
        meta = self._meta.copy()
        rs2 = new_rapidspy_object(meta, self.backend_sql)
        rs2.put(dependencies=[self], op=self._create_method_instance(rate=rate, seed=seed).random_split2)
        return rs1, rs2

    def save_duplicates(self, keep=False):
        meta = self._meta.drop_duplicates(keep=keep)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and keep != False:
            raise ValueError("'keep' can only be False if you choose MOXE as Backend Engine.")
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance(keep=keep).save_duplicates)
        return rs

    def concat_by_ix(self, obj):
        if self.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("not support API if you choose MOXE as Backend Engine.")
        meta = pd.concat([self._meta.reset_index(drop=True), obj._meta.reset_index(drop=True)], axis=1)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self, obj], op=self._create_method_instance().concat_by_ix)
        return rdf
