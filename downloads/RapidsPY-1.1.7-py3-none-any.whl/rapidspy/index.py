import pandas as pd
from rapidspy.base import Frame, new_rapidspy_object
from rapidspy.series import Series
from rapidspy import utils

class Index(Frame):

    def __init__(self, meta: pd.Index, backend_sql, table=None, dependencies=None, op = None, computed=False, table_in_session=True):
        super().__init__(meta, backend_sql, table, dependencies, op, computed, table_in_session)
        self._meta = meta

    def __iter__(self):
        return self._meta.__iter__()

    def __str__(self):
        return self.__repr__()

    def __repr__(self):
        return f"<rapidspy.index> object, name: {self.name}"

    @property
    def name(self):
        """
        Return Index or MultiIndex name.
        """
        return self._meta.name

    @property
    def names(self):
        return self._meta.names

    @property
    def nlevels(self):
        return self._meta.nlevels
    
    # def set_names(self, names, level=None):
    #     return self._meta.set_names(names, level)

    # def rename(self, name):
    #     return self._meta.rename(name)

    def to_series(self):
        meta = self._meta.to_series()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=None)

    def to_pandas(self):
        if not self.computed:
            self.compute()
        meta = self._meta.copy()
        # if self.backend_sql.BACKEND_TYPE == "MOXE":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.upper())
        # elif self.backend_sql.BACKEND_TYPE == "POSTGRES":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.lower())
        index_col = meta.names
        pdf = pd.read_sql_table(self.table, con=self.backend_sql.connectable, index_col=index_col)
        pdf.index.names = self.names
        return pdf.index
