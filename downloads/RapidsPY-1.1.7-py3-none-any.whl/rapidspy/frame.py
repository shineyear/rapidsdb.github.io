import datetime
import pandas as pd

from rapidspy.base import Frame, new_rapidspy_object
from rapidspy.series import Series
from rapidspy.scalar import Scalar
from rapidspy import utils

from pandas.io.formats.style import Styler



def lazy(func):
    def wapper(*args, **kwargs):
        return func(*args, **kwargs)

    return wapper


class DataFrame(Frame):

    def __init__(self, meta: pd.DataFrame, backend_sql, table=None, dependencies=None, op = None, computed=False, table_in_session=True):
        # repeatable在这里必须为False, 因为api在转sql时，会无法从上一个table中获取到相应的列名，比如 index-->index_i0
        utils.fix_meta_names(meta)
        super().__init__(meta, backend_sql, table, dependencies, op, computed, table_in_session)

    def _create_method_instance(self, **kwargs):
        return self.method_factory.create_frame_method(**kwargs)

    def _len(self):
        meta = len(self._meta)
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().len)
        return sc

    def __len__(self):
        # 本方法必须返回int类型，无法延迟
        # 特别注意，if rdf: 这种写法，实际上会调用这个方法
        return self._len().compute()

    def create_ix(self, index_col=None, columns=None):
        meta = self._meta.copy()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(index_col=index_col, columns=columns).create_ix)
        return rdf

    # ----------------------------------------------------------------
    # Attributes
    # ----------------------------------------------------------------
    @property
    def ndim(self):
        return self._meta.ndim

    @property
    def axes(self):
        return [self.index, self.columns]

    @property
    def index(self):
        if not hasattr(self, "_index"):
            # 舍弃掉同步修改
            meta = self._meta.index.copy()
            ri = new_rapidspy_object(meta, self.backend_sql)
            ri.put(dependencies=[self], op=self._create_method_instance().index)
            self._index = ri.rid
        return self.session.get_rapidspy_obj(self._index)

    @property
    def columns(self):
        return self._meta.columns

    @property
    def dtypes(self):
        """ Return data types """
        return self._meta.dtypes

    @property
    def shape(self):
        return self._len(), len(self.columns)

    @property
    def size(self):
        meta = self._meta.size
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().size)
        return sc

    @property
    def empty(self):
        meta = self._meta.empty
        sc = new_rapidspy_object(meta, self.backend_sql, cls=Scalar)
        sc.put(dependencies=[self], op=self._create_method_instance().empty)
        return sc

    @property
    def values(self):
        return self.to_pandas().values

    # ----------------------------------------------------------------
    # Conversion
    # ----------------------------------------------------------------
    def astype(self, dtype):
        meta = self._meta.astype(dtype)
        rs = new_rapidspy_object(meta, self.backend_sql)
        if dtype == "category":
            rs.put(dependencies=[self], op=self._create_method_instance().nothing)
        else:
            rs.put(dependencies=[self], op=self._create_method_instance(dtype=dtype).astype)
        return rs

    def copy(self):
        meta = self._meta.copy(deep=True)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().copy)
        return rdf

    # ----------------------------------------------------------------
    # Indexing, Iteration
    # ----------------------------------------------------------------
    @property
    def iat(self):
        from .indexing import _iAtIndexer
        return _iAtIndexer(self)
    
    @property
    def at(self):
        from .indexing import _AtIndexer
        return _AtIndexer(self)
    
    @property
    def iloc(self):
        from .indexing import _iLocIndexer
        return _iLocIndexer(self)
    
    @property
    def loc(self):
        from .indexing import _LocIndexer
        return _LocIndexer(self)
    
    def keys(self):
        return self._meta.keys()

    def get(self, key, default=None):
        """
        等同于加了默认值的getitem
        """
        try:
            return self[key]
        except (KeyError, ValueError, IndexError):
            return default

    def __getitem__(self, key):
        # getitem 由loc替代，暂时看不到不能替代的地方
        if isinstance(key, Series):
            return self.loc[key]

        if isinstance(key, str):
            __key = f"__{key}"
            if not hasattr(self, __key):        
                new_o = self.loc[:, key]
                new_o.fa = self.fa
                setattr(self, __key, new_o.rid)
            return self.session.get_rapidspy_obj(getattr(self, __key))
        else:
            new_o = self.loc[:, key]
            new_o.fa = self.fa
            return new_o
        # if isinstance(key, Series):
        #     rs = key
        #     rs.condition = self._get_condition(rs)
        #     rdf = new_rapidspy_object(self._meta, self.backend_sql)
        #     rdf.put(dependencies=[self], op=self._create_method_instance(rs=rs).getitem)
        #     return rdf
        # elif isinstance(key, str):
        #     if key not in self.columns:
        #         raise Exception(f"{key} not in {self.columns}.")
        #     meta = self._meta[key]
        #     rs = new_rapidspy_object(meta, self.backend_sql)
        #     rs.put(dependencies=[self], op=self._create_method_instance(key=key).getitemby)
        #     rs.key = key
        #     return rs
        # raise NotImplementedError(key)

    # def __setitem__(self, key, value):
    #     # setitem是没有返回值的，也就无法生成新的obj，无法在延迟计算的大条件下实现
    #     # df['date'] = df['action_date'].dt.date
    #     # df['time'] = df['action_date'].dt.hour
    #     if isinstance(key, (int, str)) and isinstance(value, Series):
    #         rs = value
    #         meta = self._meta.copy()
    #         meta.__setitem__(key, [])
    #         print(self._meta)
    #         print(meta)
    #         rs.condition = self._get_condition(rs)
    #         rdf = new_rapidspy_object(meta, self.backend_sql)
    #         rdf.put(dependencies=[self], op=self._create_method_instance(rs=rs).setitem)
    #         return rdf

    # ----------------------------------------------------------------
    # Function application,
    # Groupby & Window
    # ----------------------------------------------------------------
    def groupby(self, by=None, sort=True):
        from rapidspy.groupby import DataFrameGroupBy
        return DataFrameGroupBy(obj=self, by=by, sort=sort)

    def aggregate(self, func):
        # 如果func是list，返回df，否则返回series
        """
        func: 仅支持数值类型计算
        """
        meta = self._meta.agg(func=func, numeric_only=True)
        new_o = new_rapidspy_object(meta, self.backend_sql)
        new_o.put(dependencies=[self], op=self._create_method_instance(func=func).agg)
        return new_o

    agg = aggregate

    # ----------------------------------------------------------------
    # Computations / 
    # Descriptive Stats
    # ----------------------------------------------------------------
    def count(self):
        meta = self._meta.count()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().count)
        return rs

    def min(self):
        meta = self._meta.min(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().min)
        return rs

    def max(self):
        meta = self._meta.max(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().max)
        return rs

    def sum(self):
        meta = self._meta.sum(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().sum)
        return rs

    def mean(self):
        meta = self._meta.mean(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().mean)
        return rs

    def median(self):
        meta = self._meta.median(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().median)
        return rs

    def std(self):
        meta = self._meta.std(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().std)
        return rs

    def var(self):
        meta = self._meta.var(numeric_only=True)
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().var)
        return rs

    def all(self):
        meta = self._meta.all()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().all)
        return rs

    def any(self):
        meta = self._meta.any()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().any)
        return rs

    def nunique(self):
        meta = self._meta.nunique()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().nunique)
        return rs

    def abs(self):
        meta = self._meta.abs()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().abs)
        return rdf

    def round(self, decimals=0):
        meta = self._meta.round(decimals=decimals)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(decimals=decimals).round)
        return rdf

    def filter(self, items=None, like=None, axis=None):
        meta = self._meta.filter(items=items, like=like, axis=axis)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(items=items, like=like, axis=axis).filter)
        return rdf

    def describe(self):
        meta = self._meta.describe()
        ndf = new_rapidspy_object(meta, self.backend_sql)
        ndf.put(dependencies=[self], op=self._create_method_instance().describe)
        return ndf

    def nsmallest(self, n, columns):
        meta = self._meta.nsmallest(n, columns)
        ndf = new_rapidspy_object(meta, self.backend_sql)
        ndf.put(dependencies=[self], op=self._create_method_instance(n=n, columns=columns).nsmallest)
        return ndf

    def nlargest(self, n, columns):
        meta = self._meta.nlargest(n, columns)
        ndf = new_rapidspy_object(meta, self.backend_sql)
        ndf.put(dependencies=[self], op=self._create_method_instance(n=n, columns=columns).nlargest)
        return ndf

    def value_counts(self):
        meta = self._meta.value_counts()
        rs = new_rapidspy_object(meta, self.backend_sql)
        rs.put(dependencies=[self], op=self._create_method_instance().value_counts)
        return rs

    # ----------------------------------------------------------------
    # Reindexing / Selection / 
    # Label Manipulation
    # ----------------------------------------------------------------
    def drop(self, labels=None, axis=0, index=None, columns=None):
        """
        lables和axis是配合使用的
        使用lables参数时，index和columns参数是不允许使用的
        """
        # columns在_meta drop 
        # index在sql中drop
        # if labels:
        if axis in [0, "index"]: # labels 作用于index上
            if columns: # 当columns为空的时候，drop会报错
                meta = self._meta.drop(columns=columns)
            else:
                meta = self._meta.copy()
        else: # labels 作用于columns上
            meta = self._meta.drop(labels=labels, axis=axis, columns=columns)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(labels=labels, axis=axis, index=index).drop)
        return rdf

    def drop_duplicates(self, subset=None, keep=False):
        meta = self._meta.drop_duplicates(subset=subset, keep=keep)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and keep != False:
            raise ValueError("'keep' can only be False if you choose MOXE as Backend Engine.")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(subset=subset, keep=keep).drop_duplicates)
        return rdf

    def reset_index(self, level=None, drop=False):
        meta = self._meta.reset_index(level=level, drop=drop)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and isinstance(meta.index, pd.RangeIndex):
            raise ValueError("can not reset all index if you choose MOXE as Backend Engine.")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(level=level, drop=drop).reset_index)
        return rdf

    def set_index(self, keys, drop=True, append=False):
        meta = self._meta.set_index(keys=keys, drop=drop, append=append)
        if not drop:
            utils.fix_index_names(meta, repeatable=False)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(keys=keys, drop=drop, append=append).set_index)
        return rdf

    def rename(self, columns):
        # 延迟基本不可能就地修改
        meta = self._meta.copy().rename(columns=columns)
        utils.fix_column_names(meta, repeatable=False)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(columns=columns).rename)
        return rdf

    def sample(self, n=5, seed=0):
        meta = self._meta.copy()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(n=n, seed=seed).sample)
        return rdf

    def head(self, n=5):
        """
        Return the first `n` rows.
        This function returns the first `n` rows for the object based
        on position. It is useful for quickly testing if your object
        has the right type of data in it.
        For negative values of `n`, this function returns all rows except
        the last `n` rows, equivalent to ``df[:-n]``.
        Parameters
        ----------
        n : int, default 5
            Number of rows to select.
        Returns
        -------
        same type as caller
            The first `n` rows of the caller object.
        See Also
        --------
        DataFrame.tail: Returns the last `n` rows.
        Examples
        --------
        >>> df = pd.DataFrame({'animal': ['alligator', 'bee', 'falcon', 'lion',
        ...                    'monkey', 'parrot', 'shark', 'whale', 'zebra']})
        >>> df
              animal
        0  alligator
        1        bee
        2     falcon
        3       lion
        4     monkey
        5     parrot
        6      shark
        7      whale
        8      zebra
        Viewing the first 5 lines
        >>> df.head()
              animal
        0  alligator
        1        bee
        2     falcon
        3       lion
        4     monkey
        Viewing the first `n` lines (three in this case)
        >>> df.head(3)
              animal
        0  alligator
        1        bee
        2     falcon
        For negative values of `n`
        >>> df.head(-3)
              animal
        0  alligator
        1        bee
        2     falcon
        3       lion
        4     monkey
        5     parrot
        """
        meta = self._meta.head(n)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(n=n).head)
        return rdf

    # def tail(self, n=5, rows_count=100):
    #     meta = self._meta.head(n)
    #     rdf = new_rapidspy_object(meta, self.backend_sql)
    #     rdf.put(dependencies=[self], op=self._create_method_instance(n=n, rows_count=rows_count).tail)
    #     return rdf

    # ----------------------------------------------------------------
    # Missing data handling
    # ----------------------------------------------------------------
    def isna(self):
        return self.isnull()

    def isnull(self):
        meta = self._meta.isnull()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().isnull)
        return rdf

    def notna(self):
        return self.notnull()

    def notnull(self):
        meta = self._meta.notnull()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().notnull)
        return rdf

    def dropna(self, how='any'):
        meta = self._meta.dropna(how=how)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(how=how).dropna)
        return rdf

    def fillna(self, value):
        # value: scalar, dict {colname: to_replace_value}
        meta = self._meta.fillna(value=value)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(value=value).fillna)
        return rdf

    def replace(self, to_replace, value):
        # to_replace: dict, {colname: to_replace_value}
        meta = self._meta.replace(to_replace=to_replace, value=value)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(to_replace=to_replace, value=value).replace)
        return rdf

    # ----------------------------------------------------------------
    # Reshaping /
    # sorting /
    # transposing
    # ----------------------------------------------------------------
    def sort_values(self, by, ascending=True):
        meta = self._meta.sort_values(by=by, ascending=ascending)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(by=by, ascending=ascending).sort_values)
        return rdf

    def sort_index(self, level=None, ascending=True):
        meta = self._meta.sort_index(level=level, ascending=ascending)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(level=level, ascending=ascending).sort_index)
        return rdf

    # ----------------------------------------------------------------
    # Combining / joining / merging
    # ----------------------------------------------------------------
    def assign(self, **kwargs):
        for k in kwargs.keys():
            if k in self.index.names:
                raise ValueError(f"'{k}' can not be repeated with index_name.")
        pd_kwargs = {k: v._meta if isinstance(v, Frame) else v for k, v in kwargs.items()}
        meta = self._meta.assign(**pd_kwargs)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(kwargs=kwargs).assign)
        return rdf

    def merge(self, right, how="inner", on=None, left_on=None, right_on=None) -> "DataFrame":
        # left_on和right_on 得到的结果会忽略两个对象的index，新的对象创建新的index
        # 当left_index和right_on混用时，right_on有三种情况，全为column，全为index_name，或者混合，三种情况会得到三种不同的结果
        meta = self._meta.merge(right._meta, how=how, on=on, left_on=left_on, right_on=right_on)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        left_on, right_on = (on, on) if on is not None else (left_on, right_on)
        rdf.put(dependencies=[self, right], op=self._create_method_instance(how=how, left_on=left_on, right_on=right_on).merge)
        return rdf

    def concat(self, obj, axis=0, ignore_index=False):
        # axis=1暂未实现
        meta = pd.concat([self._meta, obj._meta], axis=axis, ignore_index=ignore_index)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and ignore_index == True:
            raise ValueError("'ignore_index' can only be False if you choose MOXE as Backend Engine.")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        if axis in [0, "index"]:
            rdf.put(dependencies=[self, obj], op=self._create_method_instance(ignore_index=ignore_index).concat_by_index)
        else: # 暂未实现
            rdf.put(dependencies=[self, obj], op=self._create_method_instance(ignore_index=ignore_index).concat_by_columns)
        return rdf

    # ----------------------------------------------------------------
    # Binary Operator functions
    # ----------------------------------------------------------------
    def add(self, other):
        return self.__add__(other)

    def sub(self, other):
        return self.__sub__(other)

    def mul(self, other):
        return self.__mul__(other)

    def div(self, other):
        return self.__truediv__(other)

    def __div__(self, other):
        return self.__truediv__(other)

    def truediv(self, other):
        return self.__truediv__(other)

    def floordiv(self, other):
        return self.__floordiv__(other)

    def mod(self, other):
        return self.__mod__(other)

    def pow(self, other):
        return self.__pow__(other)

    def radd(self, other):
        return self.__radd__(other)

    def rsub(self, other):
        return self.__rsub__(other)

    def rmul(self, other):
        return self.__rmul__(other)

    def rdiv(self, other):
        return self.__rtruediv__(other)

    def __rdiv__(self, other):
        return self.__rtruediv__(other)

    def rtruediv(self, other):
        return self.__rtruediv__(other)

    def rfloordiv(self, other):
        return self.__rfloordiv__(other)

    def rmod(self, other):
        return self.__rmod__(other)

    def rpow(self, other):
        return self.__rpow__(other)

    def __neg__(self):
        meta  = self._meta.__neg__()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance().neg)
        return rdf

    def __add__(self, other):
        # if isinstance(other, numbers.Real):
        # return NotImplemented
        meta = self._meta.add(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).add)
        return rdf

    def __sub__(self, other):
        meta = self._meta.sub(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).sub)
        return rdf

    def __mul__(self, other):
        meta = self._meta.mul(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).mul)
        return rdf

    def __truediv__(self, other):
        meta = self._meta.truediv(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).truediv)
        return rdf

    def __floordiv__(self, other):
        meta = self._meta.floordiv(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).floordiv)
        return rdf

    def __mod__(self, other):
        meta = self._meta.mod(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).mod)
        return rdf

    def __pow__(self, other):
        meta = self._meta.pow(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).pow)
        return rdf

    def __radd__(self, other):
        meta = self._meta.radd(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).radd)
        return rdf

    def __rsub__(self, other):
        meta = self._meta.rsub(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rsub)
        return rdf

    def __rmul__(self, other):
        meta = self._meta.rmul(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rmul)
        return rdf

    def __rtruediv__(self, other):
        meta = self._meta.rtruediv(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rtruediv)
        return rdf

    def __rfloordiv__(self, other):
        meta = self._meta.rfloordiv(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rfloordiv)
        return rdf

    def __rmod__(self, other):
        meta = self._meta.rmod(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rmod)
        return rdf

    def __rpow__(self, other):
        meta = self._meta.rpow(other)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).rpow)
        return rdf

    def lt(self, other):
        return self < other

    def le(self, other):
        return self <= other

    def gt(self, other):
        return self > other

    def ge(self, other):
        return self >= other

    def eq(self, other):
        return self == other

    def ne(self, other):
        return self != other

    def __lt__(self, other):
        meta = self._meta < other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).lt)
        return rdf

    def __le__(self, other):
        meta = self._meta <= other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).le)
        return rdf

    def __gt__(self, other):
        meta = self._meta > other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).gt)
        return rdf
        
    def __ge__(self, other):
        meta = self._meta >= other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).ge)
        return rdf

    def __eq__(self, other):
        meta = self._meta == other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).eq)
        return rdf

    def __ne__(self, other):
        meta = self._meta != other
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(other=other).ne)
        return rdf

    def to_pandas(self):
        if not self.computed:
            self.compute()
        meta = self._meta.copy()
        # if self.backend_sql.BACKEND_TYPE == "MOXE":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.upper())
        # elif self.backend_sql.BACKEND_TYPE == "POSTGRES":
        #     meta = utils.lower_or_upper_meta_names(meta, func=lambda x: x.lower())
        index_col = meta.index.names
        columns = meta.columns
        pdf = pd.read_sql_table(self.table, con=self.backend_sql.connectable, index_col=index_col, columns=columns)
        pdf.columns = self.columns
        pdf = pdf.astype(self.dtypes, copy=False, errors="ignore")
        pdf.index.names = self.index.names
        return pdf

        col_expression = ", ".join([f"i{ii}" for ii in range(self.index.nlevels)])
        col_expression += ", " + ", ".join([f"c{ci}" for ci, col_name in enumerate(self.columns)])
        sql = f"SELECT {col_expression} FROM {self.table};"
        print(sql)
        data = self.backend_sql.fetch_sql(sql)

        print(data)
        if type(self.index) is pd.MultiIndex:
            index = pd.MultiIndex.from_tuples([dat[:self.index.nlevels] for dat in data], names=self.index.names)
        else:
            index = pd.Index([dat[0] for dat in data], name=self.index.name)
        data = [dat[self.index.nlevels:] for dat in data]
        print(data)
        return pd.DataFrame(data=data, index=index, columns=self.columns)
        

    def __repr__(self) -> str:
        # return f"<DataFrame: {self.table}>"
        if not self.computed:
            return self._meta.iloc[:0].__repr__()
        rows_count = len(self)
        if rows_count <= 60:
            pdf = self.to_pandas()
        else:
            pdf = self.head().to_pandas()
        return pdf.__repr__()

    def __str__(self) -> str:
        return self.__repr__()
    
    def _repr_html_(self):
        if not self.computed:
            return self._meta.iloc[:0]._repr_html_()
        rows_count = len(self)
        if rows_count <= 60:
            pdf = self.to_pandas()
        else:
            pdf = self.head().to_pandas()
        return pdf._repr_html_()

    # @classmethod
    # def from_schema(
    #     cls,
    #     data,
    #     index=None,
    #     exclude=None,
    #     columns=None,
    #     coerce_float=False,
    #     nrows=None,
    # ) -> "DataFrame":
    #     if columns is not None:
    #         columns = ensure_index(columns)

    #     if is_iterator(data):
    #         if nrows == 0:
    #             return cls()
    #         try:
    #             first_row = next(data)
    #         except StopIteration:
    #             return cls(index=index, columns=columns)

    # ----------------------------------------------------------------
    # For AIworkflow
    # ----------------------------------------------------------------

    def iloc_setitem(self, value, iindexer=None, cindexer=None):
        iindexer = iindexer if iindexer is not None else slice(None)
        cindexer = cindexer if cindexer is not None else slice(None)
        if iindexer != slice(None) and self.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("'iloc_setitem' only supports selecting columns if you choose MOXE as Backend Engine.")
        meta = self._meta.copy()
        meta.iloc[:, cindexer] = value
        meta = meta.astype(self.dtypes, errors="ignore")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(value=value, iindexer=iindexer, cindexer=cindexer).iloc_setitem)
        return rdf

    def loc_setitem(self, value, iindexer=None, cindexer=None):
        iindexer = iindexer if iindexer is not None else slice(None)
        cindexer = cindexer if cindexer is not None else slice(None)
        meta = self._meta.copy()
        meta.loc[:, cindexer] = value
        meta = meta.astype(self.dtypes, errors="ignore")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(value=value, iindexer=iindexer, cindexer=cindexer).loc_setitem)
        return rdf

    def filter_by_conditions(self, conditions, conjunction="and", mask=False):
        meta = self._meta.copy()
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(conditions=conditions, conjunction=conjunction, mask=mask).filter_by_conditions)
        return rdf

    def random_split(self, rate, seed=0):
        meta = self._meta.copy()
        rdf1 = new_rapidspy_object(meta, self.backend_sql)
        rdf1.put(dependencies=[self], op=self._create_method_instance(rate=rate, seed=seed).random_split)
        meta = self._meta.copy()
        rdf2 = new_rapidspy_object(meta, self.backend_sql)
        rdf2.put(dependencies=[self], op=self._create_method_instance(rate=rate, seed=seed).random_split2)
        return rdf1, rdf2

    def save_duplicates(self, subset=None, keep=False):
        meta = self._meta.drop_duplicates(subset=subset, keep=keep)
        if self.backend_sql.BACKEND_TYPE == "MOXE" and keep != False:
            raise ValueError("'keep' can only be False if you choose MOXE as Backend Engine.")
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self], op=self._create_method_instance(subset=subset, keep=keep).save_duplicates)
        return rdf

    def concat_by_ix(self, obj):
        if self.backend_sql.BACKEND_TYPE == "MOXE":
            raise ValueError("not support API if you choose MOXE as Backend Engine.")
        meta = pd.concat([self._meta.reset_index(drop=True), obj._meta.reset_index(drop=True)], axis=1)
        rdf = new_rapidspy_object(meta, self.backend_sql)
        rdf.put(dependencies=[self, obj], op=self._create_method_instance().concat_by_ix)
        return rdf
