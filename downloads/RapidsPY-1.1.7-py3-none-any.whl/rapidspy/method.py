import datetime
import numpy as np
from rapidspy.frame import DataFrame
from rapidspy.series import Series


class RapidsPYMethodBase():

    @classmethod
    def instance_base(cls):
        if not hasattr(cls, "_instance_base"):
            cls._instance_base = cls()
        return cls._instance_base

    @classmethod
    def instance(cls):
        if not hasattr(cls, "_instance"):
            cls._instance = cls()
        return cls._instance

    def _get_case_sensitive(self, col, table=None):
        # 期望是写表的时候，能写入和Python相同大小写的列名。
        # 但对PG来说，如果写入了大写列名，下次使用必须使用双引号。
        # 现在想要大小写敏感的形式
        if table:
            # return f'"{table}"."{col}"' # MOXE不支持
            return f'{table}."{col}"'
        return f'"{col}"'

    def _get_row_number_expression(self):
        raise NotImplementedError

    def _new_table_ix(self):
        raise NotImplementedError

    def _create_table_ix(self, create_ix=False):
        return self._new_table_ix(create_ix=create_ix)

    def _create_table_ii(self, out_ii, change_map=None):
        table_ii = self._get_table_col(out_cols=out_ii, change_map=change_map)
        return table_ii

    def _create_table_ci(self, out_ci, change_map=None, has_index=True):
        table_ci = self._get_table_col(out_cols=out_ci, change_map=change_map)
        if table_ci and has_index:
            table_ci = ", " + table_ci
        return table_ci

    def _get_table_col(self, out_cols, change_map=None):
        if change_map is None: # change_map为None时，大小写OK
            return ", ".join([self._get_case_sensitive(col) for col in out_cols])
        col_list = []
        for col in out_cols:
            if col in change_map: # change_map中的可能是表达式
                col_list.append(f'{change_map[col]} as {self._get_case_sensitive(col)}')
            else: # col在change_map中找不到时，大小写OK
                col_list.append(self._get_case_sensitive(col))
        return ", ".join(col_list)

    def _get_one_col(self, out_col, in_exp): # in_exp可能是表达式
        return f'{in_exp} as "{out_col}"'

    def _get_orderby_expression(self, cols, desc=False):
        ob_exp = "{col}{desc}"
        if not isinstance(desc, (list, tuple)):
            desc = [desc] * len(cols)
        return ", ".join([ob_exp.format(col=self._get_case_sensitive(cols[i]), desc=" DESC" if desc[i] else "") for i in range(len(cols))])

    def _get_groupby_expression(self, cols):
        return ", ".join(self._get_case_sensitive(col) for col in cols)
        
    def _get_clauses_by_func(self, ns, rdf, func):
        # df to series，index是原来的列名， func为一个方法
        # "select 1 as ix, 'c0' as i0, min(c0) as new_c0"
        clauses = []
        for ix, index_value in enumerate(ns.index):
            col_expression = f"{self._value_to_sql(ix)} as ix, " # TODO
            change_map = {ns.index.name: self._value_to_sql(index_value)}
            col_expression += self._create_table_ii(out_ii=ns.index.names, change_map=change_map)
            change_map = {ns.name: self._get_func_expression(func=func, c=self._get_case_sensitive(index_value), dtype=rdf.dtypes[index_value])}
            col_expression += self._create_table_ci(out_ci=[ns.name], change_map=change_map)
            clauses.append(f"SELECT {col_expression} FROM {rdf.table}")
        return clauses

    def _get_clauses_by_out_index(self, out_index, out_ci, in1_dtypes, in1_table):
        # "select 1 as ix, 'min' as i0, min(c0) as c0, min(c1) as c1"
        clauses = []
        for ix, index_value in enumerate(out_index):
            col_expression = f"{self._value_to_sql(ix)} as ix, " # TODO
            change_map = {out_index.name: self._value_to_sql(index_value)}
            col_expression += self._create_table_ii(out_ii=out_index.names, change_map=change_map)
            change_map = {col_name: self._get_func_expression(func=index_value, c=self._get_case_sensitive(col_name), dtype=in1_dtypes[col_name]) for col_name in out_ci}
            col_expression += self._create_table_ci(out_ci=out_ci, change_map=change_map)
            clauses.append(f"SELECT {col_expression} FROM {in1_table}")
        return clauses

    def _union_all(self, clauses, sort=True):
        sql = " Union All ".join(clauses)
        if sort:
            sql += " order by ix"
        return sql

    def _get_case_expression(self, con, bins, labels):
        exp = "CASE"
        for i, bin in enumerate(bins):
            # exp += f" WHEN cast({c0} as integer) <= {bin} THEN '{labels[i]}'"
            if i <= 0:
                exp += f" WHEN {con} <= {bin} THEN null"
            else:
                exp += f" WHEN {con} <= {bin} THEN '{labels[i-1]}'"

        exp += " END"
        return exp

    def _get_sql_type(self, dtype):
        raise NotImplementedError

    # ----------------------------------------------------------------
    # function
    # ----------------------------------------------------------------

    def _get_if_expression(self, condition, true, false):
        raise NotImplementedError

    def _get_func_expression(self, func, c, dtype=None, **kwargs):
        """
        只接受一个参数的函数，因此，无需考虑多参数的是否同源的问题
        """
        func = func.upper()
        if func == "COUNT":
            return self._count(c, dtype)
        if func == "MIN":
            return self._min(c, dtype)
        if func == "MAX":
            return self._max(c, dtype)
        if func == "SUM":
            return self._sum(c, dtype)
        if func == "MEAN":
            return self._mean(c, dtype)
        if func == "STD":
            return self._std(c, dtype)
        if func == "VAR":
            return self._var(c, dtype)

        if func == "ALL":
            return self._all(c, dtype)
        if func == "ANY":
            return self._any(c, dtype)
        if func == "IS_UNIQUE":
            return self._is_unique(c, dtype)
        if func == "NUNIQUE":
            return self._nunique(c, dtype)
        if func == "UNIQUE":
            return self._unique(c, dtype)

        if func == "ABS":
            return self._abs(c, dtype)
        if func == "ROUND":
            return self._round(c, dtype, **kwargs)

        # if func == "PERCENTILE25":
        if func == "25%":
            return self._percentile25(c, dtype)
        # if func == "PERCENTILE50":
        if func == "50%":
            return self._percentile50(c, dtype)
        # if func == "PERCENTILE75":
        if func == "75%":
            return self._percentile75(c, dtype)
        if func == "STRJOIN":
            return self._strjoin(c, dtype, **kwargs)

        if func == "ISNULL":
            return self._isnull(c, dtype)
        if func == "NOTNULL":
            return self._notnull(c, dtype)

        if func == "SLICE":
            return self._slice(c, dtype, **kwargs)

        if func == "SPLIT_PART":
            return self._split_part(c, dtype, **kwargs)


    def _count(self, c, dtype):
        return f"COUNT({c})"

    def _min(self, c, dtype):
        return f"MIN({c})"

    def _max(self, c, dtype):
        return f"MAX({c})"

    def _sum(self, c, dtype): # postgres sum int得到的结果是decimal
        if dtype in [np.bool, bool]:
            return f"SUM(cast({c} as integer)) * 1.0"
        return f"SUM({c}) * 1.0"

    def _mean(self, c, dtype):
        return f"SUM({c}) * 1.0 / COUNT({c})"

    def _std(self, c, dtype):
        return f"stddev_samp({c})"

    def _var(self, c, dtype):
        return f"var_samp({c})"

    def _all(self, c, dtype):
        return self._get_if_expression(f"MIN({c}) != 0", "true", "false")

    def _any(self, c, dtype):
        return self._get_if_expression(f"MAX({c}) != 0", "true", "false")

    def _is_unique(self, c, dtype):
        return self._get_if_expression(f"count(distinct({c})) = count({c})", "true", "false")

    def _nunique(self, c, dtype):
        return f"COUNT(distinct({c}))"

    def _unique(self, c, dtype):
        return f"distinct({c})"

    def _abs(self, c, dtype):
        return f"ABS({c})"
    
    def _round(self, c, dtype, decimals=0):
        raise NotImplementedError

    def _percentile25(self, c, dtype):
        return f"percentile_disc(0.25) within group (order by {c})"

    def _percentile50(self, c, dtype):
        return f"percentile_disc(0.5) within group (order by {c})"

    def _percentile75(self, c, dtype):
        return f"percentile_disc(0.75) within group (order by {c})"

    def _strjoin(self, c, dtype, symbol):
        return f"string_agg(cast({c} as varchar), '{symbol}')"

    def _isnull(self, c, dtype):
        return f"{c} is null"

    def _notnull(self, c, dtype):
        return f"{c} is not null"

    # str func
    def _slice(self, c, dtype, start, stop, step):
        # PG在start小于等于0非常复杂，必须将其转为正整数，当start小于等于0时，max(start + char_length({c}) + 1, 1)
        # MOXE符合Python认知，但唯一一点，start不能等于0，等于0时会返回空字符串
        if start in [None, 0] and stop is None:
            return c
        if stop is None:
            if start >= 0:
                start += 1
            else:
                start = f"{start + 1} + char_length({c})"
                start = self._get_if_expression(f"{start} < 1", 1, start)
            return f"substring({c} from {start})"
        if start >= 0:
            start += 1
            count = stop + 1 - start
        else:
            start = f"{start + 1} + char_length({c})" # 重新计算start，将其转为正整数
            start = self._get_if_expression(f"{start} < 1", 1, start)
            count = f"({stop + 1}) - ({start})"
        if stop < 0:
            count = f"{count} + char_length({c})"
            count = self._get_if_expression(f"{count} < 0", 0, count)
        return f"substring({c} from {start} for {count})" 

    def _split_part(self, c, dtype, pat, n):
        pat = self._value_to_sql(pat)
        n += 1
        return f"split_part({c}, {pat}, {n})"

    # binary func
    def _get_binary_expression(self, func, c1, c2, d1, d2=None):
        func(c1, c2, d1, d2)

    def _add(self, c1, c2, d1, d2=None):
        return f"{c1}" + f" + {c2}"

    def _sub(self, c):
        pass

    def _get_datetime_expression():
        raise NotImplementedError 
    # ----------------------------------------------------------------
    # indexing
    # ----------------------------------------------------------------
    def _iloc_iindexer(self, in1, iindexer):
        where_expression = None
        if isinstance(iindexer, list):
            iindexer_str = ", ".join(map(str, iindexer))
            where_expression = f"ix in ({iindexer_str})"
        elif isinstance(iindexer, slice):
            # slice 有start, stop, step三个属性
            if iindexer == slice(None):
                where_expression = "true"
            else:
                where_list= []
                iindexer_start = iindexer.start or 0
                where_list.append(f"ix >= {iindexer_start}")
                if iindexer.stop:
                    where_list.append(f"ix < {iindexer.stop}")
                if iindexer.step:
                    where_list.append(f"(ix - {iindexer_start}) %% {iindexer.step} = 0")
                where_expression = " and ".join(where_list)
        else: # int
            iindexer = self._value_to_sql(iindexer)
            where_expression = f"ix = {iindexer}"
        return where_expression

    def _loc_iindexer(self, in1, iindexer):
        # 暂且仅支持只有一个index
        where_expression = None
        first_index_name = self._get_case_sensitive(in1.index.names[0])
        if isinstance(iindexer, Series):
            where_expression = in1._get_condition(iindexer)
        elif isinstance(iindexer, list):
            iindexer_str = ", ".join(map(str, iindexer))
            # where_expression = f"i0 in ({iindexer_str})" # 默认了只有i0
            where_expression = f"{first_index_name} in ({iindexer_str})" # 默认了只有i0
        elif isinstance(iindexer, slice): # 不支持slice，所有slice都当做slice(None)
            where_expression = "true"
        else: # int, str, tuple暂不支持
            # where_expression = f"i0 = {iindexer}" # 默认了只有i0
            iindexer = self._value_to_sql(iindexer)
            if iindexer == "null":
                where_expression = f"{first_index_name} is {iindexer}" # 默认了只有i0
            else:
                where_expression = f"{first_index_name} = {iindexer}" # 默认了只有i0
        return where_expression

    # ----------------------------------------------------------------
    # Other
    # ----------------------------------------------------------------
    def _value_to_sql(self, value):
        raise NotImplementedError

    def _accelerate(self, src):
        pass


class PostgresMethodBase(RapidsPYMethodBase):
    
    # @classmethod
    # def instance(cls):
    #     if hasattr(PostgresMethodBase, "_instance"):
    #         PostgresMethodBase._instance = PostgresMethodBase()
    #     return PostgresMethodBase._instance

    def _get_row_number_expression(self):
        return "row_number() over() -1"

    def _new_table_ix(self, create_ix):
        return f"{self._get_row_number_expression()} as ix, " if create_ix else "ix, "
    
    def _get_where_expression(self, out, in1):
        pass

    def _get_if_expression(self, condition, true, false):
        return f"CASE WHEN {condition} THEN {true} ELSE {false} END"

    def _get_median_sql(self, ns, rdf):
        sql = "with"
        median_sql_list = []
        for ix, index_value in enumerate(ns.index):
            col_name = self._get_case_sensitive(index_value)
            table0 = f"{ns.table}_{ix*4+0}"
            table1 = f"{ns.table}_{ix*4+1}"
            table2 = f"{ns.table}_{ix*4+2}"
            table3 = f"{ns.table}_{ix*4+3}"
            median_sql_list.append(f"""
                {table0} as (select {col_name} as c0 from {rdf.table} order by c0),
                {table1} as (select row_number() over() as ix, c0 from {table0}),
                {table2} as (select floor((count(*) + 1) / 2.0) as ix from {table1} union all select ceil((count(*) + 1) / 2.0) as ix from {table1}),
                {table3} as (select {table1}.c0 as c0 from {table2} left join {table1} on {table2}.ix = {table1}.ix)"""
            )
        sql += ",".join(median_sql_list)
        clauses = []
        for ix, index_value in enumerate(ns.index):
            table3 = f"{ns.table}_{ix*4+3}"
            col_expression = f"{self._value_to_sql(ix)} as ix, "
            change_map = {ns.index.name: self._value_to_sql(index_value)}
            col_expression += self._create_table_ii(out_ii=ns.index.names, change_map=change_map)
            change_map = {ns.name: f"SUM(c0) / 2.0"}
            col_expression += self._create_table_ci(out_ci=[ns.name], change_map=change_map)
            clauses.append(f"SELECT {col_expression} FROM {table3}")
        sql += self._union_all(clauses, sort=False)
        return sql

    def _round(self, c, dtype, decimals=0):
        return f"ROUND(cast({c} as numeric), {decimals})"

    def _get_datetime_expression(self, func_name):
        if func_name in ['year', 'month', 'day', 'hour', 'minute', 'second', 'week', 'quarter']:
            return f"extract({func_name} from " + "{fa_con})"
        if func_name == "total_seconds":
            return "extract(epoch from {fa_con})"
        if func_name == "days":
            return "floor(extract(epoch from {fa_con}) / (24 * 3600))"
        if func_name == "seconds":
            return "extract(hour from {fa_con}) * 60 * 60 + extract(minute from {fa_con}) * 60  + extract(second from {fa_con})"
            # return "extract(epoch from {fa_con}) %% (24 * 3600)"
        if func_name in ["date"]:
            # return "TO_CHAR({fa_con}, 'YYYY-MM-DD')"
            return "to_date(to_char({fa_con}, 'yyyy-mm-dd'), 'yyyy-mm-dd')"
        return ""

    # ----------------------------------------------------------------
    # Other
    # ----------------------------------------------------------------
    def _value_to_sql(self, value): # str时，需要重复%
        if value is None:
            return "null"
        if isinstance(value, datetime.datetime):
            return f"cast('{value.strftime('%Y-%m-%d %H:%M:%S')}' as timestamp)"
        if isinstance(value, datetime.timedelta):
            return f"interval '{value}'"
        if isinstance(value, bool):
            return str(value).lower()
        if isinstance(value, str):
            value = value.replace("%", "%%")
            value = value.replace("'", "''")
            return f"'{value}'"
        if isinstance(value, list):
            tmp = ", ".join(map(self._value_to_sql, value))
            return f"({tmp})"
        return str(value)

    def _get_sql_type(self, dtype):
        dtype = dtype.lower()
        if dtype.startswith("int"):
            return "integer"
        elif dtype.startswith("float"):
            return "numeric"
        elif dtype.startswith("bool"):
            return "boolean"
        elif dtype in ["object", "str", "string", "varchar"]:
            return "varchar"
        elif dtype.startswith("datetime"):
            return "timestamp"
        elif dtype.startswith("timedelta"):
            return "interval"
        return dtype


class MoxeMethodBase(RapidsPYMethodBase):

    def _get_row_number_expression(self):
        return ""

    def _new_table_ix(self, create_ix):
        return ""

    def _get_if_expression(self, condition, true, false):
        return f"IF({condition}, {true}, {false})"

    def _get_datetime_expression(self, func_name):
        if func_name in ['year', 'month', 'day', 'hour', 'minute', 'second', 'week', 'quarter']:
            return f"extract({func_name} from " + "{fa_con})"
        if func_name == "total_seconds":
            return "{fa_con}"
        if func_name == "days":
            return "floor({fa_con} / (24 * 3600))"
        if func_name == "seconds":
            return "{fa_con} % (24 * 3600)"
        if func_name == "date":
            return "cast(year({fa_con}) as varchar) + '-' + if(month({fa_con}) < 10, '0' + cast(month({fa_con}) as varchar), cast(month({fa_con}) as varchar)) + '-' + if(day({fa_con}) < 10, '0' + cast(day({fa_con}) as varchar) , cast(day({fa_con}) as varchar)) "
        return ""

    def _sum(self, c, dtype):
        if dtype in [np.bool, bool]:
            return f"SUM(IF({c}, 1, 0))"
        return f"SUM({c})"

    def _round(self, c, dtype, decimals=0):
        return f"ROUND(cast({c} as float), {decimals})"

    def _split_part(self, c, dtype, pat, n):
        pat = self._value_to_sql(pat)
        return f"IF(position({pat} in {c}) != 0, substring({c}, 1, position({pat} in {c}) - 1), {c})"

    # ----------------------------------------------------------------
    # Other
    # ----------------------------------------------------------------
    def _value_to_sql(self, value): # str时，不需要重复%
        if value is None:
            return "null"
        if isinstance(value, datetime.datetime):
            return f"cast('{value.strftime('%Y-%m-%d %H:%M:%S')}' as timestamp)"
        if isinstance(value, datetime.timedelta):
            return f"interval '{value}'"
        if isinstance(value, bool):
            return str(value).lower()
        if isinstance(value, str):
            value = value.replace("'", "''")
            return f"'{value}'"
        if isinstance(value, list):
            tmp = ", ".join(map(self._value_to_sql, value))
            return f"({tmp})"
        return str(value)

    def _get_sql_type(self, dtype):
        dtype = dtype.lower()
        if dtype.startswith("int"):
            return "integer"
        elif dtype.startswith("float"):
            return "float"
        elif dtype.startswith("bool"):
            return "boolean"
        elif dtype in ["object", "str", "string", "varchar"]:
            return "varchar"
        elif dtype.startswith("datetime"):
            return "timestamp"
        elif dtype.startswith("timedelta"):
            return "interval"
        return dtype