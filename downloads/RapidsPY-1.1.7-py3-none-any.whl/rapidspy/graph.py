

class Node:

    def __init__(self, id, dependencies=None, op = None, computed=False):
        self.id = id
        self.op = op
        self.computed = computed
        self.expression = None
        if computed:
            self.expression = self.id
        if dependencies is None:
            self.dependencies = []
        else:
            self.dependencies = dependencies
    
    def __str__(self):
        return str(self.id)

    def dfs(self, grey_set, black_set):
        print("visit:", self.id, "depends:", *self.dependencies)
        if self.computed:
            return 
        if id(self) in black_set:
            return 
        if id(self) in grey_set:
            print(f"cycle at {self}")
            return True
        
        # if self in dfs_set:
        #     return True
        # dfs_set.add(self)
        grey_set.add(id(self))

        for father in self.dependencies:
            if father.dfs(grey_set, black_set):
                return True
        
        black_set.add(id(self))
        if len(self.dependencies) == 0:
            self.expression = self.id
        elif len(self.dependencies) == 1:
            self.expression = f"({self.dependencies[0].expression} {self.op})"
        else:
            self.expression = f"({self.dependencies[0].expression} {self.op} {self.dependencies[1].expression})"
        # print(self)

    def compute(self):
        if self.computed:
            return self
            
        gray_set = set()
        black_set = set()
        # self.computed = True
        self.dfs(gray_set, black_set)
        
        return self.expression

if __name__ == "__main__":
    nodes = []
    for i in range(8):
        nodes.append(Node(i))

    node1 = Node(1, None, None, True)
    node2 = Node(2, [node1], '+ 2', False)
    node0 = Node(0, [node2], '- 0', False)
    node3 = Node(3, [node2], '* 3', False)
    node4 = Node(4, [node3], '\ 4', False)
    # node2.dependencies = [node1, node4]  cycle 判断
    node5 = Node(5, [node2, node4], '+', False)
    node6 = Node(6, [node2, node5], '/', False)
    node7 = Node(7, [node6, node4], '*', False)

    print(node7.compute())
    # print(node7.compute())
    # node0.compute()

    


