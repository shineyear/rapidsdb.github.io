from rapidspy.frame_method import PostgresFrameMethod, MoxeFrameMethod
from rapidspy.series_method import PostgresSeriesMethod, MoxeSeriesMethod


class MethodFactoryBase():

    def create_frame_method(self, **kwargs):
        return NotImplementedError

    def create_series_method(self, **kwargs):
        return NotImplementedError


class PostgresMethodFactory(MethodFactoryBase):

    @classmethod
    def instance(cls):
        if not hasattr(PostgresMethodFactory, "_instance"):
            PostgresMethodFactory._instance = PostgresMethodFactory()
        return PostgresMethodFactory._instance

    def create_frame_method(self, **kwargs):
        return PostgresFrameMethod(**kwargs)

    def create_series_method(self, **kwargs):
        return PostgresSeriesMethod(**kwargs)


class MoxeMethodFactory(MethodFactoryBase):

    @classmethod
    def instance(cls):
        if not hasattr(MoxeMethodFactory, "_instance"):
            MoxeMethodFactory._instance = MoxeMethodFactory()
        return MoxeMethodFactory._instance

    def create_frame_method(self, **kwargs):
        return MoxeFrameMethod(**kwargs)

    def create_series_method(self, **kwargs):
        return MoxeSeriesMethod(**kwargs)
