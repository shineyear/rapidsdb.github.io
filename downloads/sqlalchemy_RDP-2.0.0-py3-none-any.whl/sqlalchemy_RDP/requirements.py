from sqlalchemy.testing import exclusions, requirements
from sqlalchemy.testing.requirements import SuiteRequirements

class Requirements(SuiteRequirements):
    
    @property
    def order_by_col_from_union(self):
        return exclusions.closed()

    @property
    def cross_schema_fk_reflection(self,aa=None):
        return exclusions.closed()

    @property
    def temp_table_reflection(self):
        return exclusions.closed()

    @property
    def autoincrement_insert(self):
        return exclusions.closed()

    @property
    def independent_connections(self):
        return exclusions.closed()
    
    # duplicate key raises integrity error not support
    @property
    def duplicate_key_raises_integrity_error(self):
        return exclusions.closed()
    
    # RDP do not support foreign keys
    @property
    def foreign_keys(self):
        """Target database must support foreign keys."""
        return exclusions.closed()

    # RDP do not support auto increment
    @property
    def autoincrement_insert(self):
        """target platform generates new surrogate integer primary key values
        when insert() is executed, excluding the pk column."""

        return exclusions.closed()
    # @property
    # def server_side_cursors(self):
    #     return exclusions.open()


    @property
    def datetime(self):
        return exclusions.closed()
    
    @property
    def datetime_microseconds(self):
        return exclusions.closed()
        
    @property
    def timestamp_microseconds(self):
        return exclusions.open()

    @property
    def time(self):
        return exclusions.closed()
    
    @property
    def time_microseconds(self):
        return exclusions.closed()

    @property
    def date(self):
        return exclusions.closed()

    @property
    def text_type(self):
        return exclusions.closed()

    @property
    def precision_numerics_enotation_large(self):
        return exclusions.open()

    @property
    def precision_numerics_many_significant_digits(self):
        return exclusions.closed()

    @property
    def foreign_key_constraint_reflection(self):
        return exclusions.closed()


        

        