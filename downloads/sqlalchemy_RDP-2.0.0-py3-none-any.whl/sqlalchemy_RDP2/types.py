from sqlalchemy import types as sqltypes

'''
Type		|    Default interpretation of size / scale / precision
--------------------------------------------------------------------
INTEGER	    |    Precision in decimal digits (if unspecified: 18)
DECIMAL	    |    Precision in decimal digits, scale in decimal digits (if unspecified: 19, 0)
FLOAT		|    Size of mantissa in binary digits (if unspecified: 53)
TIMESTAMP   |    
VARCHAR	    |    Physical size in bytes (if unspecifed: variable up to 2G)
VARBINARY	|    Physical size in bytes (if unspecified: variable up to 2G)
Boolean
'''
class BOOLEAN(object):
    __visit_name__ = 'BOOLEAN'

# Do not have TINYINT
class TINYINT(sqltypes.INTEGER):
    __visit_name__ = 'TINYINT'

class SMALLINT(sqltypes.SMALLINT):
    __visit_name__ = 'SMALLINT'

class INTEGER(sqltypes.INTEGER):
    __visit_name__ = 'INTEGER'

class BIGINT(sqltypes.BIGINT):
    __visit_name__ = 'BIGINT'

class DECIMAL(sqltypes.DECIMAL):
    __visit_name__ = 'DECIMAL'

class FLOAT(sqltypes.FLOAT):
    __visit_name__ = "FLOAT"

class DATE(sqltypes.DATE):
    __visit_name__ = "DATE"

class TIME(sqltypes.TIME):
    __visit_name__ = "TIME"

class TIMESTAMP(sqltypes.TIMESTAMP):
    __visit_name__ = 'TIMESTAMP'

class DATETIME(sqltypes.DateTime):
    __visit_name__ = 'DATETIME'

# Do not have INTERVAL
class INTERVAL(sqltypes.Interval):
    __visit_name__ = 'INTERVAL'

class VARCHAR(sqltypes.VARCHAR):
    __visit_name__ = 'VARCHAR'

class VARBINARY(sqltypes.VARBINARY):
    __visit_name__ = 'VARBINARY'
