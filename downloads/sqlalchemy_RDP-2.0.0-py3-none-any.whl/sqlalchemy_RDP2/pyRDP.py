"""

.. dialect:: pyRDP2
    :name: pyRDP2
    :dbapi: pyRDP2
    :connectstring: RDP2://<user>:<password>@<host>[:<port>]/<federation>/<catalog>/<schema>

"""
from .base import RDPDialect

class RDPDialect_pyRDP(RDPDialect):

    driver = 'pyRDP2'
    default_paramstyle = 'format'
    description_encoding = None

    # def __init__(self, server_side_cursors=False, **kwargs):
    #     super(RDPDialect_pyRDP, self).__init__(**kwargs)
    #     self.server_side_cursors = server_side_cursors

    # def supports_server_side_cursors(self):
    #     try:
    #         cursors = __import__('pyRDP').cursors
    #         self._sscursor = cursors.SSCursor
    #         return True
    #     except (ImportError, AttributeError):
    #         return False

    @classmethod
    def dbapi(cls):
        import pyRDP2
        pyRDP2.paramstyle = cls.default_paramstyle
        return pyRDP2

    def create_connect_args(self, url):
        kwargs = url.translate_connect_args(username="user")
        kwargs.setdefault("port", 4333)
        kwargs.update(url.query)
        meta_dict = self._parse_url(kwargs.get('database'))
        table_metadata = TableMetaData(meta_dict['catalog'],meta_dict['schema'])

        kwargs.setdefault("federation", meta_dict['federation'])
        kwargs.setdefault("catalog", meta_dict['catalog'])
        kwargs.setdefault("schema", meta_dict['schema'])
        kwargs.setdefault("database", meta_dict['schema'])
  
        if table_metadata.get_catalog():
            self._set_default_catalog(table_metadata.get_catalog())
        if table_metadata.get_schema():
            self._set_default_schema(table_metadata.get_schema())

        return (), kwargs

    def _parse_url(self,url):

        meta_dict = {}
        meta_dict['federation']= None
        meta_dict['catalog']   = None
        meta_dict['schema']    = None

        if url is not None:
            names = url.split('/')
            nums = len(names)
            if nums==3:
                meta_dict['federation']= names[0]
                meta_dict['catalog']   = names[1]
                meta_dict['schema']    = names[2]
            elif nums==2:
                meta_dict['catalog']   = names[0]
                meta_dict['schema']    = names[1]
            elif nums ==1:
                meta_dict['catalog']   = names[0]
            else:
                pass

        return meta_dict

    def is_disconnect(self, error, connection, cursor):
        if connection is None:
            return True
        return connection._closed

class TableMetaData(object):
    def __init__(self,catalog=None,schema=None,name=None):
        self.catalog = catalog
        self.schema  = schema
        self.name    = name
    
    def get_catalog(self):
        return self.catalog

    def get_schema(self):
        return self.schema

    def get_name(self):
        return self.name

dialect = RDPDialect_pyRDP


