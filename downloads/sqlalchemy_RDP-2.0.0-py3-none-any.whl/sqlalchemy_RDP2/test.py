from sqlalchemy import MetaData, create_engine, Table
from sqlalchemy.ext.automap import automap_base
from sqlalchemy.orm import sessionmaker
# declarative_base类维持了一个从类到表的关系
from sqlalchemy.ext.declarative import declarative_base
 
uri = 'RDP2://rapids:rapids@192.168.10.14:34333/'
 
engine = create_engine(uri, echo=False)
metadata = MetaData(engine)
# ①：反射单个表
apply_info = Table('MEMSQL.\"tpchsf1_date\".\"tb001\"', metadata, autoload=True)
apply_info.columns.keys()  # 列出所有的列名
Session = sessionmaker(bind=engine)
session = Session()
rows = session.query(apply_info).all()
