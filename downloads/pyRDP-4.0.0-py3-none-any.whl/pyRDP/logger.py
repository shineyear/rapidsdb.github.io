# -*- coding: utf-8 -*-
import logging
'''
logger component, log some userful information for debug

'''

def Singleton(cls):
    """
    singletion decorator
    :param cls: instance class
    :return: instance class
    """

    _instance = {}

    def _singleton(*args, **kargs):
        if cls not in _instance:
            _instance[cls] = cls(*args, **kargs)
        return _instance[cls]

    return _singleton

@Singleton
class Logger(object):
    def __init__(self,app_name ="pyRDP",log_file_name="pyRDP.log",log_level=logging.ERROR):
        """
        get logger
        :param appName: application name
        :param logFileName: log fiel name
        :return: logger object
        """

        self.app_name = app_name
        self.log_file_name = log_file_name
        self.log_level = log_level

        self.logger = logging.getLogger(self.app_name)
        self.logger.setLevel(self.log_level)

        file_handler = logging.FileHandler(self.log_file_name)
        file_handler.setLevel(self.log_level)

        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(self.log_level)

        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        stream_handler.setFormatter(formatter)

        self.logger.addHandler(file_handler)
        self.logger.addHandler(stream_handler)

    def getLogger(self):
        return self.logger