# -*- coding: utf-8 -*-
import struct

def int2_4bytes(i):
    """
    Encode int to 4 bytes.
    :param number i : input int .
    :return : 4 bytes
    """
    return struct.pack(">I",i)

def bytes2int(bs):
    """
    Decode bytes to int.
    :param bytes bs : input bytes .
    :return : int
    """
    return struct.unpack(">I",bs)

def int2byte(i):
    """
    Encode int to byte.
    :param number i : input int .
    :return : byte
    """
    return struct.pack("!B", i)

def byte2int(b):
    """
    Decode byte to int.
    :param byte b : input byte .
    :return : int
    """
    if isinstance(b, int):
        return b
    else:
        return struct.unpack("!B", b)[0]

def join_bytes(bs):
    if len(bs) == 0:
        return ""
    else:
        rv = bs[0]
        for b in bs[1:]:
            rv += b
        return rv