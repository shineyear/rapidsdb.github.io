# -*- coding: utf-8 -*-
import re
import warnings
import pyRDP.err as err
from pyRDP.logger import Logger
from pyRDP._compat import range_type, text_type, PY2

#: Regular expression for :meth:`Cursor.executemany`.
#: executemany only suports simple bulk insert.
#: You can use it to load large dataset.
RE_INSERT_VALUES = re.compile(
    r"\s*((?:INSERT|REPLACE)\b.+\bVALUES?\s*)(\(\s*(?:%s|%\(.+\)s)\s*(?:,\s*(?:%s|%\(.+\)s)\s*)*\))(\s*(?:ON DUPLICATE.*)?);?\s*\Z",re.IGNORECASE | re.DOTALL)

log = Logger().getLogger()

class Cursor(object):
    '''
    This is the object you use to interact with the database.
    Do not create an instance of a Cursor yourself. Call
    connections.Connection.cursor().
    See `Cursor <https://www.python.org/dev/peps/pep-0249/#cursor-objects>`_ in
    the specification.
    '''
  
    def __init__(self,connection):
        self.connection  = connection
        self.description = None
        self.rownumber   = 0 
        self.rowcount    = -1 #specifies the number of rows that the last .execute*() produced  or affected 
        self.arraysize   = 1 #specifies the number of rows to fetch at a time with .fetchmany()
        self._executed   = None 
        self._result     = None # response result of executed query
        self._rows       = None # all data rows
        self._time_flag  = False
        #self._warnings_handled = False
    
    def close(self):
        """
        Close cursor .
        """
        conn = self.connection
        if conn is None:
            return
        try:
            while self.nextset():
                pass
        finally:
            self.connection = None

    def __enter__(self):
        return self

    def __exit__(self, *exc_info):
        del exc_info
        self.close()

    def __iter__(self):
        return iter(self.fetchone, None)

    #cursor.execute("insert into user values(1, 80, 'zhang')"
    #cursor.execute("insert into user values(%s, %s, %s)",(1,80,"zhang"))
    def execute(self, query, args=None):
        """
        execute SQL statment.
        :param str query : query .
        :param tuple|dict|set args : query args.
        :return : affected row of this execute
        """
        # Befor execute new query , exhanst last result 
        print(query)
        while self.nextset():
            pass

        query = self.mogrify(query, args)

        log.info("[method execute]- sql to server : " + query)

        result = self._query(query)
        self._executed = query

        self._print_execution_info(result)
        return result

    def _print_execution_info(self,rowcount):
        # Boss need print row count and sql execute time here.
        message = None
        if self._time_flag:
            message = "Row count: " + str(rowcount) + ". Sql execution time: " + str(self._get_execute_time()) + "."
        else:
            message = "Row count: " + str(message) + "." 
        print(message)

    def set_time_flag(self, flag):
        self._time_flag = flag

    def mogrify(self, query, args=None):
        """
        Returns the real sql that is sent to the database by calling the execute() method.
        :param str query : query .
        :param tuple|dict|set args : query args.
        :return : real sql .
        """
        conn = self._get_db()

        if args is not None and len(args) != 0:
            query = query % self._escape_args(args, conn)
            
        if not query.endswith(';'):
            query += ';'

        return query
    
    def _escape_args(self, args, conn):

        if isinstance(args, (tuple, list)):
            return tuple(conn.literal(arg) for arg in args)
        elif isinstance(args, dict):
            return {key: conn.literal(val) for (key, val) in args.items()}
        else:
            return conn.escape(args)

    # def _escape_args(self, query, args=None):
    #     conn = self._get_db()

    #     if args is not None:
    #         query_list = re.split('%s',query)
    #         temp_query = ''
    #         for i in range(len(query_list)-1):
    #             temp_query += query_list[i]
    #             if isinstance(args[i:i+1][0],str):
    #                 temp_query += '\''
    #                 temp_query += args[i:i+1][0]
    #                 temp_query += '\''
    #             else:
    #                 temp_query += str(args[i:i+1][0])
    #         temp_query += query_list[-1]
    #         query = temp_query
    #     if not query.endswith(';'):
    #         query += ';'
    #     return query

    def executemany(self, query, args):
        """
        Batch execute .
        :param str query : query .
        :param tuple|dict|set args : query args.
        :return : affected row of this execute
        """
        if not args:
            return

        m = RE_INSERT_VALUES.match(query)
        if m:
            q_prefix = m.group(1) % ()
            q_values = m.group(2).rstrip()
            q_postfix = m.group(3) or ''
            assert q_values[0] == '(' and q_values[-1] == ')'
            return self._do_execute_many(q_prefix, q_values, q_postfix, args)
                                         

        self.rowcount = sum(self.execute(query, arg) for arg in args)

        self._print_execution_info(self.rowcount)
        return self.rowcount

    def _do_execute_many(self, prefix, values, postfix, args):
        conn = self._get_db()
        escape = self._escape_args
        sql = prefix
        rows = 0
        for arg in args:
            v = values % escape(arg, conn)
            sql += v
            sql += ','
        
        sql = sql[:-1]
        log.info("[method executemany]- sql to server : " + sql)
        self.execute(sql + postfix)
        rows = len(arg)
        self.rowcount = rows
        return rows

    def _query(self, q):
        """
        Fetch one row data.
        : return : one row data.
        """
        conn = self._get_db()
        self._last_executed = q
        self._clear_result()
        conn.query(q)
        self._do_get_result()
        return self.rowcount

    def fetchone(self):
        """
        Fetch one row data.
        : return : one row data.
        """
        self._check_executed()
        if self._rows is None or self.rownumber >= len(self._rows):
            return None
        result = self._rows[self.rownumber]
        self.rownumber += 1
        return result

    def fetchmany(self, size=None):
        """
        Fetch number of the result rows.
        : return : size or arraysize data rows.
        """
        self._check_executed()
        if self._rows is None:
            return ()
        end = self.rownumber + (size or self.arraysize)
        result = self._rows[self.rownumber:end]
        self.rownumber = min(end, len(self._rows))
        return result

    def fetchall(self):
        """
        Fetch all the rows.
        : return : all the result set.
        """
        self._check_executed()
        if self._rows is None:
            return ()
        if self.rownumber:
            result = self._rows[self.rownumber:]
        else:
            result = self._rows
        self.rownumber = len(self._rows)
        return result

    def _get_execute_time(self):
        return self.connection.current_execute_time

    def nextset(self):
        return self._nextset(False)
    
    def _nextset(self, unbuffered=False):
        return False

    def _do_get_result(self):
        """
        Get result after execute.
        """
        conn = self._get_db()
        self._result = result = conn._result
        self.rowcount = result.affected_rows
        self.description = result.description
        self.err = result.err
        self._rows = result.rows
        if self.err:
            # TODO raise a execption
            warnings.warn(self.err)
    
    def _get_db(self):
        """
        Get the connection to execute query operation.
        : return : connection.
        """
        if not self.connection:
            raise err.ProgrammingError("Cursor closed")
        return self.connection
    
    def _check_executed(self):
        """
        Check if the query executed.
        """
        if not self._executed:
            raise err.ProgrammingError("execute() first")
    
    def _clear_result(self):
        """
        Clear last result info.
        """
        self.rownumber = 0
        self._result = None
        self.rowcount = 0
        self.description = None
        self.lastrowid = None
        self._rows = None
    
    def set_arraysize(self, size):
        """
        Set arraysize to the cursor.
        :param number size : arraysize of the cursor.
        """
        self.arraysize = size

    def get_arraysize(self):
        """
        Get arraysize of the cursor.
        : return : arraysize of the cursor.
        """
        return self.arraysize
    
    def callproc(self, procname, args=()):
        '''
        Does nothing, required by DB API.
        '''

    def setinputsizes(self, *args):
        '''
        Does nothing, required by DB API.
        '''
        pass
       
    def setoutputsizes(self, *args):
        '''
        Does nothing, required by DB API.
        '''
        pass

    Warning = err.Warning
    Error = err.Error
    InterfaceError = err.InterfaceError
    DatabaseError = err.DatabaseError
    DataError = err.DataError
    OperationalError = err.OperationalError
    IntegrityError = err.IntegrityError
    InternalError = err.InternalError
    ProgrammingError = err.ProgrammingError
    NotSupportedError = err.NotSupportedError

class SSCursor(Cursor):
    """
    Unbuffered Cursor, mainly useful for queries that return a lot of data,
    or for connections to remote servers over a slow network.
    Instead of copying every row of data into a buffer, this will fetch
    rows as needed. The upside of this is the client uses much less memory,
    and rows are returned much faster when traveling over a slow network
    or if the result set is very big.
    There are limitations, though. The wireline protocol doesn't support
    returning the total number of rows, so the only way to tell how many rows
    there are is to iterate over every row returned. Also, it currently isn't
    possible to scroll backwards, as only the current row is held in memory.
    """

    def close(self):
        conn = self.connection
        if conn is None:
            return

        if self._result is not None and self._result is conn._result:
            #self._result._finish_unbuffered_query()
            pass

        try:
            while self.nextset():
                pass
        finally:
            self.connection = None

    __del__ = close

    def _query(self, q):
        conn = self._get_db()
        self._last_executed = q
        self._clear_result()
        conn.query(q, unbuffered=True)
        self._do_get_result()
        return self.rowcount

    def nextset(self):
        return self._nextset(unbuffered=True)

    def read_next(self):
        """
        Read next row
        """
        return self._result.read_next_row()

    def fetchone(self):
        """
        Fetch next row
        """
        self._check_executed()
        row = self.read_next()
        if row is None:
            #self._show_warnings()
            return None
        self.rownumber += 1
        return row

    def fetchall(self):
        """
        Fetch all, as per MySQLdb. Pretty useless for large queries, as
        it is buffered. See fetchall_unbuffered(), if you want an unbuffered
        generator version of this method.
        """
        return list(self.fetchall_unbuffered())

    def fetchall_unbuffered(self):
        """
        Fetch all, implemented as a generator, which isn't to standard,
        however, it doesn't make sense to return everything in a list, as that
        would use ridiculous memory for large result sets.
        """
        return iter(self.fetchone, None)

    def __iter__(self):
        return self.fetchall_unbuffered()

    def fetchmany(self, size=None):
        """Fetch many"""
        self._check_executed()
        if size is None:
            size = self.arraysize

        rows = []
        for i in range_type(size):
            row = self.read_next()
            if row is None:
                #self._show_warnings()
                break
            rows.append(row)
            self.rownumber += 1
        return rows
