# -*- coding: utf-8 -*-
import io
import errno
import socket
import logging
from pyRDP.logger import Logger
from pyRDP.cursors import Cursor
import pyRDP.err as err
import pyRDP.converters as converters
from pyRDP.wireline_protocol import WirelineProtocol
from pyRDP._compat import PY2,IRONPYTHON,str_type
from pyRDP.charset import charset_by_name, charset_by_id
from pyRDP.messages.v2.QueryExecuteRequest.ttypes import QueryExecuteRequest
import datetime

log = Logger().getLogger()

if PY2 and not IRONPYTHON:
    # read method of file-like returned by sock.makefile() is very slow.
    # So we copy io-based one from Python 3.
    from pyRDP._socketio import SocketIO

    def _makefile(sock, mode):
        return io.BufferedReader(SocketIO(sock, mode))
else:
    # socket.makefile in Python 3 is nice.
    def _makefile(sock, mode):
        return sock.makefile(mode)

DEFAULT_CHARSET = 'utf8'

class Connection(object):
    """
    Representation of a socket with a rapidsdb server.
    The proper way to get an instance of this class is to call
    connect().
    Establish a connection to the rapidsdb database. Accepts several
    arguments:
    :param host: Host where the database server is located
    :param user: Username to log in as
    :param password: Password to use.
    :param database: Database to use, None to not use a particular one.
    :param port: rapidsdb port to use, default is usually OK. (default: 4333)
    :param read_timeout: The timeout for reading from the connection in seconds (default: None - no timeout)
    :param write_timeout: The timeout for writing to the connection in seconds (default: None - no timeout)
    :param charset: Charset you want to use.
    :param conv:
        Conversion dictionary to use instead of the default one.
        This is used to provide custom marshalling and unmarshaling of types.
        See converters.
    :param cursorclass: Custom cursor class to use.
    :param connect_timeout: Timeout before throwing an exception when connecting.
        (default: 10, min: 1, max: 31536000)
    See `Connection <https://www.python.org/dev/peps/pep-0249/#connection-objects>`_ in the
    specification.
    """

    _sock = None
    _closed = False
    _secure = False

    # AUTH_TYPE PLAIN / KERBORS
    def __init__(self,host=None, port=4333,cursorclass=Cursor,db=None,database=None,
                tprotocol=None,write_timeout=None,read_timeout=None,protocol=None,user=None,
                password=None,federation=None,catalog=None,schema=None,charset='',
                encoding=None,conv=None,connect_timeout=10,auth_type='PLAIN'):
        self.current_execute_time = 0
        self.host = host or "localhost"
        self.port = port or 4333
        self.auth_type = auth_type
        self.user = user
        self.password = password
        self.cursorclass = cursorclass
        self.protocol =protocol
        if read_timeout is not None and read_timeout <= 0:
            log.error("read_timeout should be >= 0")
            raise ValueError("read_timeout should be >= 0")
        self._read_timeout = read_timeout
        if write_timeout is not None and write_timeout <= 0:
            log.error("write_timeout should be >= 0")
            raise ValueError("write_timeout should be >= 0")
        self._write_timeout = write_timeout

        connect_timeout = int(connect_timeout)
        if not (0 < connect_timeout <= 31536000):
            raise ValueError("connect_timeout should be >0 and <=31536000")
        self.connect_timeout = connect_timeout or None

        if charset:
            self.charset = charset
        else:
            self.charset = DEFAULT_CHARSET

        self.encoding = charset_by_name(self.charset).encoding

        if conv is None:
            conv = converters.conversions
            
        self.encoders = {k: v for (k, v) in conv.items() if type(k) is not int}
        self.decoders = {k: v for (k, v) in conv.items() if type(k) is int}

        self.connect()

        # set federation catalog schema
        if federation:
            self._set_federation(federation)
        if catalog:
            self._set_catalog(catalog)
        if schema:
            self._set_schema(schema)

    def __enter__(self):
        """Context manager that returns a Cursor"""
        return self.cursor()

    def connect(self, sock=None):
        self._closed = False
        if sock is None:
            sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
            sock.settimeout(self.connect_timeout)
            sock.connect((self.host,self.port))
        self._sock = sock
        self._rfile = _makefile(sock,'rb')
        if self.protocol is None:
            self.protocol = WirelineProtocol(self)
        self._login()

    def _login(self):
        self.protocol.login()

    # this private method use to set federation catalog schema
    def _set_federation(self, federation_name):
        maxlength = 128

        if(federation_name and (len(federation_name) > maxlength or len(federation_name) < 1)):
            #TODO: raise execption
            pass

        cursor = self.cursor()
        sql = "SET FEDERATION "
        sql += federation_name
        sql += ";"
        cursor.execute(sql)
        cursor.close()

    def _set_catalog(self, catalog_name):
        maxlength = 128

        if(catalog_name and (len(catalog_name) > maxlength or len(catalog_name) < 1)):
            #TODO: raise execption
            pass

        cursor = self.cursor()
        sql = "SET CATALOG "
        sql += catalog_name
        sql += ";"

        cursor.execute(sql)
        cursor.close()

    def _set_schema(self, schema_name):
        maxlength = 128

        if(schema_name and (len(schema_name) > maxlength or len(schema_name) < 1)):
            #TODO: raise execption
            pass

        cursor = self.cursor()
        sql = "SET SCHEMA "
        sql += schema_name
        sql += ";"
        cursor.execute(sql)
        cursor.close()

    def escape(self, obj, mapping=None):
        """
        Escape whatever value you pass to it.
        Non-standard, for internal use; do not use this in your applications.
        """
        if isinstance(obj, str_type):
            return "'" + converters.escape_string(obj) + "'"
        if isinstance(obj, (bytes, bytearray)):
            return converters.escape_bytes(obj)
        return converters.escape_item(obj, self.charset, mapping=mapping)

    def literal(self, obj):
        """
        Alias for escape()
        Non-standard, for internal use; do not use this in your applications.
        """
        return self.escape(obj, self.encoders)
    

    def close(self):
        """
        Close connection .
        """
        if self._closed:
            raise err.Error("Already closed")
        self._closed = True
        if self._sock is None:
            return
        # try:
        #     #TODO send cole session
        # except Exception:
        #     pass
        # finally:
        self._force_close()

    def _check_open(self):
        if self._closed:
            #TODO: raise a socket closed exception
            pass

    def open(self):
        return self._sock is not None
    
    def _force_close(self):
        if self._sock:
            try:
                self._sock.close()
            except:
                pass
        self._sock = None
        self._rfile = None

    def commit(self):
        '''
        Does nothing, required by DB API.
        '''
        pass
    
    def rollback(self):
        '''
        Does nothing, required by DB API.
        '''
        pass

    def begin(self):
        '''
        Does nothing, required by DB API.
        ''' 
        pass

    def query(self,sql,unbuffered=False):
        start = datetime.datetime.now()
        self.protocol.query(sql)
        end = datetime.datetime.now()
        self.current_execute_time = end - start
        self._affected_rows = self._read_query_result(unbuffered)
    
    def next_result(self, unbuffered=False):
        self._affected_rows = self._read_query_result(unbuffered=unbuffered)
        return self._affected_rows

    # This is for testing base request, will delete later
    def query_demo(self,sql):
        request = QueryExecuteRequest(sql)
        self.protocol._send_message(request,29)
        while True:
            message = self.protocol._read_message()
            print(message)

    def cursor(self, cursor=None):
        if cursor:
            return cursor(self)
        return self.cursorclass(self)
    
    def _read_query_result(self, unbuffered=False):
        self._result = None
        if unbuffered:  
            try:
                result = ResultSet(self.protocol)
                result.init_unbuffered_query()
            except:
                result.unbuffered_active = False
                result.protocol = None
                raise
        else:
            result = ResultSet(self.protocol)
            result.read()
        self._result = result
        return result.affected_rows
    
class ResultSet(object):
    def __init__(self, protocol):
        self.protocol = protocol
        self.affected_rows = None
        self.rows = None
        self.unbuffered = False
        self.description = None
        self.field_count = 0
        self.err = None
    
    # buffered result, cache all the data to the client
    def read(self):
        self._read_all()
        self.protocol = None
    
    def init_unbuffered_query(self):
        self.description = self.protocol.description
        self.field_count = self.protocol.numColumns
        self.err = self.protocol.errstr
        self.affected_rows = 18446744073709551615
        self.unbuffered = True
        # if self.err:
        #     raise err.ProgrammingError(err)

    def read_next_row(self):
        if not self.unbuffered:
            return

        if self.protocol and self.protocol.get_next_row():
            row = self.protocol.row
        else:
            self.protocol = None
            row = None

        self.rows = (row,)

        if row is not None:
            self.affected_rows = 1
       
        return row
        
    def _read_all(self):
        rows = []
        while self.protocol.get_next_row():
            rows.append(self.protocol.row)
        self.affected_rows = len(rows)
        self.rows=rows
        self.description = self.protocol.description
        self.field_count = self.protocol.numColumns
        self.err = self.protocol.errstr
        # if self.err:
        #     raise err.ProgrammingError(err)
        


    
    