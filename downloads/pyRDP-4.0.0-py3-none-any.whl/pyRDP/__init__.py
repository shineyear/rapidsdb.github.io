'''
pyRDP: A pure-Python RapidsDB client library.

'''

'''
0	Threads may not share the module.
1	Threads may share the module, but not connections.
2	Threads may share the module and connections.
3	Threads may share the module, connections and cursors.
'''

'''

paramstyle |	Meaning
------------------------------------------------------
qmark	   | Question mark style, e.g. ...WHERE name=?
numeric	   | Numeric, positional style, e.g. ...WHERE name=:1
named	   | Named style, e.g. ...WHERE name=:name
format	   | ANSI C printf format codes, e.g. ...WHERE name=%s
pyformat   | Python extended format codes, e.g. ...WHERE name=%(name)s
'''

from .err import Error

threadsafety = 1
# PEP249 is version 2.0; PEP248 is version 1.0, here we follow PEP249
apilevel = "2.0"

def Connect(*args, **kwargs):
    from pyRDP.connections import Connection
    return Connection(*args, **kwargs)

connect = Connection = Connect