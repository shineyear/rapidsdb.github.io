# -*- coding: utf-8 -*-
from io import BytesIO

import time
import errno
import datetime
from decimal import Decimal
import pyRDP.err as err
from pyRDP.constants import CR
from pyRDP.logger import Logger
from thrift.protocol import TCompactProtocol, TBase
from thrift.TSerialization import serialize, deserialize
from pyRDP.utils import byte2int, int2_4bytes, int2byte,bytes2int

from pyRDP.messages.v4.MessageTypes.ttypes import MessageTypes
from pyRDP.messages.compatibility.ProtocolCompatibleRequest.ttypes import ProtocolCompatibleRequest
from pyRDP.messages.compatibility.ProtocolCompatibleResponse.ttypes import ProtocolCompatibleResponse
from pyRDP.messages.compatibility.ProtocolIncompatibleResponse.ttypes import ProtocolIncompatibleResponse
from pyRDP.messages.v4.ColumnMetadata.ttypes import ColumnMetadata
from pyRDP.messages.v4.ColumnMetadata.ttypes import DataType
from pyRDP.messages.v4.ErrorResponse.ttypes import ErrorResponse
from pyRDP.messages.v4.WarningResponse.ttypes import WarningResponse
from pyRDP.messages.v4.ShutdownNotification.ttypes import ShutdownNotification
from pyRDP.messages.v4.DisconnectNotification.ttypes import DisconnectNotification
from pyRDP.messages.v4.DisconnectRequest.ttypes import DisconnectRequest
from pyRDP.messages.v4.PingRequest.ttypes import PingRequest
from pyRDP.messages.v4.PingResponse.ttypes import PingResponse
from pyRDP.messages.v4.ClearTextTunnelRequest.ttypes import ClearTextTunnelRequest
from pyRDP.messages.v4.TunnelSupportedResponse.ttypes import TunnelSupportedResponse
from pyRDP.messages.v4.AuthenticationOkResponse.ttypes import AuthenticationOkResponse
from pyRDP.messages.v4.SessionChangeRequest.ttypes import SessionChangeRequest
from pyRDP.messages.v4.SessionChangeResponse.ttypes import SessionChangeResponse
from pyRDP.messages.v4.QueryExecuteRequest.ttypes import QueryExecuteRequest
from pyRDP.messages.v4.QueryReceiptResponse.ttypes import QueryReceiptResponse
from pyRDP.messages.v4.RowMetadataResponse.ttypes import RowMetadataResponse
from pyRDP.messages.v4.RowDataResponse.ttypes import RowDataResponse
from pyRDP.messages.v4.StatementResponse.ttypes import StatementResponse
from pyRDP.messages.v4.QueryExecuteResponse.ttypes import QueryExecuteResponse
from pyRDP.messages.v4.QueryProgressRequest.ttypes import QueryProgressRequest
from pyRDP.messages.v4.QueryProgressResponse.ttypes import QueryProgressResponse
from pyRDP.messages.v4.SessionMonitoringRequest.ttypes import SessionMonitoringRequest
from pyRDP.messages.v4.SessionProtocolVersionResponse.ttypes import SessionProtocolVersionResponse
from pyRDP.messages.v4.SessionDataResponse.ttypes import SessionDataResponse
from pyRDP.messages.v4.SessionDroppedMessagesResponse.ttypes import SessionDroppedMessagesResponse
from pyRDP.messages.v4.SessionMonitoringResponse.ttypes import SessionMonitoringResponse
from pyRDP.messages.v4.ParseStatementRequest.ttypes import ParseStatementRequest
from pyRDP.messages.v4.ParseStatementResponse.ttypes import ParseStatementResponse
from pyRDP.messages.v4.StatementBindAndExecuteRequest.ttypes import StatementBindAndExecuteRequest
from pyRDP.messages.v4.ClosePreparedStatementRequest.ttypes import ClosePreparedStatementRequest
from pyRDP.messages.v4.ClosePreparedStatementResponse.ttypes import ClosePreparedStatementResponse
from pyRDP.messages.v4.PlainAuthenticationRequest.ttypes import PlainAuthenticationRequest
from pyRDP.messages.v4.GssNegotiationMsg.ttypes import GssNegotiationMsg
from pyRDP.messages.v4.KerberosAuthenticationRequest.ttypes import KerberosAuthenticationRequest

log = Logger().getLogger()

class WirelineProtocol(object):

    MAX_MSG_PAYLOAD_SIZE = 16777208; # 24 bits - 8 bytes for the header

    def __init__(self, connection=None, tprotocol=None):
        self.connection = connection
        self.sock = connection._sock
        self.rfile = connection._rfile
        self.serialize = serialize
        self.deserialize = deserialize
        self.tprotocol = tprotocol
        self.current_row_data_response = None
        self.new_row_data_response = None
        self.has_row_metadata_response = False
        self.current_message_type = None # current message type
        self.rdb_header = None
        self.icurrent_row_index = 0 # current row index
        self.imax_rows = 0 # total rows of this rowdataresponse packet
        self.row = None # current row data 
        self.numColumns = None # number of columns
        self.columns = None # columns metadata 
        self.description = None
        self.end_of_response = False # response end of this request
        self.end_of_results = False  # results end of this request
        self.errstr = None  # ErrorResponse message here
        if tprotocol is None:
            self.tprotocol = TCompactProtocol.TCompactProtocolFactory()
    
    def login(self):
        """
        Before real request and response,  make sure server side have ability to response the request.
        """
        self._do_protocol_compatibility_dailog("login")
        self._do_tunnel_dialog()
        #Authentication
        if self.connection.auth_type == 'PLAIN':
           self._do_plain_authentication_dialog()
        else:
            raise err.NotSupportedError("Only support Authentication type PLAIN")
     
        self._do_session_change_dialog()

    def _do_protocol_compatibility_dailog(self,desc):
        """
        Negotiate protocol version
        """
        request = ProtocolCompatibleRequest(4,desc)
        self._send_message(request,1)
        message = self._read_message()


    def _do_tunnel_dialog(self):
        """
        Negotiate tunnel type 
        """
        request = ClearTextTunnelRequest()
        self._send_message(request,21)
        message = self._read_message()
    
    def _do_kerberos_authentication_dialog(self):
        """
        Authentication with kerberos, still not support here.
        """
        pass
    
    def _do_plain_authentication_dialog(self):
        """
        Authentication with username and password.
        """
        username = self.connection.user
        password = self.connection.password
        request = PlainAuthenticationRequest(username,password)
        self._send_message(request,31)
        message = self._read_message()

        if message.type == 6:
            log.debug("Could not authenticate with RapidsDB (username/password).")
            # throw a exception
            raise err.OperationalError(message.message.errorString,"28R01")

    
    def _do_authentication_dialog(self,username):
        """
        Authentication, actually server side always allow client pass the authentication right now.
        """
        request = AuthenticationRequest(username)
        self._send_message(request,23)
        message = self._read_message()

    def _do_session_change_dialog(self):
        """
        I have no idea about this method, seems we need this request befor real comunication. 
        """
        request = SessionChangeRequest()
        self._send_message(request,41)
        message = self._read_message()
    
    def query(self, sql):
        """
        Send query message and handle response.
        """
        # clear last result here
        self._clear()
        # rowsPerRowDataResponse
        request = QueryExecuteRequest(query=sql)
        self._send_message(request,51)

        self.current_message_type = MessageTypes.QueryExecuteRequest
        done = False
        while not done:
            done = self._handle_message_state()
        
        if self.new_row_data_response is not None:
            self.current_row_data_response = self.new_row_data_response

    def _read_message(self):
        """
        Read a message from sever side. First read a message header , according to the header info, the read the total message.
        """
        header = self._read_bytes(8)
        length = bytes2int(header[0:4])[0]
        return_type = byte2int(header[4])
        payload_size = length - 8
        payload = self._read_bytes(payload_size)
        message = self._create_message(return_type)
        return_message = self.deserialize(message,payload,self.tprotocol)
        
        msgTypeName = self._get_messagetype_name(return_type)
        msg = "Receving Message type: " + str(return_type) + \
            " (" + msgTypeName + ") from server." 
        
        # log message info 
        log.info(msg)
        return MessageAndTypePair(return_message, return_type)
        #return return_message

    def _read_bytes(self,num_bytes):
        """
        Read bytes from socket.
        """
        while True:
            try:
                data = self.rfile.read(num_bytes)
                break
            except (IOError, OSError) as e:
                if e.errno == errno.EINTR:
                    continue
                raise err.OperationalError(
                        CR.CR_SERVER_LOST,
                        "Lost connection to RapidDB server during query (%s)" % (e,))
        if len(data) < num_bytes:
            raise err.OperationalError(
                        CR.CR_SERVER_LOST,
                        "Lost connection to RapidDB server during query ")
        return data

    def _send_message(self, message, type):
        """
        Send  message to server side.
        """

        msgTypeName = self._get_messagetype_name(type)
        msg = "Sending Message type: " + str(type) + \
            " (" + msgTypeName + ") to server. " 
        
        # log message info
        log.info(msg)

        message_bytes = serialize(message,self.tprotocol)
        if len(message_bytes) > self.MAX_MSG_PAYLOAD_SIZE:
            raise err.ProgrammingError("Message is over max message payload size.")

        header = self._create_header(type,len(message_bytes))
        data = header + message_bytes
        self._send_bytes(data)
    
    def _send_bytes(self, data):
        """
        Send bytes to socket.
        """

        try:
            self.sock.sendall(data)
        except IOError as e:
            raise err.OperationalError(
                CR.CR_SERVER_GONE_ERROR,
                "RapidDB server has gone away (%r)" % (e,))
    
    def _get_messagetype_name(self, type):
        """
        Get message type name according type id.
        """
        message_type_name = MessageTypes._VALUES_TO_NAMES[type]
        if message_type_name is None:
            raise err.ProgrammingError("Message type not exist.")
        return message_type_name

    def _handle_message_state(self):
        """
        Handle the response from the server side.
        """   
        b_done = False
        response_pair = None
        #new_state reprenst new message type
        new_state = self._read_rdp_header()
        log.info('Receving Message type :' + str(new_state) + "("+ self._get_messagetype_name(new_state) +") from server." )
        if self.current_message_type == MessageTypes.RowDataResponse and new_state == MessageTypes.RowDataResponse:
            b_done = True
        else:
            response_pair = self._read_rdp_buffer()

        if self.current_message_type == MessageTypes.QueryExecuteRequest:
            if new_state == MessageTypes.QueryReceiptResponse:
                pass
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                # - errorCode
                # - sqlStateCode 
                # - errorString
                # - stackTrace
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            else:
                #raise a execption to tell wrong state
                pass
        elif self.current_message_type == MessageTypes.QueryReceiptResponse:
            if new_state == MessageTypes.RowMetadataResponse:
                # message is rowmetadataresponse
                message = response_pair.message
                self.numColumns = message.numColumns
                column_metadatas = message.columns
                columns = []
                descs = []
                #sqlAlchemly only support list description
                for column_metadata in column_metadatas :
                    col_info = {}
                    desc = []
                    col_info['name'] = column_metadata.columnName
                    col_info['type'] = column_metadata.columnType
                    col_info['rdb_type'] = self._get_rdb_type(column_metadata.columnType)
                    col_info['precision'] = column_metadata.precision
                    col_info['scale'] = column_metadata.scale
                    col_info['nullable'] = column_metadata.isNullable
                    desc.append(col_info['name'])
                    desc.append(col_info['type'])
                    desc.append(col_info['rdb_type'])
                    desc.append(col_info['precision'])
                    desc.append(col_info['scale'])
                    desc.append(col_info['nullable'])
                    columns.append(col_info)
                    descs.append(desc)
                self.columns = columns
                self.description = descs
                self.has_row_metadata_response = True
                self.imax_rows = 0
                self.icurrent_row_index = 0
                if self.numColumns > 0:
                    self.end_of_response = False
                    self.end_of_results = False
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            elif new_state == MessageTypes.StatementResponse:
                pass
            else:
                #TODO raise a execption to tell wrong state
                pass
        elif self.current_message_type == MessageTypes.RowMetadataResponse:
            if new_state == MessageTypes.RowDataResponse:
                message = response_pair.message
                self.imax_rows = len(message.rows)
                self.new_row_data_response = message
                self.end_of_response = False
            elif new_state == MessageTypes.StatementResponse:
                message = response_pair.message
                #self.new_row_data_response = 
                self.imax_rows = 0
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            else:
                #TODO raise a execption to tell wrong state
                pass
        elif self.current_message_type == MessageTypes.RowDataResponse:
            if new_state == MessageTypes.RowDataResponse:
                self.end_of_response = False
                b_done = True
            elif new_state == MessageTypes.StatementResponse:
                """
                statementId
                statementString
                numMatchedRows
                numAffectedRows
                affectedVerb
                """
                message = response_pair.message
                self.affected_rows = message.numAffectedRows
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            else:
                #TODO raise a execption to tell wrong state
                pass
        elif self.current_message_type == MessageTypes.StatementResponse:
            if new_state == MessageTypes.QueryExecuteResponse:
                b_done = True
                self.end_of_response = True
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            # TODO: Handle receiving another StatementResponse here
            # TODO: e.g., as part of a batch submitted as one query.
            elif new_state == MessageTypes.RowMetadataResponse:
                pass 
            # do not handle multiple results
            elif new_state == MessageTypes.StatementResponse:
                pass
            else:
                #TODO raise a execption to tell wrong state
                pass
        elif self.current_message_type == MessageTypes.QueryExecuteResponse:
            #Should never get a message after a QueryExecuteResponse
            #except for an asynchronous message like a DisconnectNotification.
            pass
        elif self.current_message_type == MessageTypes.WarningResponse:
            #All warnings are handled in the context of other queries, and we ignore warnings from the context
            #of setting current_message_type too. So we should never get here.
            pass
        elif self.current_message_type == MessageTypes.ErrorResponse:
            if new_state == MessageTypes.QueryExecuteResponse:
                b_done = True
                self.end_of_response = True
            elif new_state == MessageTypes.WarningResponse:
                pass
            elif new_state == MessageTypes.ErrorResponse:
                self._error_received = True
                message = response_pair.message
                self.errstr = message.errorString
                if message.stackTrace:
                    self.errstr += "\n" + message.stackTrace
                b_done = True
                self.end_of_response = True
            else:
                #TODO raise a execption to tell wrong state
                pass
        else:
            b_done = True
        
        self.rdb_header.msg_prior_type = self.current_message_type
        self.current_message_type = new_state

        return b_done
    
    # TODO: extracte repeat part
    def _handle_error_response(self):
        pass

    def _get_rdb_type(self, colum_type):
        """
        Get rdb data type according to metadata colum type.
        :param number colum_type : colum data type.
        : return : rdb data type.
        """
        return DataType._VALUES_TO_NAMES[colum_type]

    def get_next_row(self):
        """
        Get next row data.
        : return : flag of if have next row.
        """
        if ((self.end_of_response or self.end_of_results) and self.current_row_data_response is None):
            return False
        if self.icurrent_row_index < self.imax_rows:
            self._next_row()
        else:
            if self._read_more_data():
                self.icurrent_row_index = 0
                self.end_of_results = False
                self._next_row()
            else:
                self.end_of_response = True
                self.end_of_results = True
        if self.end_of_results:
            return False
        return True

    def get_next_set(self):
        """
        Get next set data.
        """
        if ((self.end_of_response or self.end_of_results) and self.current_row_data_response is None):
            return False
        if self.icurrent_row_index < self.imax_rows:
            self._next_set()
        else:
            if self._read_more_data():
                self.icurrent_row_index = 0
                self.end_of_results = False
                self._next_set()
            else:
                self.end_of_response = True
                self.end_of_results = True
        if self.end_of_results:
            return False
        return True

    def _next_set(self):
        """
        Get data as a set.
        """
        if self.end_of_response and self.current_row_data_response is None:
            return
        try:
            self._get_set_from_rdp_buffer()
        except:
            pass

    def _get_set_from_rdp_buffer(self):
        """
        Decode all the buffered data to a set.

        ps: not used in high level
        """
        self.set = []
        while not self.end_of_results:
            self._get_row_from_rdp_buffer
            self.set.append(self.row)

    def _next_row(self):
        """
        Decode next row from buffer.
        """
        if self.end_of_response and self.current_row_data_response is None:
            return
        try:
            self._get_row_from_rdp_buffer()
        except ValueError:
            pass  
    
    def _get_row_from_rdp_buffer(self):
        """
        Get one row from buffer and decode the db data type to python data type.
        """
        if self.current_row_data_response is not None and self.icurrent_row_index < self.imax_rows:
            row = self.current_row_data_response.rows[self.icurrent_row_index]
            self.icurrent_row_index += 1
            colums = row.columns
            temp_row = []
            for i in range(len(colums)) : 
                if colums[i].isNull:
                    temp_row.append(None)
                elif self.columns[i]['rdb_type'] == "NULL":
                    temp_row.append(None)
                elif self.columns[i]['rdb_type'] == "BOOLEAN":
                    temp_row.append(colums[i].booleanVal)
                elif self.columns[i]['rdb_type'] == "TINYINT":
                    temp_row.append(colums[i].tinyIntVal)
                elif self.columns[i]['rdb_type'] == "SMALLINT":
                    temp_row.append(colums[i].smallIntVal)
                elif self.columns[i]['rdb_type'] == "INTEGER":
                    temp_row.append(colums[i].integerVal)
                elif self.columns[i]['rdb_type'] == "BIGINT":
                    temp_row.append(colums[i].bigintVal)
                elif self.columns[i]['rdb_type'] == "DECIMAL":
                    temp_row.append(Decimal(colums[i].bigDecimalVal))
                elif self.columns[i]['rdb_type'] == "FLOAT":
                    temp_row.append(colums[i].doubleVal)
                elif self.columns[i]['rdb_type'] == "DATE":
                    timestamp = colums[i].dateVal
                    date = datetime.date(year=int(timestamp.year), month=int(timestamp.month),
                             day=int(timestamp.day))
                    temp_row.append(date)
                elif self.columns[i]['rdb_type'] == "TIME":
                    timestamp = colums[i].timeVal
                    time = datetime.time(hour=int(timestamp.hour), minute=int(timestamp.minute),
                             second=int(timestamp.second), microsecond=int(timestamp.nanoseconds))
                    temp_row.append(time)
                elif self.columns[i]['rdb_type'] == "TIMESTAMP":
                    timestamp = colums[i].timestampVal
                    dt = datetime.datetime(int(timestamp.year),int(timestamp.month),int(timestamp.day),
                        int(timestamp.hour),int(timestamp.minute),int(timestamp.second),int(timestamp.nanoseconds))
                    temp_row.append(dt)
                elif self.columns[i]['rdb_type'] == "INTERVAL":
                    interval  = colums[i].intervalVal
                    temp_row.append(interval)
                elif self.columns[i]['rdb_type'] == "VARCHAR":
                    temp_row.append(colums[i].stringVal)
                elif self.columns[i]['rdb_type'] == "VARBINARY":
                    temp_row.append(colums[i].binaryVal)
                else:
                 raise err.NotSupportedError("Unimplemented data type from the wire line protocol: " + columns[i]['rdb_type'])
            self.row = tuple(temp_row)
            self.end_of_results = False
        else:
            self.end_of_results = True

    def _read_more_data(self):
        """
        Read more data.
        : return : flag of the response state.
        """
        b_done = False
        self.current_row_data_response = None

        if self.end_of_response:
            return False
        response_pair = None
        prior_state = self.rdb_header.msg_prior_type
        new_state = self.rdb_header.msg_type

        if prior_state == MessageTypes.RowDataResponse and new_state == MessageTypes.RowDataResponse and self.end_of_response == False :
            response_pair = self._read_rdp_buffer()
            row_data_response = response_pair.message
            self.imax_rows = len(row_data_response.rows)
            self.current_row_data_response = row_data_response
            self.icurrent_row_index = 0
            b_done = True
        else:
            return False
        
        self.current_message_type = new_state
        b_handle_next_state = False
        while(not b_handle_next_state):
            b_handle_next_state = self._handle_message_state()

        return b_done

    def _read_rdp_header(self):
        """
        Read 8 bytes from socket and resolv the message meta information.
        : return : message type id.
        """
        header = self._read_bytes(8)
        length = bytes2int(header[0:4])[0]
        return_type = byte2int(header[4])
        payload_size = length - 8

        if self.rdb_header is None:
            self.rdb_header = RDPHeader()
        self.rdb_header.raw_msg_type = return_type
        self.rdb_header.msg_type = return_type
        self.rdb_header.msg_length = payload_size
        self.rdb_header.clear()

        # msgTypeName = self._get_messagetype_name(return_type)
        # msg = "Receving Message type: " + str(return_type) + \
        #     " (" + msgTypeName + ") from server." 
        
        # # log message info 
        # log.info(msg)

        return return_type

    def _read_rdp_buffer(self):
        """
        Read message boay according to message payload size.
        : return : MessageAndTypePair.
        """
        payload_size = self.rdb_header.msg_length
        payload = self._read_bytes(payload_size)
        message = self._create_message(self.rdb_header.raw_msg_type)
        self.deserialize(message,payload,self.tprotocol)
        return MessageAndTypePair(message, self.rdb_header.raw_msg_type)

    def _create_header(self, type, size):
        """
        Create byte mesage header.
        :param number type : message type id.
        :param number size : message paload size.
        : return : bytes of message header.
        """
        header = int2_4bytes(size + 8) + int2byte(type) + int2byte(0) + int2byte(0) + int2byte(0) 
        return header
 
    def _create_message(self,type):
        """
        Create empty message according to message type id.
        :param number type : message type id.
        : return : Empty message of the type id.
        """

        if type   == 1:
            return ProtocolCompatibleRequest()
        elif type == 2:
            return ProtocolCompatibleResponse()
        elif type == 4:
            return ProtocolIncompatibleResponse()
        elif type == 6:
            return ErrorResponse()
        elif type == 8:
            return WarningResponse()
        elif type == 10:
            return ShutdownNotification()
        elif type == 12:
            return DisconnectNotification()
        elif type == 13:
            return DisconnectRequest()
        elif type == 15:
            return DisconnectRequest()
        elif type == 16:
            return DisconnectRequest()
        elif type == 21 :
            return ClearTextTunnelRequest()
        elif type == 22 :
            return TunnelSupportedResponse()
        elif type == 31 :
            return PlainAuthenticationRequest()
        elif type == 33 :
            return KerberosAuthenticationRequest()
        elif type == 34 :
            return GssNegotiationMsg()
        elif type == 38 :
            return AuthenticationOkResponse()
        elif type == 41 :
            return SessionChangeRequest()
        elif type == 42 :
            return SessionChangeResponse()
        elif type == 51:
            return QueryExecuteRequest()
        elif type == 52:
            return QueryReceiptResponse()
        elif type == 54:
            return RowMetadataResponse()
        elif type == 56:
            return RowDataResponse()
        elif type == 58:
            return StatementResponse()
        elif type == 60:
            return QueryExecuteResponse()
        elif type == 71:
            return QueryCancellationRequest()
        elif type == 72:
            return QueryCancellationResponse()
        elif type == 81:
            return QueryProgressRequest()
        elif type == 82:
            return QueryProgressResponse()
        elif type == 91:
            return SessionMonitoringRequest()
        elif type == 92:
            return SessionProtocolVersionResponse()
        elif type == 94:
            return SessionDataResponse()
        elif type == 96:
            return SessionDroppedMessagesResponse()
        elif type == 98:
            return SessionMonitoringResponse()
        elif type == 101:
            return ParseStatementRequest()
        elif type == 102:
            return ParseStatementResponse()
        elif type == 103:
            return StatementBindAndExecuteRequest()
        elif type == 105:
            return ClosePreparedStatementRequest()
        elif type == 106:
            return ClosePreparedStatementResponse()
        else:
            return None

    def _clear(self):
        self.errstr      = None
        self.row         = None
        self.columns     = None
        self.description = None

class RDPHeader(object):
    def __init__(self, message=None, msg_type=None, msg_prior_type=None, raw_msg_type=None, msg_length=None):
        self.message = message
        self.msg_type =msg_type
        self.msg_prior_type = msg_prior_type
        self.raw_msg_type = raw_msg_type
        self.msg_length = msg_length
    
    def clear(self):
        self.message = None

class MessageAndTypePair(object):
    """
    message and message type wrapper.
    """
    def __init__(self, message, type):
        self.message =  message
        self.type = type

class TableMetaData(object):
    def __init__(self):
        self.catalog = None
        self.schema  = None
        self.name    = None